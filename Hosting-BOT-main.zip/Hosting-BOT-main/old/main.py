#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║   🤖 PROFESSIONAL HOSTING PLATFORM — Combined Edition         ║
║   Telegram Bot Hoster + Web Control Panel                     ║
║   Merged & Optimized from all source examples                 ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import logging
import threading
import time

# ── Ensure project root is on the path ──────────────────────────
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# ── Configure logging early ─────────────────────────────────────
LOG_DIR = os.path.join(BASE_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, 'hosting.log'), encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logging.getLogger('werkzeug').setLevel(logging.ERROR)
logger = logging.getLogger('HostingPlatform')


def main():
    """Launch the combined Hosting Platform."""
    from config import Config
    from database import Database
    from process_manager import ProcessManager
    from web_panel import create_web_panel
    from bot_manager import HostingBot

    logger.info("=" * 60)
    logger.info("🚀 HOSTING PLATFORM STARTING...")
    logger.info(f"🐍 Python: {sys.version.split()[0]}")
    logger.info(f"📁 Base Dir: {BASE_DIR}")
    logger.info(f"➤ Owner ID: {Config.OWNER_ID}")
    logger.info("=" * 60)

    # ── Initialize shared components ─────────────────────────
    db = Database(Config)
    db.initialize()
    db.load_state()

    proc_mgr = ProcessManager(Config, db, logger)

    # ── Start web panel (non-blocking) ───────────────────────
    web_panel = create_web_panel(Config, db, proc_mgr)
    web_thread = threading.Thread(target=web_panel.run_server, daemon=True, name="WebPanel")
    web_thread.start()
    logger.info(f"🌐 Web panel available (thread started)")

    # ── Start Telegram bot (blocking with auto-reconnect) ────
    bot = HostingBot(Config, db, proc_mgr, logger)
    bot.start_polling()


if __name__ == '__main__':
    main()