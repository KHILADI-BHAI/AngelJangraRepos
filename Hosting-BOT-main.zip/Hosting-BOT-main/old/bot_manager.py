#!/usr/bin/env python3
"""Telegram Bot — full-featured hosting bot (merged, optimized)."""
import os, time, shutil, zipfile
from datetime import datetime
import telebot
from telebot import types
import psutil
from config import Config
from database import Database
from process_manager import ProcessManager

BOT_START = time.time()


class HostingBot:
    def __init__(self, cfg, db, pm, logger):
        self.cfg, self.db, self.pm, self.logger = cfg, db, pm, logger
        self.bot = telebot.TeleBot(cfg.BOT_TOKEN)
        self.bot_locked = False
        self._reg()

    # ── helpers ──
    def is_admin(self, uid): return uid in self.cfg.ADMIN_IDS

    def _spinner(self, cid, text, dur=2):
        try:
            m = self.bot.send_message(cid, f"⏳ {text}")
            for i in range(int(dur * 4)):
                time.sleep(0.25)
                try: self.bot.edit_message_text(f"⏳ {text}{'.' * (i % 4)}", cid, m.message_id)
                except Exception: pass
            return m
        except Exception: return None

    def _kb(self, uid):
        kb = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
        if self.is_admin(uid):
            kb.row("📤 Upload File", "📂 Check Files")
            kb.row("🟢 Running Bots", "📊 Statistics")
            kb.row("💳 Subscriptions", "📢 Broadcast")
            kb.row("🔒 Lock Bot", "👥 User Management")
            kb.row("📋 Pending Files", "👑 Admin Panel")
            kb.row("📢 Channel", "📞 Contact")
        else:
            kb.row("📤 Upload File", "📂 Check Files")
            kb.row("🟢 My Bots", "📊 My Stats")
            kb.row("📢 Channel", "📞 Contact")
        return kb

    def _ban_check(self, m):
        if self.db.is_banned(m.from_user.id):
            self.bot.send_message(m.chat.id, "🚫 You are banned.")
            return True
        return False

    def _join_check(self, m):
        if self.is_admin(m.from_user.id): return True
        chans = self.db.force_channels()
        if not chans: return True
        missing = []
        for ch in chans:
            try:
                st = self.bot.get_chat_member(ch['channel'], m.from_user.id).status
                if st in ('left', 'kicked'): missing.append(ch)
            except Exception: missing.append(ch)
        if missing:
            kb = types.InlineKeyboardMarkup()
            for ch in missing:
                kb.add(types.InlineKeyboardButton(f"📢 {ch.get('title') or ch['channel']}",
                        url=ch.get('invite_link') or f"https://t.me/{ch['channel'].lstrip('@')}"))
            kb.add(types.InlineKeyboardButton("✅ I've joined!", callback_data='joined'))
            self.bot.send_message(m.chat.id, "🔒 Join these channels first:", reply_markup=kb)
            return False
        return True

    def _limit_str(self, uid):
        lim = self.db.get_file_limit(uid)
        return '∞' if lim == float('inf') else str(int(lim))

    def _uptime(self):
        d = int(time.time() - BOT_START)
        return f"{d // 3600}h {(d % 3600) // 60}m"

    @staticmethod
    def _fmt(n):
        for u in ('B', 'KB', 'MB', 'GB'):
            if n < 1024: return f"{n:.1f} {u}"
            n /= 1024
        return f"{n:.1f} TB"

    # ── handlers ──
    def _reg(self):
        b = self.bot

        @b.message_handler(commands=['start'])
        def start(m):
            self.db.touch_user(m.from_user.id, m.from_user.username)
            if self._ban_check(m): return
            if not self._join_check(m): return
            self._spinner(m.chat.id, "Loading...", 2)
            self.bot.send_message(
                m.chat.id,
                f"🤖 <b>HOSTING PLATFORM</b>\n\n"
                f"👋 Welcome, <b>{m.from_user.first_name}</b>!\n"
                f"📁 Files: {self.db.project_count(m.from_user.id)}/{self._limit_str(m.from_user.id)}\n"
                f"💳 Status: {'👑 Owner' if m.from_user.id == self.cfg.OWNER_ID else '⭐ Admin' if self.is_admin(m.from_user.id) else '🌟 Premium' if self.db.is_premium(m.from_user.id) else '👤 Free'}",
                parse_mode='HTML', reply_markup=self._kb(m.from_user.id))

        @b.message_handler(commands=['stats'])
        def stats(m):
            msg = self._spinner(m.chat.id, "Gathering stats...", 2)
            mem = psutil.virtual_memory()
            projs = self.db.all_projects()
            txt = (f"📊 <b>SYSTEM STATS</b>\n🖥️ CPU: {psutil.cpu_percent()}%\n"
                   f"🧠 RAM: {mem.percent}% ({self._fmt(mem.used)}/{self._fmt(mem.total)})\n"
                   f"🚀 Projects: {len(projs)}\n"
                   f"🟢 Running: {sum(1 for p in projs if p['status'] == 'running')}\n"
                   f"⏱️ Uptime: {self._uptime()}")
            try: b.edit_message_text(txt, m.chat.id, msg.message_id, parse_mode='HTML')
            except Exception: b.send_message(m.chat.id, txt, parse_mode='HTML')

        @b.message_handler(commands=['speed'])
        def speed(m):
            t0 = time.time()
            self._spinner(m.chat.id, "Testing...", 1)
            lat = (time.time() - t0) * 1000
            b.send_message(m.chat.id, f"⚡ <b>Speed</b>\n🏓 Latency: {lat:.1f}ms\n"
                                      f"🖥️ CPU: {psutil.cpu_percent()}%\n"
                                      f"📶 {'🟢 Excellent' if lat < 100 else '🟡 Good' if lat < 500 else '🔴 Slow'}",
                           parse_mode='HTML')

        @b.message_handler(commands=['lock'])
        def lock(m):
            if not self.is_admin(m.from_user.id): return b.reply_to(m, "⛔ Admin only!")
            self.bot_locked = not self.bot_locked
            b.reply_to(m, f"🔒 Locked: {self.bot_locked}")

        @b.message_handler(commands=['sub', 'unsub', 'ban', 'unban', 'limit', 'broadcast'])
        def admin(m):
            if not self.is_admin(m.from_user.id): return b.reply_to(m, "⛔ Admin only!")
            p = m.text.split(); cmd = p[0].lstrip('/')
            try:
                if cmd == 'sub' and len(p) == 3:
                    exp = self.db.set_subscription(int(p[1]), int(p[2]))
                    b.reply_to(m, f"✅ Sub until {exp.date()}")
                elif cmd == 'unsub' and len(p) == 2:
                    self.db.remove_subscription(int(p[1])); b.reply_to(m, "✅ Removed")
                elif cmd == 'ban' and len(p) >= 2:
                    self.db.ban_user(int(p[1]), ' '.join(p[2:]) or 'Banned'); b.reply_to(m, "✅ Banned")
                elif cmd == 'unban' and len(p) == 2:
                    self.db.unban_user(int(p[1])); b.reply_to(m, "✅ Unbanned")
                elif cmd == 'limit' and len(p) == 3:
                    self.db.set_file_limit(int(p[1]), int(p[2])); b.reply_to(m, "✅ Limit set")
                elif cmd == 'broadcast' and len(p) >= 2:
                    msg2 = ' '.join(p[1:]); sent = 0
                    for u in self.db.all_users():
                        try: b.send_message(u['user_id'], f"📢 <b>Broadcast:</b>\n{msg2}", parse_mode='HTML'); sent += 1
                        except Exception: pass
                    b.reply_to(m, f"✅ Sent to {sent} users")
                else: b.reply_to(m, "❌ Invalid usage")
            except Exception as e:
                b.reply_to(m, f"❌ Error: {e}")

        @b.message_handler(func=lambda m: m.text and not m.text.startswith('/'))
        def menu(m):
            t = m.text.strip()
            if t == "📤 Upload File":
                self.db.save_pending_upload(m.from_user.id, {'step': 'file'})
                b.send_message(m.chat.id, "📤 Send me a .py file or .zip archive.")
            elif t == "📂 Check Files": self._list_projects(m)
            elif t == "🟢 Running Bots": self._running(m, all_users=True)
            elif t == "🟢 My Bots": self._running(m)
            elif t == "📊 Statistics":
                projs, users = self.db.all_projects(), self.db.all_users()
                b.send_message(m.chat.id, f"📊 <b>Stats</b>\n👥 Users: {len(users)}\n🚀 Projects: {len(projs)}\n🟢 Running: {sum(1 for p in projs if p['status'] == 'running')}\n⏱️ Uptime: {self._uptime()}", parse_mode='HTML')
            elif t == "📊 My Stats":
                ups = self.db.user_projects(m.from_user.id)
                b.send_message(m.chat.id, f"📊 <b>Your Stats</b>\n📁 Projects: {len(ups)}/{self._limit_str(m.from_user.id)}\n🟢 Running: {sum(1 for p in ups if p['status'] == 'running')}\n💳 Premium: {'Yes' if self.db.is_premium(m.from_user.id) else 'No'}", parse_mode='HTML')
            elif t == "💳 Subscriptions":
                if not self.is_admin(m.from_user.id): return
                b.send_message(m.chat.id, "💳 Use:\n/sub <user_id> <days>\n/unsub <user_id>")
            elif t == "📢 Broadcast":
                if not self.is_admin(m.from_user.id): return
                b.reply_to(m, "Send: /broadcast <message>")
            elif t == "🔒 Lock Bot":
                if not self.is_admin(m.from_user.id): return
                self.bot_locked = not self.bot_locked
                b.send_message(m.chat.id, f"🔒 {'Locked' if self.bot_locked else 'Unlocked'}!")
            elif t == "👥 User Management":
                if not self.is_admin(m.from_user.id): return
                b.send_message(m.chat.id, f"👥 Users: {len(self.db.all_users())}\nUse /ban <id> /unban <id>")
            elif t == "📋 Pending Files":
                if not self.is_admin(m.from_user.id): return
                self._pending(m)
            elif t == "👑 Admin Panel":
                if not self.is_admin(m.from_user.id): return
                b.send_message(m.chat.id, "👑 <b>Admin</b>\n/sub <id> <days> • /unsub <id>\n/ban <id> • /unban <id>\n/limit <id> <n> • /broadcast <msg>\n/lock", parse_mode='HTML')
            elif t == "📢 Channel":
                b.send_message(m.chat.id, f"📢 <b>Channel:</b> {self.cfg.UPDATES_CHANNEL}", parse_mode='HTML')
            elif t == "📞 Contact":
                b.send_message(m.chat.id, f"📞 <b>Contact:</b> {self.cfg.YOUR_USERNAME}", parse_mode='HTML')
            else:
                b.reply_to(m, "Use buttons below 👇", reply_markup=self._kb(m.from_user.id))

        @b.message_handler(content_types=['document'])
        def upload(m):
            self.db.touch_user(m.from_user.id, m.from_user.username)
            if self._ban_check(m): return
            if not self._join_check(m): return
            if self.bot_locked and not self.is_admin(m.from_user.id):
                return b.reply_to(m, "🔒 Bot locked.")
            self._handle_upload(m)

        @b.callback_query_handler(func=lambda c: True)
        def cb(c):
            data, uid, cid = c.data, c.from_user.id, c.message.chat.id
            try:
                if data == 'joined':
                    b.delete_message(cid, c.message.message_id)
                    self._spinner(cid, "Checking...", 1)
                    b.send_message(cid, f"🤖 <b>WELCOME!</b>\n👋 Hi, <b>{c.from_user.first_name}</b>!\n📁 Files: {self.db.project_count(uid)}/{self._limit_str(uid)}", parse_mode='HTML', reply_markup=self._kb(uid))
                elif data.startswith('run_'):
                    self._run(cid, data[4:])
                elif data.startswith('stop_'):
                    self.pm.stop(data[5:]); b.answer_callback_query(c.id, "🛑 Stopped")
                    self._list_projects_from_cb(cid, uid)
                elif data.startswith('restart_'):
                    pid2 = data[8:]; p = self.db.get_project(pid2)
                    if p:
                        self.pm.stop(pid2)
                        self.db.update_project(pid2, stopped_by_user=0, rate_limited=0)
                        np2, err = self.pm.start(p)
                        if np2: self.db.update_project(pid2, status='running', pid=np2, started_at=datetime.now().isoformat())
                        b.answer_callback_query(c.id, "🔄 Restarted")
                    self._list_projects_from_cb(cid, uid)
                elif data.startswith('logs_'):
                    p = self.db.get_project(data[5:])
                    if p:
                        f = self.pm.project_dir(p['project_id']) / 'output.log'
                        logs = f.read_text(encoding='utf-8', errors='replace')[-1500:] if f.exists() else 'No logs yet'
                        b.send_message(cid, f"📋 <code>{logs}</code>", parse_mode='HTML')
                elif data.startswith('del_'):
                    p = self.db.get_project(data[4:])
                    if p:
                        self.pm.stop(p['project_id'])
                        shutil.rmtree(self.pm.project_dir(p['project_id']), ignore_errors=True)
                        self.db.delete_project(p['project_id'])
                        b.answer_callback_query(c.id, "🗑️ Deleted")
                    self._list_projects_from_cb(cid, uid)
                elif data.startswith('approve_'):
                    self._approve(cid, data[8:])
                elif data.startswith('reject_'):
                    name = data[7:]
                    for p in self.db.all_pending():
                        if p['project_name'] == name:
                            if os.path.exists(p.get('file_path') or ''): os.remove(p['file_path'])
                            self.db.remove_pending(name); break
                    b.answer_callback_query(c.id, "❌ Rejected")
                    self._pending_from_cb(cid, uid)
            except Exception as e:
                self.logger.error(f"CB error: {e}")

        @b.message_handler(commands=['help'])
        def help(m):
            b.send_message(m.chat.id,
                "📚 <b>Commands</b>\n/start • /help\n/stats • /speed\n"
                "/running • /lock (admin)\n"
                "/sub <id> <days> (admin)\n/ban <id> • /unban <id>\n"
                "/limit <id> <n> • /broadcast <msg>", parse_mode='HTML')

    # ── listing ──
    def _list_projects(self, m):
        self._list_projects_from_cb(m.chat.id, m.from_user.id)

    def _list_projects_from_cb(self, cid, uid):
        projs = self.db.user_projects(uid)
        if not projs:
            return self.bot.send_message(cid, "📂 No projects yet. Upload a file!")
        for p in projs:
            kb = types.InlineKeyboardMarkup(row_width=2)
            running = p['status'] == 'running'
            kb.add(types.InlineKeyboardButton("🛑 Stop" if running else "▶️ Run",
                                              callback_data=f"stop_{p['project_id']}" if running else f"run_{p['project_id']}"))
            kb.add(types.InlineKeyboardButton("🔄", callback_data=f"restart_{p['project_id']}"),
                   types.InlineKeyboardButton("📋", callback_data=f"logs_{p['project_id']}"))
            kb.add(types.InlineKeyboardButton("🗑️", callback_data=f"del_{p['project_id']}"))
            txt = (f"📦 <b>{p['project_name']}</b> ({p['file_type']})\n"
                   f"🆔 {p['project_id']} • 📄 {p['main_file']}\n"
                   f"📈 <b>{'🟢 Running' if running else '🔴 Stopped'}</b>")
            if running and p.get('pid'):
                s = self.pm.process_stats(p['pid'])
                txt += f"\n💻 CPU: {s['cpu']} • RAM: {s['ram']}"
            self.bot.send_message(cid, txt, parse_mode='HTML', reply_markup=kb)

    def _running(self, m, all_users=False):
        self._spinner(m.chat.id, "Fetching...", 1)
        projs = self.db.all_projects() if all_users else self.db.user_projects(m.from_user.id)
        running = [p for p in projs if p['status'] == 'running']
        if not running: return self.bot.send_message(m.chat.id, "🔴 No bots running.")
        self.bot.send_message(m.chat.id,
            "🟢 <b>RUNNING BOTS</b>\n" + '\n'.join(
                f"• {p['project_name']} (PID {p.get('pid', 'N/A')}) • {self.pm.uptime_str(p.get('started_at'))}"
                for p in running), parse_mode='HTML')

    # ── pending ──
    def _pending(self, m): self._pending_from_cb(m.chat.id, m.from_user.id)

    def _pending_from_cb(self, cid, uid):
        pend = self.db.all_pending()
        if not pend: return self.bot.send_message(cid, "📋 No pending files.")
        for p in pend:
            kb = types.InlineKeyboardMarkup()
            kb.add(types.InlineKeyboardButton("✅ Approve", callback_data=f"approve_{p['project_name']}"),
                   types.InlineKeyboardButton("❌ Reject", callback_data=f"reject_{p['project_name']}"))
            self.bot.send_message(cid,
                f"📋 <b>{p['project_name']}</b> ({p['file_type']})\n👤 {p['owner_id']}\n"
                f"🔒 <b>{'Safe' if p['is_safe'] else '⚠️ ' + (p.get('security_msg') or '')}</b>",
                parse_mode='HTML', reply_markup=kb)

    def _approve(self, cid, name):
        match = next((x for x in self.db.all_pending() if x['project_name'] == name), None)
        if not match: return self.bot.send_message(cid, "❌ Not found")
        (fpath, ftype) = (match.get('file_path'), match.get('file_type', 'py'))
        if ftype == 'zip' and fpath and os.path.exists(fpath):
            proj = self.db.create_project(match['owner_id'], name, main_file='main.py', file_type='py')
            with zipfile.ZipFile(fpath) as zf: zf.extractall(self.pm.project_dir(proj['project_id']))
        elif fpath and os.path.exists(fpath):
            proj = self.db.get_user_project(match['owner_id'], name) or \
                   self.db.create_project(match['owner_id'], name, main_file=os.path.basename(fpath), file_type=ftype)
            shutil.copy(fpath, self.pm.project_dir(proj['project_id']) / os.path.basename(fpath))
        try:
            if fpath and os.path.exists(fpath): os.remove(fpath)
        except Exception: pass
        self.db.remove_pending(name)
        self.bot.send_message(cid, f"✅ Approved: <b>{name}</b>!", parse_mode='HTML')
        self.bot.send_message(match['owner_id'], f"✅ <b>{name}</b> approved! Use 📂 Check Files to run it.", parse_mode='HTML')

    # ── upload ──
    def _handle_upload(self, m):
        uid = m.from_user.id
        if self.db.project_count(uid) >= self.db.get_file_limit(uid):
            return self.bot.send_message(m.chat.id, f"❌ Limit reached ({self._limit_str(uid)}).")
        fi, fname = m.document, (m.document.file_name or 'main.py')
        if not fname.endswith(('.py', '.zip', '.txt', '.json', '.env')):
            return self.bot.send_message(m.chat.id, f"❌ Unsupported: {fname}")
        if fi.file_size and fi.file_size > self.cfg.MAX_FILE_BYTES:
            return self.bot.send_message(m.chat.id, f"❌ Too large (max {self.cfg.MAX_UPLOAD_MB}MB).")
        self._spinner(m.chat.id, "Downloading...", 1)
        try:
            fpath = self.cfg.PENDING_DIR / fname
            dl = self.bot.get_file(fi.file_id)
            fpath.write_bytes(self.bot.download_file(dl.file_path))
        except Exception as e:
            return self.bot.send_message(m.chat.id, f"❌ Download failed: {e}")
        # security scan
        is_safe, sec_msg = True, "✅ Safe"
        if fname.endswith('.py'):
            try: is_safe, sec_msg = self.pm.scan_code(fpath.read_text(encoding='utf-8', errors='replace'))
            except Exception: pass
        base = os.path.splitext(fname)[0][:30]
        proj = self.db.get_user_project(uid, base)
        if proj:
            try: fpath.unlink()
            except Exception: pass
            return self.bot.send_message(m.chat.id, f"❌ Project <b>{base}</b> already exists.", parse_mode='HTML')
        if fname.endswith('.zip'):
            self.db.add_pending(uid, base, str(fpath), 'zip', is_safe, sec_msg, chat_id=m.chat.id)
            self.bot.send_message(m.chat.id, f"📦 <b>{base}</b> queued for approval!\n🔒 Security: {sec_msg}\n⏳ You'll be notified.", parse_mode='HTML')
            for a in self.cfg.ADMIN_IDS:
                try: self.bot.send_message(a, f"📋 Pending: <b>{base}</b> from {uid}")
                except Exception: pass
            return
        proj = self.db.create_project(uid, base, main_file=fname, file_type='py')
        shutil.copy(fpath, self.pm.project_dir(proj['project_id']) / fname)
        try: fpath.unlink()
        except Exception: pass
        self.bot.send_message(m.chat.id, f"✅ Uploaded <b>{fname}</b> → <b>{base}</b>!\n📂 Check Files to run it.", parse_mode='HTML')
        self.db.log(uid, 'UPLOAD', fname)

    def _run(self, cid, pid2):
        p = self.db.get_project(pid2)
        if not p: return self.bot.send_message(cid, "❌ Not found.")
        if p['status'] == 'running': return self.bot.send_message(cid, "⚠️ Already running.")
        self.db.update_project(pid2, stopped_by_user=0, rate_limited=0)
        np2, err = self.pm.start(p)
        if np2:
            self.db.update_project(pid2, status='running', pid=np2, started_at=datetime.now().isoformat())
            self.bot.send_message(cid, f"✅ <b>{p['project_name']}</b> started! (PID {np2})", parse_mode='HTML')
        else:
            self.bot.send_message(cid, f"❌ Failed: {err}")

    # ── public ──
    def start_polling(self):
        self.logger.info("🤖 Telegram bot polling...")
        while True:
            try:
                self.bot.infinity_polling(timeout=self.cfg.POLLING_TIMEOUT,
                                          long_polling_timeout=self.cfg.LONG_POLLING_TIMEOUT)
            except Exception as e:
                self.logger.error(f"Polling error: {e}; retry in 5s...")
                time.sleep(5)