#!/usr/bin/env python3
"""Web Panel — Flask control panel for hosted bots + users."""
import os, json, zipfile, shutil
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify

from config import Config
from database import Database
from process_manager import ProcessManager

TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')


def create_web_panel(cfg: Config, db: Database, pm: ProcessManager):
    app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=TEMPLATE_DIR)
    app.secret_key = cfg.WEB_SECRET
    app.config['MAX_CONTENT_LENGTH'] = cfg.MAX_FILE_BYTES

    SITE_CTX = {'site_name': cfg.SITE_NAME, 'contact_url': cfg.CONTACT_URL}

    # ── Public pages ──
    @app.route('/')
    def index():
        return render_template('landing.html', **SITE_CTX)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            u, p = request.form.get('username', ''), request.form.get('password', '')
            if (u == 'admin' and p == cfg.WEB_ADMIN_PASSWORD) or u == str(cfg.OWNER_ID):
                session['user'], session['role'] = u, 'admin'
                return redirect(url_for('admin'))
            return render_template('login.html', error='Invalid credentials!', **SITE_CTX)
        return render_template('login.html', error=None, **SITE_CTX)

    @app.route('/logout')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.route('/admin')
    def admin():
        if session.get('role') != 'admin':
            return redirect(url_for('login'))
        projects = db.all_projects()
        return render_template('admin.html', projects=projects, users=db.all_users(),
                               total_servers=len(projects),
                               total_running=sum(1 for p in projects if p['status'] == 'running'),
                               **SITE_CTX)

    def admin_ok():
        return session.get('role') == 'admin'

    # ── Admin API ──
    @app.route('/api/admin/create', methods=['POST'])
    def admin_create():
        if not admin_ok():
            return jsonify({'error': 'Unauthorized'}), 403
        d = request.get_json()
        name = d.get('project_name', '').strip()
        if not name:
            return jsonify({'error': 'Project name required!'}), 400
        proj = db.create_project(int(d.get('owner_id', cfg.OWNER_ID)), name,
                                 main_file=d.get('main_file', 'main.py'),
                                 file_type=d.get('file_type', 'py'),
                                 cpu_limit=int(d.get('cpu_limit', 80)),
                                 expiry_days=int(d.get('expiry_days', 3)))
        pm.write_default_files(proj['project_id'])
        return jsonify({'success': True, 'project': proj})

    @app.route('/api/admin/delete/<pid>', methods=['POST'])
    def admin_delete(pid):
        if not admin_ok():
            return jsonify({'error': 'Unauthorized'}), 403
        pm.stop(pid)
        shutil.rmtree(pm.project_dir(pid), ignore_errors=True)
        db.delete_project(pid)
        return jsonify({'success': True})

    @app.route('/api/admin/subscribe', methods=['POST'])
    def admin_subscribe():
        if not admin_ok():
            return jsonify({'error': 'Unauthorized'}), 403
        d = request.get_json()
        exp = db.set_subscription(int(d['user_id']), int(d.get('days', 30)))
        return jsonify({'success': True, 'expiry': exp.isoformat()})

    @app.route('/api/admin/ban', methods=['POST'])
    def admin_ban():
        if not admin_ok():
            return jsonify({'error': 'Unauthorized'}), 403
        d = request.get_json()
        (db.ban_user if d.get('action') == 'ban' else db.unban_user)(int(d['user_id']))
        return jsonify({'success': True})

    @app.route('/api/admin/cpu/<pid>', methods=['POST'])
    def admin_cpu(pid):
        if not admin_ok():
            return jsonify({'error': 'Unauthorized'}), 403
        val = int(request.get_json().get('cpu_limit', 80))
        db.update_project(pid, cpu_limit=val)
        return jsonify({'success': True, 'cpu_limit': val})

    # ── Project operations ──
    @app.route('/api/project/<pid>/start', methods=['POST'])
    def start_project(pid):
        p = db.get_project(pid)
        if not p:
            return jsonify({'error': 'Not found'}), 404
        if p['status'] == 'running':
            return jsonify({'error': 'Already running'}), 400
        pm.stop(pid)
        db.update_project(pid, stopped_by_user=0, rate_limited=0)
        new_pid, err = pm.start(p)
        if new_pid:
            db.update_project(pid, status='running', pid=new_pid,
                              started_at=datetime.now().isoformat())
            return jsonify({'success': True, 'pid': new_pid})
        return jsonify({'error': err or 'Failed'}), 500

    @app.route('/api/project/<pid>/stop', methods=['POST'])
    def stop_project(pid):
        pm.stop(pid)
        return jsonify({'success': True})

    @app.route('/api/project/<pid>/logs')
    def project_logs(pid):
        f = pm.project_dir(pid) / 'output.log'
        return jsonify({'logs': f.read_text(encoding='utf-8', errors='replace')[-5000:]
                        if f.exists() else ''})

    @app.route('/api/project/<pid>/stats')
    def project_stats(pid):
        p = db.get_project(pid)
        if not p:
            return jsonify({'cpu': '0%', 'ram': '0 MB', 'uptime': '0h'})
        s = pm.process_stats(p['pid']) if p.get('pid') else {}
        return jsonify(status=p['status'], cpu=s.get('cpu', '0%'), ram=s.get('ram', '0 MB'),
                       uptime=pm.uptime_str(p.get('started_at')),
                       net_in=s.get('net_in', '0 KB'), net_out=s.get('net_out', '0 KB'))

    @app.route('/api/project/<pid>/files')
    def project_files(pid):
        base = pm.project_dir(pid)
        fld = request.args.get('folder', '')
        target = base / fld if fld else base
        if not str(target.resolve()).startswith(str(base.resolve())):
            return jsonify({'files': []})
        files = []
        if target.exists():
            for item in target.iterdir():
                files.append({'name': item.name, 'is_dir': item.is_dir(),
                              'size': item.stat().st_size if item.is_file() else 0,
                              'modified': datetime.fromtimestamp(item.stat().st_mtime)
                              .strftime('%Y-%m-%d %H:%M')})
        return jsonify({'files': files})

    @app.route('/api/project/<pid>/file', methods=['GET', 'POST', 'DELETE'])
    def project_file(pid):
        base = pm.project_dir(pid)
        if request.method == 'GET':
            fp = base / request.args.get('filename', '')
            return jsonify({'content': fp.read_text(encoding='utf-8', errors='replace')}
                           if fp.is_file() else {'error': 'Not found'}), (200 if fp.is_file() else 404)
        if request.method == 'POST':
            d = request.get_json()
            fp = base / d.get('filename', '')
            fp.parent.mkdir(parents=True, exist_ok=True)
            fp.write_text(d.get('content', ''), encoding='utf-8')
            return jsonify({'success': True})
        d = request.get_json()
        fp = base / d.get('filename', '')
        if fp.exists():
            shutil.rmtree(fp) if fp.is_dir() else fp.unlink()
        return jsonify({'success': True})

    @app.route('/api/project/<pid>/struct', methods=['GET', 'POST'])
    def project_struct(pid):
        if request.method == 'GET':
            p = db.get_project(pid)
            return jsonify(main_file=(p or {}).get('main_file', 'main.py'),
                           requirements=(p or {}).get('requirements', 'requirements.txt'))
        d = request.get_json()
        db.update_project(pid, main_file=d.get('main_file', 'main.py'),
                          requirements=d.get('requirements'))
        return jsonify({'success': True})

    @app.route('/api/project/<pid>/upload', methods=['POST'])
    def project_upload(pid):
        if 'file' not in request.files:
            return jsonify({'error': 'No file'}), 400
        fld = request.form.get('folder', '')
        target = pm.project_dir(pid)
        if fld:
            target = target / fld
            target.mkdir(parents=True, exist_ok=True)
        request.files['file'].save(os.path.join(target, request.files['file'].filename))
        return jsonify({'success': True})

    @app.route('/api/project/<pid>/unzip', methods=['POST'])
    def project_unzip(pid):
        d = request.get_json()
        zp = pm.project_dir(pid) / d.get('filename', '')
        if zp.exists() and zp.suffix == '.zip':
            try:
                with zipfile.ZipFile(zp) as zf:
                    zf.extractall(zp.parent)
                return jsonify({'success': True})
            except Exception as e:
                return jsonify({'error': str(e)}), 400
        return jsonify({'error': 'Invalid zip'}), 400

    @app.route('/api/health')
    def health():
        return jsonify(status='ok', time=datetime.now().isoformat(),
                       projects=len(db.all_projects()))

    # Attach a `run` method so the same object works for local & serverless
    def run():
        app.run(host=cfg.WEB_HOST, port=cfg.WEB_PORT, debug=False, use_reloader=False)
    app.run_server = run
    return app


# ── Vercel serverless entry ─────────────────────────────────────
# Exposes the Flask app directly for Vercel's Python runtime.
# In serverless mode, the DB / uploads live in /tmp (see config.py).
try:
    cfg = Config()
    db = Database(Config)
    db.initialize()
    db.load_state()
    _pm = ProcessManager(Config, db, None)
    app = create_web_panel(cfg, db, _pm)
except Exception:
    app = Flask(__name__)
