# Professional Hosting Platform

A production-ready, combined **Telegram Bot Hoster + Web Control Panel** for hosting Python bots/scripts. Merged and optimized from multiple source examples into a clean, modular, professional codebase.

---

## ✨ Features

### Telegram Bot (User-facing)
- **Upload & Deploy** — Send `.py` or `.zip` files, auto-extract & run
- **Security Scanning** — Blocks dangerous patterns (`os.system`, `eval`, `exec`, etc.)
- **Project Management** — Start/Stop/Restart/Logs/Delete via inline buttons
- **Live Stats** — CPU, RAM, Network, Uptime per project
- **Force-Join Channels** — Require channel membership before use
- **Tiered Limits** — Free / Premium / Admin / Owner file limits
- **Subscriptions** — Time-based premium access (admin controlled)
- **Broadcast** — Admin can message all users
- **Auto-Restart** — Smart crash recovery with cooldown & max-retries
- **CPU Protection** — Per-project CPU limit enforcement with auto-stop

### Web Control Panel (Admin-facing)
- **Dashboard** — Overview of all projects, users, running count
- **Project Control** — Start/Stop/Restart/Delete, CPU limit, logs, stats
- **File Manager** — Browse, edit, upload, create folders, unzip
- **Startup Config** — Set main file & requirements per project
- **User Management** — Ban/Unban, subscriptions, custom file limits
- **Responsive UI** — Dark theme, Tailwind + FontAwesome, mobile-friendly
- **Vercel-ready** — Serverless entry point included

---

## 🏗 Architecture

```
├── main.py                 # Entry point — starts web panel + bot
├── config.py               # All configuration (env-only, no hardcoded secrets)
├── database.py             # SQLite layer (thread-safe, WAL mode)
├── process_manager.py      # Process lifecycle, monitoring, security scan
├── bot_manager.py          # Telegram bot handlers (telebot)
├── web_panel.py            # Flask web panel (admin + API)
├── requirements.txt        # Python dependencies
├── .env.example            # Configuration template
├── .gitignore              # Excludes secrets, data, logs, __pycache__
├── templates/              # Jinja2 templates
│   ├── landing.html        # Public landing page
│   ├── login.html          # Admin login
│   ├── admin.html          # Admin dashboard
│   ├── home.html           # User project panel
│   └── error.html          # Expired/deleted server pages
└── data/                   # Runtime data (created at runtime)
    ├── hosting.db          # SQLite database
    ├── projects/           # Project directories (code + logs)
    └── pending/            # Pending uploads awaiting approval
```

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd HOSTING-BOT
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Linux/macOS
pip install -r requirements.txt
```

### 2. Configure

```bash
copy .env.example .env         # Windows
# cp .env.example .env         # Linux/macOS
```

Edit `.env` with **your values** (see [Configuration](#configuration) below).

### 3. Run

```bash
python main.py
```

- **Web Panel**: `http://localhost:8080` (or `WEB_PORT`)
- **Admin Login**: `http://localhost:8080/login` (user: `admin`, pass: `WEB_ADMIN_PASSWORD`)
- **Telegram Bot**: Starts polling automatically

---

## ⚙️ Configuration

All settings are **environment variables only** — no hardcoded secrets.

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `BOT_TOKEN` | ✅ Yes | — | Telegram bot token from @BotFather |
| `OWNER_ID` | ✅ Yes | — | Your numeric Telegram user ID |
| `ADMIN_IDS` | No | `""` | Comma-separated extra admin IDs |
| `YOUR_USERNAME` | No | `""` | Shown in "Contact" button |
| `UPDATES_CHANNEL` | No | `""` | Link for "Updates Channel" button |
| `SITE_NAME` | No | `Hosting Platform` | Brand name in templates |
| `CONTACT_URL` | No | `""` | "Contact Admin" link on error pages |
| `WEB_ADMIN_PASSWORD` | No | `admin` | Admin panel login password |
| `WEB_SECRET` | No | `hosting-secret-key-change-me` | Flask session secret |
| `WEB_HOST` | No | `0.0.0.0` | Web panel bind address |
| `WEB_PORT` | No | `8080` | Web panel port |
| `MAX_UPLOAD_MB` | No | `50` | Max upload size (MB) |
| `FREE_USER_LIMIT` | No | `3` | Free tier project limit |
| `SUBSCRIBED_USER_LIMIT` | No | `15` | Premium tier project limit |
| `ADMIN_LIMIT` | No | `999` | Admin project limit |
| `DEFAULT_CPU_LIMIT` | No | `80` | Default CPU % limit per project |
| `AUTO_RESTART_MAX` | No | `3` | Max auto-restarts before giving up |
| `RESTART_COOLDOWN_SEC` | No | `60` | Seconds between auto-restarts |
| `DATA_DIR` | No | `./data` | Runtime data directory |
| `PORT` | No | `8080` | For Render/Railway (maps to WEB_PORT) |

### Getting Your IDs

- **BOT_TOKEN**: Message @BotFather → `/newbot` → copy token
- **OWNER_ID**: Message @userinfobot → copy your numeric ID
- **ADMIN_IDS**: Same way, get IDs of trusted admins

---

## 🌐 Deployment

### Local / VPS (systemd)

```ini
# /etc/systemd/system/hosting-bot.service
[Unit]
Description=Professional Hosting Platform
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/opt/hosting-bot
EnvironmentFile=/opt/hosting-bot/.env
ExecStart=/opt/hosting-bot/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now hosting-bot
```

### Render / Railway / Fly.io

1. Create a new **Web Service**
2. Set **Build Command**: `pip install -r requirements.txt`
3. Set **Start Command**: `python main.py`
4. Add all env vars from `.env` in the dashboard
5. Set `PORT` (provided automatically) — maps to `WEB_PORT`

### Vercel (Serverless Web Panel Only)

The `web_panel.py` exposes a serverless-compatible `app` at module level.

1. Push to GitHub
2. Import in Vercel → Framework: **Other**
3. Add env vars in Vercel dashboard
4. Deploy — the web panel works; **Telegram bot must run separately** (VPS/Render worker)

---

## 📖 Usage Guide

### For Users (Telegram)

1. **Start** — `/start` shows main menu with file limits
2. **Upload** — Press "📤 Upload File" → send `.py` or `.zip`
3. **Manage** — "📂 Check Files" → inline buttons: ▶️ Run / 🛑 Stop / 🔄 Restart / 📋 Logs / 🗑️ Delete
4. **Stats** — "📊 My Stats" or `/stats` for system overview
5. **Channel** — "📢 Channel" for updates (if configured)

### For Admins (Telegram)

- **Approve/Reject** — Pending `.zip` uploads appear with ✅/❌ buttons
- **Commands**:
  - `/sub <user_id> <days>` — Grant premium
  - `/unsub <user_id>` — Remove premium
  - `/ban <user_id> [reason]` — Ban user
  - `/unban <user_id>` — Unban
  - `/limit <user_id> <n>` — Custom file limit
  - `/broadcast <message>` — Message all users
  - `/lock` — Toggle bot lock (blocks uploads)
  - `/stats` — System stats
  - `/speed` — Latency test

### For Admins (Web Panel)

1. Open `http://your-domain/login`
2. Login: `admin` / `WEB_ADMIN_PASSWORD`
3. **Dashboard** — All projects, users, running count
4. **Projects Table** — Start/Stop/Logs/Delete, inline CPU limit edit
5. **Users Table** — Ban/Unban, +30d subscription
6. **Project Detail** (click project) — File manager, startup config, live stats, console

---

## 🔒 Security

- **No hardcoded secrets** — All via env vars
- **Code scanning** — Blocks `os.system`, `subprocess`, `eval`, `exec`, path traversal
- **Process isolation** — Each project runs in its own directory, killed on stop
- **CPU enforcement** — Rolling average, auto-kill on exceed
- **Path traversal protection** — File API validates paths stay in project dir
- **Admin-only endpoints** — Session-based, role-checked
- **WAL-mode SQLite** — Concurrent reads, safe writes

---

## 🛠 Development

### Project Structure

```
main.py              # Composition root
config.py            # Single source of truth for config
database.py          # All DB operations (thread-safe)
process_manager.py   # Process lifecycle + monitoring
bot_manager.py       # Telegram bot (telebot)
web_panel.py         # Flask app + API routes
templates/           # Jinja2 templates (config-driven)
```

### Adding Features

1. **New DB table** → `database.py` `initialize()` + methods
2. **New bot command** → `bot_manager.py` `_reg()` handler
3. **New web API** → `web_panel.py` route + template if needed
4. **New config** → `config.py` `Config` class + `.env.example`

### Running Tests

```bash
# No formal test suite yet — manual verification:
python -c "from config import Config; print('Config OK')"
python -c "from database import Database; from config import Config; db=Database(Config); db.initialize(); print('DB OK')"
```

---

## 📝 License

MIT License — Use freely, modify, distribute. Attribution appreciated.

---

## 🙏 Credits

Built by merging and optimizing multiple hosting bot examples into a single, professional, maintainable codebase. All hardcoded credentials removed; configuration is 100% environment-driven.

---

## 🆘 Troubleshooting

| Issue | Fix |
|-------|-----|
| `RuntimeError: MISSING ENVIRONMENT VARIABLE` | Create `.env` with `BOT_TOKEN` and `OWNER_ID` |
| `ModuleNotFoundError` | `pip install -r requirements.txt` |
| Bot doesn't respond | Check `BOT_TOKEN` valid, bot not blocked, polling started |
| Web panel 500 | Check logs, ensure `WEB_SECRET` set, DB writable |
| Upload fails | Check `MAX_UPLOAD_MB`, disk space, file extension allowed |
| Auto-restart not working | Check `AUTO_RESTART_MAX`, `RESTART_COOLDOWN_SEC`, project not `stopped_by_user` |

---

**Happy Hosting! 🚀**