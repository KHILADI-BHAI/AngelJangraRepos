#!/usr/bin/env python3
"""Database layer — SQLite, thread-safe, shared by web panel + Telegram bot."""
import json
import sqlite3
import threading
import uuid
from datetime import datetime, timedelta

from config import Config


class Database:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._lock = threading.RLock()
        cfg.ensure_dirs()
        self.conn = sqlite3.connect(str(cfg.DB_PATH), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")

    def initialize(self):
        with self._lock:
            c = self.conn.cursor()
            c.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY, username TEXT, role TEXT DEFAULT 'user',
                    password TEXT, is_banned INTEGER DEFAULT 0, ban_reason TEXT, created_at TEXT);
                CREATE TABLE IF NOT EXISTS subscriptions (
                    user_id INTEGER PRIMARY KEY, expiry TEXT);
                CREATE TABLE IF NOT EXISTS projects (
                    project_id TEXT PRIMARY KEY, owner_id INTEGER NOT NULL, project_name TEXT NOT NULL,
                    main_file TEXT DEFAULT 'main.py', requirements TEXT DEFAULT 'requirements.txt',
                    file_type TEXT DEFAULT 'py', status TEXT DEFAULT 'stopped', pid INTEGER,
                    cpu_limit INTEGER DEFAULT 80, ram_limit TEXT DEFAULT '512MB', disk_limit TEXT DEFAULT '1GB',
                    started_at TEXT, created_at TEXT, expiry TEXT, rate_limited INTEGER DEFAULT 0,
                    stopped_by_user INTEGER DEFAULT 0, UNIQUE(owner_id, project_name));
                CREATE TABLE IF NOT EXISTS pending_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL, project_name TEXT NOT NULL,
                    file_path TEXT, file_type TEXT, is_safe INTEGER DEFAULT 1, security_msg TEXT,
                    chat_id INTEGER, main_file TEXT, queued_at TEXT);
                CREATE TABLE IF NOT EXISTS user_limits (
                    user_id INTEGER PRIMARY KEY, file_limit INTEGER);
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS force_join (
                    channel TEXT PRIMARY KEY, title TEXT, invite_link TEXT);
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT,
                    details TEXT, timestamp TEXT);
                CREATE TABLE IF NOT EXISTS pending_uploads (
                    user_id INTEGER PRIMARY KEY, data TEXT);
            """)
            self.conn.commit()

    def load_state(self):
        pass

    @staticmethod
    def _now():
        return datetime.now().isoformat()

    # ── Users ──
    def add_user(self, user_id, username=None, role='user', password=None):
        with self._lock:
            self.conn.execute("""
                INSERT INTO users (user_id, username, role, password, created_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET username = excluded.username
            """, (user_id, username, role, password, self._now()))
            self.conn.commit()

    def touch_user(self, user_id, username=None):
        with self._lock:
            self.conn.execute("UPDATE users SET username = COALESCE(?, username) WHERE user_id = ?",
                              (username, user_id))
            if self.conn.total_changes == 0:
                self.conn.execute("INSERT OR IGNORE INTO users (user_id, username, created_at) VALUES (?, ?, ?)",
                                  (user_id, username, self._now()))
                self.conn.commit()

    def get_user(self, user_id):
        with self._lock:
            row = self.conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
            return dict(row) if row else None

    def all_users(self):
        with self._lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM users")]

    def is_admin(self, user_id):
        return user_id in self.cfg.ADMIN_IDS

    def is_banned(self, user_id):
        with self._lock:
            row = self.conn.execute("SELECT is_banned FROM users WHERE user_id = ?", (user_id,)).fetchone()
            return bool(row and row['is_banned'])

    def ban_user(self, user_id, reason=None):
        with self._lock:
            self.conn.execute("""
                INSERT INTO users (user_id, is_banned, ban_reason, created_at) VALUES (?, 1, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET is_banned = 1, ban_reason = excluded.ban_reason
            """, (user_id, reason, self._now()))
            self.conn.commit()

    def unban_user(self, user_id):
        with self._lock:
            self.conn.execute("UPDATE users SET is_banned = 0, ban_reason = NULL WHERE user_id = ?", (user_id,))
            self.conn.commit()

    # ── Subscriptions ──
    def set_subscription(self, user_id, days):
        expiry = datetime.now() + timedelta(days=days)
        with self._lock:
            self.conn.execute("""
                INSERT INTO subscriptions (user_id, expiry) VALUES (?, ?)
                ON CONFLICT(user_id) DO UPDATE SET expiry = excluded.expiry
            """, (user_id, expiry.isoformat()))
            self.conn.commit()
        return expiry

    def remove_subscription(self, user_id):
        with self._lock:
            self.conn.execute("DELETE FROM subscriptions WHERE user_id = ?", (user_id,))
            self.conn.commit()

    def get_subscription(self, user_id):
        with self._lock:
            row = self.conn.execute("SELECT expiry FROM subscriptions WHERE user_id = ?", (user_id,)).fetchone()
            if not row:
                return None
            try:
                return datetime.fromisoformat(row['expiry'])
            except ValueError:
                return None

    def is_premium(self, user_id):
        exp = self.get_subscription(user_id)
        return exp is not None and exp > datetime.now()

    # ── File limits ──
    def get_file_limit(self, user_id):
        if user_id == self.cfg.OWNER_ID:
            return self.cfg.OWNER_LIMIT
        if user_id in self.cfg.ADMIN_IDS:
            return self.cfg.ADMIN_LIMIT
        if self.is_premium(user_id):
            return self.cfg.SUBSCRIBED_USER_LIMIT
        with self._lock:
            row = self.conn.execute("SELECT file_limit FROM user_limits WHERE user_id = ?", (user_id,)).fetchone()
            if row:
                return row['file_limit']
        return self.cfg.FREE_USER_LIMIT

    def set_file_limit(self, user_id, limit):
        with self._lock:
            self.conn.execute("""
                INSERT INTO user_limits (user_id, file_limit) VALUES (?, ?)
                ON CONFLICT(user_id) DO UPDATE SET file_limit = excluded.file_limit
            """, (user_id, limit))
            self.conn.commit()

    def remove_file_limit(self, user_id):
        with self._lock:
            self.conn.execute("DELETE FROM user_limits WHERE user_id = ?", (user_id,))
            self.conn.commit()

    # ── Projects ──
    def create_project(self, owner_id, project_name, main_file='main.py', file_type='py',
                       cpu_limit=None, expiry_days=None):
        with self._lock:
            c = self.conn.cursor()
            pid = uuid.uuid4().hex[:8]
            c.execute("""
                INSERT INTO projects (project_id, owner_id, project_name, main_file, file_type,
                                      cpu_limit, created_at, expiry)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (pid, owner_id, project_name, main_file, file_type,
                  cpu_limit or self.cfg.DEFAULT_CPU_LIMIT, self._now(),
                  (datetime.now() + timedelta(days=expiry_days or 3)).isoformat()))
            self.conn.commit()
            return dict(c.execute("SELECT * FROM projects WHERE project_id = ?", (pid,)).fetchone())

    def get_project(self, project_id):
        with self._lock:
            row = self.conn.execute("SELECT * FROM projects WHERE project_id = ?", (project_id,)).fetchone()
            return dict(row) if row else None

    def get_user_project(self, owner_id, project_name):
        with self._lock:
            row = self.conn.execute("SELECT * FROM projects WHERE owner_id = ? AND project_name = ?",
                                    (owner_id, project_name)).fetchone()
            return dict(row) if row else None

    def user_projects(self, owner_id):
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM projects WHERE owner_id = ?", (owner_id,))]

    def project_count(self, owner_id):
        with self._lock:
            return self.conn.execute("SELECT COUNT(*) AS n FROM projects WHERE owner_id = ?",
                                     (owner_id,)).fetchone()['n']

    def update_project(self, project_id, **fields):
        allowed = {'main_file', 'requirements', 'status', 'pid', 'cpu_limit',
                   'started_at', 'expiry', 'rate_limited', 'stopped_by_user', 'file_type'}
        sets, vals = [], []
        for k, v in fields.items():
            if k in allowed:
                sets.append(f"{k} = ?")
                vals.append(v)
        if sets:
            vals.append(project_id)
            with self._lock:
                self.conn.execute(f"UPDATE projects SET {', '.join(sets)} WHERE project_id = ?", vals)
                self.conn.commit()

    def all_projects(self):
        with self._lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM projects")]

    def delete_project(self, project_id):
        with self._lock:
            self.conn.execute("DELETE FROM projects WHERE project_id = ?", (project_id,))
            self.conn.commit()

    # ── Pending files ──
    def add_pending(self, owner_id, project_name, file_path, file_type, is_safe,
                    security_msg, main_file=None, chat_id=None):
        with self._lock:
            self.conn.execute("""
                INSERT INTO pending_files (owner_id, project_name, file_path, file_type, is_safe,
                                           security_msg, chat_id, main_file, queued_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (owner_id, project_name, file_path, file_type, int(is_safe),
                  security_msg, chat_id, main_file, self._now()))
            self.conn.commit()

    def pending_for_user(self, owner_id):
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM pending_files WHERE owner_id = ?", (owner_id,))]

    def all_pending(self):
        with self._lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM pending_files")]

    def remove_pending(self, project_name):
        with self._lock:
            self.conn.execute("DELETE FROM pending_files WHERE project_name = ?", (project_name,))
            self.conn.commit()

    # ── Settings ──
    def set_setting(self, key, value):
        with self._lock:
            self.conn.execute("""
                INSERT INTO settings (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """, (key, value))
            self.conn.commit()

    def get_setting(self, key, default=None):
        with self._lock:
            row = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
            return row['value'] if row else default

    # ── Force-join channels ──
    def add_force_channel(self, channel, title, invite_link=None):
        with self._lock:
            self.conn.execute("""
                INSERT INTO force_join (channel, title, invite_link) VALUES (?, ?, ?)
                ON CONFLICT(channel) DO UPDATE SET title = excluded.title, invite_link = excluded.invite_link
            """, (channel, title, invite_link))
            self.conn.commit()

    def remove_force_channel(self, channel):
        with self._lock:
            self.conn.execute("DELETE FROM force_join WHERE channel = ?", (channel,))
            self.conn.commit()

    def force_channels(self):
        with self._lock:
            return [dict(r) for r in self.conn.execute("SELECT * FROM force_join")]

    # ── Activity log ──
    def log(self, user_id, action, details=''):
        with self._lock:
            self.conn.execute("""
                INSERT INTO activity_log (user_id, action, details, timestamp) VALUES (?, ?, ?, ?)
            """, (user_id, action, details, self._now()))
            self.conn.commit()

    def recent_logs(self, limit=50):
        with self._lock:
            return [dict(r) for r in self.conn.execute(
                "SELECT * FROM activity_log ORDER BY id DESC LIMIT ?", (limit,))]

    # ── Pending uploads (multi-step state) ──
    def save_pending_upload(self, user_id, data):
        with self._lock:
            self.conn.execute("""
                INSERT INTO pending_uploads (user_id, data) VALUES (?, ?)
                ON CONFLICT(user_id) DO UPDATE SET data = excluded.data
            """, (user_id, json.dumps(data)))
            self.conn.commit()

    def get_pending_upload(self, user_id):
        with self._lock:
            row = self.conn.execute("SELECT data FROM pending_uploads WHERE user_id = ?", (user_id,)).fetchone()
            if row:
                try:
                    return json.loads(row['data'])
                except json.JSONDecodeError:
                    return None
            return None

    def clear_pending_upload(self, user_id):
        with self._lock:
            self.conn.execute("DELETE FROM pending_uploads WHERE user_id = ?", (user_id,))
            self.conn.commit()

    def close(self):
        with self._lock:
            self.conn.close()