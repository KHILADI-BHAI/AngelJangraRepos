#!/usr/bin/env python3
"""Process Manager — run, stop, monitor, auto-restart + security scanning."""
import os, re, sys, time, shutil, subprocess, threading
from datetime import datetime
import psutil
from config import Config
from database import Database


class ProcessManager:
    def __init__(self, cfg: Config, db: Database, logger):
        self.cfg, self.db, self.logger = cfg, db, logger
        self.cpu_history, self.crash_count = {}, {}

    # ── Security ──
    def scan_code(self, content: str):
        findings = [p for p in self.cfg.DANGEROUS_PATTERNS
                    if re.search(p, content, re.IGNORECASE)]
        if findings:
            return False, f"⚠️ Dangerous pattern(s): {', '.join(findings[:3])}"
        return True, "✅ Code looks safe"

    # ── Directories ──
    def project_dir(self, pid):
        d = self.cfg.UPLOAD_DIR / pid
        d.mkdir(parents=True, exist_ok=True)
        return d

    def write_default_files(self, pid):
        d = self.project_dir(pid)
        if not (d / 'main.py').exists():
            (d / 'main.py').write_text(self.cfg.DEFAULT_MAIN_FILE, encoding='utf-8')
        if not (d / 'requirements.txt').exists():
            (d / 'requirements.txt').write_text('# Add pip packages here\n', encoding='utf-8')

    # ── Start ──
    def start(self, project: dict, main_file=None, requirements=None):
        pid = project['project_id']
        main_file = main_file or project.get('main_file', 'main.py')
        requirements = requirements or project.get('requirements')
        d, logp = self.project_dir(pid), self.project_dir(pid) / 'output.log'

        def log(m):
            try:
                with open(logp, 'a', encoding='utf-8') as f:
                    f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {m}\n")
            except Exception:
                pass

        main_path = d / main_file
        if not main_path.exists():
            return None, f"ERROR: {main_file} not found!"
        if logp.exists():
            try: logp.unlink()
            except Exception: logp.write_text('', encoding='utf-8')

        log(f"🚀 Starting {pid} (CPU limit {project.get('cpu_limit', 80)}%)")

        if requirements and requirements.strip():
            rp = d / requirements.strip()
            if rp.exists():
                log("📦 Installing requirements...")
                try:
                    p = subprocess.Popen([sys.executable, '-m', 'pip', 'install', '-r', str(rp),
                                          '--disable-pip-version-check'],
                                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, encoding='utf-8', errors='replace',
                                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                    for line in iter(p.stdout.readline, ''):
                        if line.strip(): log(line.rstrip())
                    p.wait()
                    log("✅ Requirements installed" if p.returncode == 0 else "⚠️ Some packages failed")
                except Exception as e:
                    log(f"pip error: {e}")
            else:
                log(f"⚠️ {requirements} not found, skipping")

        try:
            env = os.environ.copy()
            env.update(PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
            proc = subprocess.Popen([sys.executable, str(main_path)],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    cwd=str(d), text=True, encoding='utf-8', errors='replace',
                                    bufsize=1, env=env,
                                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            log(f"✅ PID: {proc.pid}")

            def stream():
                try:
                    with open(logp, 'a', encoding='utf-8') as f:
                        for line in iter(proc.stdout.readline, ''):
                            if line:
                                f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {line.rstrip()}\n")
                                f.flush()
                except Exception:
                    pass
            threading.Thread(target=stream, daemon=True).start()
            threading.Thread(target=self._cpu_monitor,
                             args=(pid, proc, project.get('cpu_limit', 80), log), daemon=True).start()
            threading.Thread(target=self._monitor, args=(pid, proc, log), daemon=True).start()
            return proc.pid, None
        except Exception as e:
            log(f"❌ Error: {e}")
            return None, str(e)

    def _cpu_monitor(self, pid, proc, cpu_limit, log):
        while proc.poll() is None:
            time.sleep(self.cfg.CPU_CHECK_INTERVAL)
            try:
                cpu = psutil.Process(proc.pid).cpu_percent(interval=1)
                now = time.time()
                self.cpu_history.setdefault(pid, [])
                self.cpu_history[pid] = [h for h in self.cpu_history[pid]
                                         if now - h['t'] < self.cfg.CPU_HISTORY_WINDOW]
                self.cpu_history[pid].append({'t': now, 'c': cpu})
                recent = [h['c'] for h in self.cpu_history[pid]
                          if now - h['t'] < self.cfg.CPU_AVG_WINDOW]
                if recent and sum(recent) / len(recent) > cpu_limit:
                    log(f"🔥 CPU limit exceeded! {sum(recent)/len(recent):.1f}% > {cpu_limit}%")
                    self._kill_tree(proc.pid)
                    self.db.update_project(pid, status='stopped', pid=None,
                                           rate_limited=1, stopped_by_user=0)
                    return
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                return

    def _monitor(self, pid, proc, log):
        proc.wait()
        project = self.db.get_project(pid)
        if not project or project.get('stopped_by_user') or project.get('rate_limited'):
            return
        info = self.crash_count.get(pid, {'count': 0, 'last': time.time()})
        if time.time() - info['last'] < self.cfg.RESTART_COOLDOWN_SEC:
            if info['count'] >= self.cfg.AUTO_RESTART_MAX:
                log("🛑 Max auto-restarts reached")
                self.db.update_project(pid, status='stopped', pid=None)
                return
        else:
            info['count'] = 0
        info['count'] += 1
        info['last'] = time.time()
        self.crash_count[pid] = info
        log(f"🔄 Auto-restart #{info['count']}...")
        time.sleep(3)
        new_pid, err = self.start(project)
        if new_pid:
            self.db.update_project(pid, status='running', pid=new_pid,
                                   started_at=datetime.now().isoformat(),
                                   rate_limited=0, stopped_by_user=0)
        else:
            log(f"❌ Restart failed: {err}")
            self.db.update_project(pid, status='stopped', pid=None)

    def stop(self, project_id):
        p = self.db.get_project(project_id)
        if p and p.get('pid'):
            self._kill_tree(p['pid'])
        self.db.update_project(project_id, status='stopped', pid=None, stopped_by_user=1)
        try:
            with open(self.project_dir(project_id) / 'output.log', 'a', encoding='utf-8') as f:
                f.write(f"\n[{datetime.now().strftime('%I:%M:%S %p')}] 🛑 Stopped by user\n")
        except Exception:
            pass

    def _kill_tree(self, pid):
        try:
            parent = psutil.Process(pid)
            for child in parent.children(recursive=True):
                try: child.kill()
                except Exception: pass
            parent.terminate()
            try: parent.wait(timeout=3)
            except psutil.TimeoutExpired: parent.kill()
        except Exception:
            pass

    # ── Stats ──
    def process_stats(self, pid):
        try:
            p = psutil.Process(pid)
            mem = p.memory_info().rss / 1048576
            io = p.io_counters() if hasattr(p, 'io_counters') else None
            return {
                'cpu': f"{p.cpu_percent(interval=0.5):.1f}%",
                'ram': f"{mem:.1f} MB" if mem < 1024 else f"{mem/1024:.1f} GB",
                'net_in': self._fmt(io.read_bytes / 1024) if io and io.read_bytes else '0 KB',
                'net_out': self._fmt(io.write_bytes / 1024) if io and io.write_bytes else '0 KB'
            }
        except Exception:
            return {'cpu': '0%', 'ram': '0 MB', 'net_in': '0 KB', 'net_out': '0 KB'}

    def uptime_str(self, started_at):
        if not started_at:
            return '0h 0m'
        try:
            diff = datetime.now() - datetime.fromisoformat(started_at)
            h, m, s = diff.seconds // 3600, (diff.seconds % 3600) // 60, diff.seconds % 60
            return f"{diff.days}d {h}h {m}m" if diff.days else f"{h}h {m}m {s}s"
        except Exception:
            return '0h 0m'

    @staticmethod
    def _fmt(kb):
        if kb < 1024: return f"{kb:.1f} KB"
        mb = kb / 1024
        return f"{mb:.1f} MB" if mb < 1024 else f"{mb/1024:.2f} GB"