#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration for the Professional Hosting Platform.

ALL secrets & personal values are read from ENVIRONMENT VARIABLES only.
There are NO hardcoded credentials in this file.

Set them via a .env file (recommended) or your hosting platform's
Environment Variables dashboard.

Required variables (bot will refuse to start without them):
    BOT_TOKEN       - Telegram bot token from @BotFather
    OWNER_ID        - Your telegram numeric user ID

Optional variables (sensible defaults shown in parentheses):
    ADMIN_IDS        - Comma separated extra admin IDs ("")
    YOUR_USERNAME    - Owner username (@you)
    UPDATES_CHANNEL  - Channel/group link ("")

The .env file is loaded automatically by this module on import.
Copy `.env.example` → `.env` and fill in your values.
"""
import os
from pathlib import Path


def _load_dotenv(path=None):
    """Minimal .env loader (no external dependency).

    Reads KEY=VALUE lines from a .env file into os.environ.
    Supports '#' comments, blank lines, and quoted values.
    Existing environment variables are NOT overwritten.
    """
    if path is None:
        # Look for .env in project root
        here = Path(__file__).resolve().parent
        candidates = [here / ".env", here.parent / ".env"]
        chosen = next((p for p in candidates if p.is_file()), None)
        if chosen is None:
            return
        path = chosen
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                if not key:
                    continue
                if (value.startswith('"') and value.endswith('"')) or (
                    value.startswith("'") and value.endswith("'")
                ):
                    value = value[1:-1]
                # Don't override real environment variables
                if key not in os.environ:
                    os.environ[key] = value
    except Exception:
        # Never crash because of a malformed .env file
        pass


# Load .env before reading any configuration
_load_dotenv()


def _require_env(name: str) -> str:
    """Return env value or raise a clear error."""
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(
            f"❌ MISSING ENVIRONMENT VARIABLE: {name}\n"
            f"   Please set it in your .env file or in your hosting "
            f"platform's environment settings.\n"
            f"   See README.md or .env.example for the full setup guide."
        )
    return value


# ── Base paths ──────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
_IN_VERCEL = os.environ.get("VERCEL") == "1"
DATA_DIR = Path(
    os.environ.get(
        "DATA_DIR",
        "/tmp/hosting-data" if _IN_VERCEL else str(BASE_DIR / "data"),
    )
)
UPLOAD_DIR = DATA_DIR / "projects"
PENDING_DIR = DATA_DIR / "pending"
LOGS_DIR = BASE_DIR / "logs"
DB_PATH = DATA_DIR / "hosting.db"


class Config:
    # ── Required: Telegram credentials (NO defaults) ──────────────
    BOT_TOKEN = _require_env("BOT_TOKEN")
    OWNER_ID = int(_require_env("OWNER_ID"))

    # ── Optional: extra admins & links ────────────────────────────
    ADMIN_IDS = {
        int(x.strip())
        for x in os.environ.get("ADMIN_IDS", "").split(",")
        if x.strip().isdigit()
    }
    ADMIN_IDS.add(OWNER_ID)

    YOUR_USERNAME = os.environ.get("YOUR_USERNAME", "")
    UPDATES_CHANNEL = os.environ.get("UPDATES_CHANNEL", "")

    # ── Site branding & contact (used by templates) ──────────────
    SITE_NAME = os.environ.get("SITE_NAME", "Hosting Platform")
    CONTACT_URL = os.environ.get("CONTACT_URL", "")

    # ── Web panel (Flask) ────────────────────────────────────────
    WEB_HOST = os.environ.get("WEB_HOST", "0.0.0.0")
    WEB_PORT = int(os.environ.get("WEB_PORT", "8080"))
    WEB_SECRET = os.environ.get("WEB_SECRET", "hosting-secret-key-change-me")
    WEB_ADMIN_PASSWORD = os.environ.get("WEB_ADMIN_PASSWORD", "admin")

    # ── File upload limits ───────────────────────────────────────
    MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "50"))
    MAX_FILE_BYTES = MAX_UPLOAD_MB * 1024 * 1024
    FREE_USER_LIMIT = int(os.environ.get("FREE_USER_LIMIT", "3"))
    SUBSCRIBED_USER_LIMIT = int(os.environ.get("SUBSCRIBED_USER_LIMIT", "15"))
    ADMIN_LIMIT = int(os.environ.get("ADMIN_LIMIT", "999"))
    OWNER_LIMIT = float(os.environ.get("OWNER_LIMIT", "inf"))

    # ── Process / resource monitoring ────────────────────────────
    DEFAULT_CPU_LIMIT = int(os.environ.get("DEFAULT_CPU_LIMIT", "80"))
    AUTO_RESTART_MAX = int(os.environ.get("AUTO_RESTART_MAX", "3"))
    RESTART_COOLDOWN_SEC = int(os.environ.get("RESTART_COOLDOWN_SEC", "60"))
    CPU_CHECK_INTERVAL = int(os.environ.get("CPU_CHECK_INTERVAL", "5"))
    CPU_AVG_WINDOW = int(os.environ.get("CPU_AVG_WINDOW", "10"))
    CPU_HISTORY_WINDOW = int(os.environ.get("CPU_HISTORY_WINDOW", "30"))

    # ── Runtime ──────────────────────────────────────────────────
    KEEP_ALIVE_PORT = int(os.environ.get("PORT", "8080"))
    POLLING_TIMEOUT = int(os.environ.get("POLLING_TIMEOUT", "60"))
    LONG_POLLING_TIMEOUT = int(os.environ.get("LONG_POLLING_TIMEOUT", "30"))

    # ── Security: scripts matching these are auto-blocked ────────
    DANGEROUS_PATTERNS = [
        r"import\s+os\s*;\s*os\.system",
        r"os\.system\s*\(",
        r"subprocess\.(Popen|call|run)\s*\(",
        r"eval\s*\(",
        r"exec\s*\(",
        r"open\s*\(.*['\"]/etc/",
        r"rm\s+-rf\s*/",
        r"shutil\.rmtree\s*\(.*['\"]/",
    ]

    # ── Default main file injected into new projects ─────────────
    DEFAULT_MAIN_FILE = '''# Hosted on Professional Hosting Platform
import time

print("=" * 40)
print("🎉 Bot is running on the hosting platform!")
print("🚀 Server is ready!")
print("=" * 40)

counter = 0
while True:
    counter += 1
    print(f"[{time.strftime('%H:%M:%S')}] Heartbeat #{counter} | Server active")
    time.sleep(10)
'''

    # ── SQLite connection lock helpers ───────────────────────────
    @staticmethod
    def ensure_dirs():
        """Create all required directories."""
        for d in (DATA_DIR, UPLOAD_DIR, PENDING_DIR, LOGS_DIR):
            d.mkdir(parents=True, exist_ok=True)