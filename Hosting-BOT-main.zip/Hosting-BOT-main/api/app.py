#!/usr/bin/env python3
"""Vercel serverless entry point.

Exposes the Flask web panel app for Vercel's Python runtime.
The Telegram bot itself (long-running) still runs on a VPS/local machine.
"""
import os
import sys

# Ensure api directory is importable on Vercel (local copies first)
API_DIR = os.path.dirname(os.path.abspath(__file__))
if API_DIR not in sys.path:
    sys.path.insert(0, API_DIR)

# Ensure project root is importable on Vercel
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Re-export the global Flask app built in web_panel.py
try:
    from web_panel import app  # noqa: E402
except Exception:
    from flask import Flask
    app = Flask(__name__)

# Vercel expects the WSGI app object named `app`
application = app
