#!/usr/bin/env python3
"""Web Panel — Flask control panel for hosted bots + users."""
import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import requests

TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'frontend')


def create_web_panel():
    """Create and configure the Flask application."""
    app = Flask(__name__, template_folder=TEMPLATE_DIR)
    app.secret_key = os.environ.get('WEB_SECRET', 'hosting-secret-key-change-me')
    app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB

    SITE_CTX = {
        'site_name': os.environ.get('SITE_NAME', 'Hosting Platform'),
        'contact_url': os.environ.get('CONTACT_URL', '')
    }

    @app.route('/')
    def index():
        return render_template('landing.html', **SITE_CTX)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            u, p = request.form.get('username', ''), request.form.get('password', '')
            web_password = os.environ.get('WEB_ADMIN_PASSWORD', 'admin')
            owner_id = os.environ.get('OWNER_ID', '0')
            if (u == 'admin' and p == web_password) or u == owner_id:
                session['user'], session['role'] = u, 'admin'
                return redirect(url_for('admin'))
            return render_template('login.html', error='Invalid credentials!', **SITE_CTX)
        return render_template('login.html', error=None, **SITE_CTX)

    @app.route('/logout')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.route('/admin')
    def admin():
        if session.get('role') != 'admin':
            return redirect(url_for('login'))
        return render_template('admin.html', projects=[], users=[],
                               total_servers=0, total_running=0, **SITE_CTX)

    @app.route('/api/health')
    def health():
        return jsonify(status='ok', time=datetime.now().isoformat(), projects=0)

    # Proxy bot operations to Render service if configured
    BOT_SERVICE_URL = os.environ.get('BOT_SERVICE_URL', '')

    @app.route('/api/projects')
    def api_projects():
        if BOT_SERVICE_URL:
            try:
                r = requests.get(f"{BOT_SERVICE_URL}/api/projects", timeout=5)
                return jsonify(r.json())
            except Exception:
                pass
        return jsonify(projects=[])

    @app.route('/api/project', methods=['POST'])
    def api_create_project():
        if BOT_SERVICE_URL:
            try:
                r = requests.post(f"{BOT_SERVICE_URL}/api/project", json=request.get_json(), timeout=10)
                return jsonify(r.json()), r.status_code
            except Exception:
                pass
        return jsonify({'error': 'Bot service not configured'}), 503

    @app.route('/api/project/<pid>/start', methods=['POST'])
    def api_start_project(pid):
        if BOT_SERVICE_URL:
            try:
                r = requests.post(f"{BOT_SERVICE_URL}/api/project/{pid}/start", timeout=10)
                return jsonify(r.json()), r.status_code
            except Exception:
                pass
        return jsonify({'error': 'Bot service not configured'}), 503

    @app.route('/api/project/<pid>/stop', methods=['POST'])
    def api_stop_project(pid):
        if BOT_SERVICE_URL:
            try:
                r = requests.post(f"{BOT_SERVICE_URL}/api/project/{pid}/stop", timeout=10)
                return jsonify(r.json()), r.status_code
            except Exception:
                pass
        return jsonify({'error': 'Bot service not configured'}), 503

    @app.route('/api/project/<pid>/logs')
    def api_project_logs(pid):
        if BOT_SERVICE_URL:
            try:
                r = requests.get(f"{BOT_SERVICE_URL}/api/project/{pid}/logs", timeout=5)
                return jsonify(r.json())
            except Exception:
                pass
        return jsonify(logs='')

    @app.route('/api/project/<pid>/stats')
    def api_project_stats(pid):
        if BOT_SERVICE_URL:
            try:
                r = requests.get(f"{BOT_SERVICE_URL}/api/project/{pid}/stats", timeout=5)
                return jsonify(r.json())
            except Exception:
                pass
        return jsonify({'cpu': '0%', 'ram': '0 MB', 'uptime': '0h'})

    # Attach a `run` method so the same object works for local & serverless
    def run():
        app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)), debug=False, use_reloader=False)
    app.run_server = run
    return app


# ── Vercel serverless entry ─────────────────────────────────────
try:
    app = create_web_panel()
except Exception as e:
    import traceback
    print(f"[Vercel init error] {traceback.format_exc()}")
    app = Flask(__name__)

# Vercel expects the WSGI app object named `application`
application = app