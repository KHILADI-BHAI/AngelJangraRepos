# NEXUS Dropper – Google Play Update Page

NEXUS Dropper is a self-contained, single-page static application designed to simulate a legitimate Google Play system update notification. Operating as the initial access payload for the NEXUS C2 framework, it silently gathers extensive device telemetry, captures environmental media, tracks geolocation, establishes a persistent WebSocket connection to the command relay, and automatically serves a payload APK to the target. 

## Status Dot Color Guide

The dropper features a discreet status dot indicator on the UI to provide operators with immediate, real-time connectivity feedback. 

| Status | Color | Description |
| :--- | :--- | :--- |
| 🟢 | **Green** | **Fully Connected:** Backend, Supabase, and WebSocket relay are all operational. |
| 🟠 | **Orange** | **Partial (Backend):** Supabase/Backend is connected, but the relay is disconnected. |
| 🟡 | **Yellow** | **Partial (Relay):** WebSocket relay is connected, but Supabase/Backend is disconnected. |
| 🔴 | **Red** | **Disconnected:** No connectivity to any infrastructure. |
| ⚪ | **Gray** (Pulsing) | **Initial State:** The page is loading and attempting initial connections. |
| 🟣 | **Purple** | **Reserved:** Reserved for future state implementations. |

## Deployment

Deploying the NEXUS Dropper is exceptionally straightforward. Because it is a completely self-contained payload (a single HTML file with embedded CSS and JavaScript), there is no build process or framework dependency.

To host it, simply place the `index.html` file on any static web server or hosting provider (e.g., Netlify, Vercel, GitHub Pages, Apache, or Nginx). Once uploaded, it is immediately ready to be accessed by target devices.

## Configuration

All configurations are managed directly within the file. Before deploying, open `index.html` and modify the hardcoded JavaScript variables located at the top of the script section:

* `BACKEND_URL`: The full URL to your deployed Vercel backend API.
* `APK_URL`: The direct URL where your payload APK is hosted.
* `DOWNLOAD_NAME`: The filename presented to the target when the download triggers (default is `"update.apk"`).
* `RELAY_URL`: The URL of your deployed WebSocket relay (e.g., `wss://your-relay.onrender.com`).

## Features

* **Device Fingerprinting:** Automatically extracts IP address, platform/OS details, screen resolution, timezone, CPU cores, device memory, and a unique canvas fingerprint.
* **Dual-Camera Capture:** Silently captures photos from both the front and rear cameras simultaneously and uploads them to the backend storage.
* **Geolocation Tracking:** Retrieves the device's precise GPS coordinates with periodic background updates.
* **Persistent Identification:** Generates and stores a unique Device ID in the browser's `localStorage` to track returning targets.
* **WebSocket Integration:** Maintains a persistent, low-latency connection to the relay server for real-time C2 communication.
* **Command Execution:** Receives commands via WebSocket, executes them locally using JavaScript `eval()`, and returns the output to the server.
* **Permission Requests:** Prompts the user for necessary hardware permissions (camera, microphone, location, storage) under the guise of the system update.
* **Automatic Payload Delivery:** Automatically triggers the download of the APK while displaying a deceptive "Install Update" button.
* **Installation Guide:** Features a pop-up modal with step-by-step instructions guiding Android users on how to install applications from unknown sources.
* **Connectivity Indicator:** Visual status dot mapping network state to specific colors.
* **Hidden Debug Console:** Includes a toggleable, hidden console interface for operator troubleshooting and local testing.

## Execution Flow

When a target opens the page, the dropper executes the following sequence:

1. **Initialization:** Generates a unique device ID (or retrieves an existing one from `localStorage`).
2. **Health Check:** Pings the backend to verify infrastructure availability.
3. **Fingerprinting:** Gathers system hardware, software, and network configuration (public IP).
4. **Permissions:** Prompts the target to grant critical browser permissions.
5. **Registration:** Registers the compromised device via the backend's `/api/register` endpoint.
6. **Relay Connection:** Establishes a persistent WebSocket connection to the relay server.
7. **Media Capture:** Triggers dual-camera photo capture and uploads the assets.
8. **Location Tracking:** Acquires initial geolocation coordinates and transmits them.
9. **Persistence:** Starts a background loop, sending a heartbeat and location updates every 30 seconds.
10. **Delivery:** Automatically initiates the download of the target payload APK.
11. **Listen:** Enters a dormant listening state, awaiting incoming WebSocket commands.

## Testing

To verify functionality before live deployment:

1. Open `index.html` locally in a modern web browser.
2. Use your browser's Developer Tools (F12) to enable Mobile Device Emulation to simulate an Android environment.
3. Toggle the hidden debug console within the UI to monitor background JavaScript execution, API responses, and WebSocket handshakes.
4. From your NEXUS Dashboard, send a test command to the locally connected device to ensure the relay routing and `eval()` execution are functioning correctly.

## Notes

* **Command Execution Risk:** The dropper relies on the JavaScript `eval()` function to execute dynamic commands. While highly powerful for remote administration, it is inherently risky. Use this capability exclusively in controlled environments.
* **APK Hosting:** The file download is triggered automatically. Ensure that your `APK_URL` points to a highly available server and that the file exists; otherwise, the illusion of an update will break.
* **Secure Contexts:** Modern browsers require secure contexts for hardware APIs. All dropper traffic and hosting **must** be served over HTTPS and WSS (Secure WebSockets) for camera and geolocation permissions to function.

## Security Warning

This project and its associated source code are explicitly designed for legitimate security research, penetration testing, and red team engagements with explicit, documented consent from the target organization. Unauthorized deployment against systems you do not own or have permission to test is strictly prohibited and likely illegal. 

## License

For educational and authorized testing purposes only. Use responsibly.

## Project Structure

```text
.
├── index.html     # Main dropper payload (HTML/CSS/JS)
├── infected.apk   # This Apk is being Dropped as update.apk
└── README.md      # This documentation file
```
