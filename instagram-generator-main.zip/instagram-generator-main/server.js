const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const { Ratelimit } = require('@upstash/ratelimit');
const { Redis } = require('@upstash/redis');
const axios = require('axios');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const chromium = require('@sparticuz/chromium');
const { faker } = require('faker');
const userAgent = require('user-agents');

puppeteer.use(StealthPlugin());
const app = express();
app.use(express.json());

// ---------- ENV VARIABLES ----------
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const CAPTCHA_API_KEY = process.env.CAPTCHA_API_KEY;

// ---------- SUPABASE ----------
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ---------- RATE LIMIT (Upstash) ----------
const redis = Redis.fromEnv();
const rateLimiter = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(5, '10 s'),
  analytics: true,
});

// ---------- PROXY MANAGER ----------
let proxyList = [];
let lastFetch = 0;
async function fetchProxies() {
  const sources = [
    'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
    'https://www.proxy-list.download/api/v1/get?type=http',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt'
  ];
  for (const url of sources) {
    try {
      const res = await axios.get(url, { timeout: 5000 });
      const lines = res.data.split('\n').filter(l => l.trim() && !l.includes('#'));
      if (lines.length > 10) return lines.map(l => l.trim());
    } catch (_) { continue; }
  }
  return [];
}
async function getNextProxy() {
  const now = Date.now();
  if (proxyList.length === 0 || now - lastFetch > 60000) {
    proxyList = await fetchProxies();
    lastFetch = now;
  }
  if (proxyList.length === 0) return null;
  const proxy = proxyList.pop();
  proxyList.unshift(proxy);
  return `http://${proxy}`;
}

// ---------- TEMP MAIL (1secmail) ----------
const MAIL_BASE = 'https://www.1secmail.com/api/v1/';
async function createTempEmail() {
  const res = await axios.get(`${MAIL_BASE}?action=genRandomMailbox&count=1`);
  const email = res.data[0];
  const [login, domain] = email.split('@');
  return { email, login, domain };
}
async function waitForInbox(email, timeoutMs = 60000) {
  const [login, domain] = email.split('@');
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await axios.get(`${MAIL_BASE}?action=getMessages&login=${login}&domain=${domain}`);
    const messages = res.data;
    if (messages && messages.length > 0) {
      const msg = messages[0];
      const detail = await axios.get(`${MAIL_BASE}?action=readMessage&login=${login}&domain=${domain}&id=${msg.id}`);
      return detail.data;
    }
    await new Promise(r => setTimeout(r, 3000));
  }
  throw new Error('Timeout waiting for email');
}
function extractCodeFromEmail(body) {
  const match = body.match(/\b(\d{6})\b/);
  return match ? match[1] : null;
}

// ---------- SMS (Quackr.io) ----------
const QUACKR_API = 'https://quackr.io/api';
async function getTempNumber() {
  const res = await axios.get(`${QUACKR_API}/get_number`);
  if (res.data && res.data.number) {
    return { number: res.data.number, id: res.data.id || '' };
  }
  throw new Error('Failed to get temp number from Quackr');
}
async function waitForSms(number, timeoutMs = 60000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await axios.get(`${QUACKR_API}/sms`, { params: { number } });
    const messages = res.data;
    if (Array.isArray(messages) && messages.length > 0) {
      const latest = messages[messages.length - 1];
      const match = latest.body.match(/\b(\d{6})\b/);
      if (match) return match[1];
    }
    await new Promise(r => setTimeout(r, 3000));
  }
  throw new Error('SMS timeout – no code received');
}

// ---------- 2CAPTCHA SOLVER ----------
const CAPTCHA_BASE = 'https://2captcha.com/in.php';
const CAPTCHA_RESULT = 'https://2captcha.com/res.php';
async function waitForCaptchaResult(id, timeoutMs = 120000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const res = await axios.get(CAPTCHA_RESULT, {
      params: { key: CAPTCHA_API_KEY, action: 'get', id, json: 1 },
    });
    if (res.data.status === 1) return res.data.request;
    if (res.data.request === 'CAPCHA_NOT_READY') {
      await new Promise(r => setTimeout(r, 4000));
      continue;
    }
    throw new Error(`2captcha error: ${res.data.request}`);
  }
  throw new Error('2captcha timeout');
}
async function solveRecaptchaV2(sitekey, pageurl) {
  const res = await axios.post(CAPTCHA_BASE, null, {
    params: {
      key: CAPTCHA_API_KEY,
      method: 'userrecaptcha',
      googlekey: sitekey,
      pageurl,
      json: 1,
    },
  });
  if (res.data.status !== 1) throw new Error(`Recaptcha submit failed: ${res.data.request}`);
  return await waitForCaptchaResult(res.data.request);
}
async function solveCaptcha(page) {
  const recaptcha = await page.$('iframe[src*="recaptcha"], .g-recaptcha');
  if (recaptcha) {
    const sitekey = await page.evaluate(() => {
      const el = document.querySelector('.g-recaptcha') || document.querySelector('[data-sitekey]');
      return el?.getAttribute('data-sitekey');
    });
    if (!sitekey) {
      const src = await page.evaluate(() => {
        const iframe = document.querySelector('iframe[src*="recaptcha"]');
        return iframe?.getAttribute('src');
      });
      if (src) {
        const match = src.match(/k=([^&]+)/);
        if (match) return await solveRecaptchaV2(match[1], page.url());
      }
      return null;
    }
    return await solveRecaptchaV2(sitekey, page.url());
  }
  const imgCaptcha = await page.$('img[src*="captcha"]');
  if (imgCaptcha) {
    const buffer = await imgCaptcha.screenshot({ encoding: 'base64' });
    const res = await axios.post(CAPTCHA_BASE, null, {
      params: {
        key: CAPTCHA_API_KEY,
        method: 'base64',
        body: buffer,
        json: 1,
      },
    });
    if (res.data.status !== 1) throw new Error(`Image captcha submit failed: ${res.data.request}`);
    return await waitForCaptchaResult(res.data.request);
  }
  return null;
}

// ---------- FINGERPRINT SPOOFING ----------
function getRandomViewport() {
  const sizes = [
    { width: 1920, height: 1080 },
    { width: 1366, height: 768 },
    { width: 1536, height: 864 },
    { width: 1440, height: 900 },
    { width: 1280, height: 720 },
  ];
  return sizes[Math.floor(Math.random() * sizes.length)];
}
function getRandomUserAgent() {
  return new userAgent({ deviceCategory: 'desktop' }).toString();
}
function getRandomLocale() {
  const locales = ['en-US', 'en-GB', 'en-CA', 'en-AU', 'fr-FR', 'de-DE', 'es-ES'];
  return locales[Math.floor(Math.random() * locales.length)];
}

// ---------- API ENDPOINT ----------
app.post('/api/generate', async (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'anonymous';
  const { success } = await rateLimiter.limit(ip);
  if (!success) {
    return res.status(429).json({ error: 'Rate limit exceeded. Wait a moment.' });
  }

  let browser = null;
  try {
    const username = faker.internet.userName().toLowerCase() + Math.floor(Math.random() * 9999);
    const password = faker.internet.password({ length: 14, memorable: true }) + 'Aa1!';
    const tempMail = await createTempEmail();
    const email = tempMail.email;

    const proxy = await getNextProxy();
    const args = chromium.args.concat([
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--window-size=1920,1080',
      '--disable-gpu',
    ]);
    if (proxy) args.push(`--proxy-server=${proxy}`);

    const viewport = getRandomViewport();
    const userAgentStr = getRandomUserAgent();

    browser = await puppeteer.launch({
      args,
      defaultViewport: viewport,
      executablePath: await chromium.executablePath(),
      headless: true,
    });

    const page = await browser.newPage();
    await page.setUserAgent(userAgentStr);
    await page.setExtraHTTPHeaders({ 'Accept-Language': getRandomLocale() });

    // --- Signup ---
    await page.goto('https://www.instagram.com/accounts/emailsignup/', { waitUntil: 'networkidle2' });
    await page.type('input[name="emailOrPhone"]', email, { delay: 70 + Math.random() * 30 });
    await page.type('input[name="fullName"]', faker.name.findName(), { delay: 70 + Math.random() * 30 });
    await page.type('input[name="username"]', username, { delay: 70 + Math.random() * 30 });
    await page.type('input[name="password"]', password, { delay: 70 + Math.random() * 30 });
    await page.mouse.move(200 + Math.random() * 300, 200 + Math.random() * 300);
    await page.click('button[type="submit"]');
    await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 });

    // --- Captcha Check (Post-Signup) ---
    const captchaSolution = await solveCaptcha(page);
    if (captchaSolution) {
      const input = await page.$('input[name="captcha"]') || await page.$('input#captcha');
      if (input) {
        await input.type(captchaSolution, { delay: 50 });
        await page.click('button[type="submit"]');
        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 });
      }
    }

    // --- Phone Handling ---
    let smsCode = null;
    try {
      await page.waitForSelector('input[name="phoneNumber"]', { timeout: 5000 });
      const tempNumber = await getTempNumber();
      const phoneInput = await page.$('input[name="phoneNumber"]');
      await phoneInput?.type(tempNumber.number, { delay: 50 });
      await page.click('button[type="submit"]');
      smsCode = await waitForSms(tempNumber.number);
      await page.waitForSelector('input[name="confirmationCode"]', { timeout: 15000 });
      await page.type('input[name="confirmationCode"]', smsCode, { delay: 50 });
      await page.click('button[type="submit"]');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 });
    } catch (phoneError) {
      console.log('Phone page not triggered or skipped.');
    }

    // --- Email Verification (if phone didn't complete) ---
    if (!smsCode) {
      await page.waitForSelector('input[name="confirmationCode"]', { timeout: 30000 });
      const emailData = await waitForInbox(email);
      const code = extractCodeFromEmail(emailData.body);
      if (!code) throw new Error('No email code found');
      await page.type('input[name="confirmationCode"]', code, { delay: 50 });
      await page.click('button[type="submit"]');
      await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 });
    }

    // --- Final Captcha ---
    const finalCaptcha = await solveCaptcha(page);
    if (finalCaptcha) {
      const input = await page.$('input[name="captcha"]');
      if (input) {
        await input.type(finalCaptcha, { delay: 50 });
        await page.click('button[type="submit"]');
        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 });
      }
    }

    const url = page.url();
    if (url.includes('challenge') || url.includes('error')) {
      throw new Error('Final verification failed.');
    }

    const { error: dbError } = await supabase.from('accounts').insert({
      username,
      password,
      email,
      phone_used: smsCode ? 'temp' : null,
      created_at: new Date().toISOString(),
      proxy_used: proxy || 'direct',
    });
    if (dbError) throw dbError;

    await browser.close();
    res.status(200).json({ success: true, username, password, email });
  } catch (err) {
    if (browser) await browser.close();
    res.status(500).json({ error: err.message || 'Unknown error' });
  }
});

// ---------- SERVE BUILT-IN HTML UI (no public folder needed) ----------
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Potato's Instagram Generator</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body { background: #0b0d15; }
    .glass { background: rgba(255,255,255,0.03); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.06); }
    .log-box { font-family: 'Courier New', monospace; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 text-white">
  <div class="w-full max-w-2xl glass rounded-3xl p-8 shadow-2xl">
    <div class="flex items-center gap-3 mb-6">
      <span class="text-3xl">🥔</span>
      <h1 class="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">Potato Generator</h1>
    </div>
    <p class="text-gray-400 text-sm mb-6 border-l-4 border-yellow-500 pl-4">Fingerprint spoofed · Captcha solved · Proxy cycled · SMS ready</p>
    <button id="generateBtn" class="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl font-semibold text-lg shadow-lg hover:scale-[1.02] transition-all flex items-center justify-center gap-2">
      <i class="fas fa-rocket"></i> Generate Account
    </button>
    <div id="logs" class="mt-6 bg-black/50 rounded-xl p-4 log-box text-sm max-h-48 overflow-y-auto border border-white/5 hidden">
      <div id="logContent"></div>
    </div>
    <div id="error" class="mt-4 hidden bg-red-500/20 border border-red-500/40 rounded-xl p-4 flex items-start gap-3">
      <i class="fas fa-exclamation-circle text-red-400 mt-0.5"></i>
      <span id="errorText" class="text-red-300"></span>
    </div>
    <div id="result" class="mt-6 hidden bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-5">
      <div class="grid grid-cols-1 gap-2 text-sm">
        <div><span class="text-gray-400">Username:</span> <span id="resUser" class="font-mono text-emerald-300"></span></div>
        <div><span class="text-gray-400">Password:</span> <span id="resPass" class="font-mono text-emerald-300"></span></div>
        <div><span class="text-gray-400">Email:</span> <span id="resEmail" class="font-mono text-emerald-300"></span></div>
      </div>
    </div>
    <p class="mt-6 text-center text-gray-600 text-xs border-t border-white/5 pt-4">⚡ Render Deployed · 2Captcha · Quackr SMS · Upstash Rate Limit</p>
  </div>
  <script>
    const btn = document.getElementById('generateBtn');
    const logDiv = document.getElementById('logs');
    const logContent = document.getElementById('logContent');
    const errorDiv = document.getElementById('error');
    const errorText = document.getElementById('errorText');
    const resultDiv = document.getElementById('result');
    function addLog(msg) {
      logDiv.classList.remove('hidden');
      logContent.innerHTML += '<div class="py-0.5 text-gray-300">' + msg + '</div>';
      logDiv.scrollTop = logDiv.scrollHeight;
    }
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
      logContent.innerHTML = '';
      logDiv.classList.add('hidden');
      errorDiv.classList.add('hidden');
      resultDiv.classList.add('hidden');
      addLog('🌀 Launching headless browser with stealth...');
      try {
        const res = await fetch('/api/generate', { method: 'POST' });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed');
        addLog('✅ Account created & saved to Supabase!');
        document.getElementById('resUser').textContent = data.username;
        document.getElementById('resPass').textContent = data.password;
        document.getElementById('resEmail').textContent = data.email;
        resultDiv.classList.remove('hidden');
      } catch (err) {
        addLog('❌ ' + err.message);
        errorText.textContent = err.message;
        errorDiv.classList.remove('hidden');
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-rocket"></i> Generate Account';
      }
    });
  </script>
</body>
</html>
  `);
});

// ---------- START SERVER ----------
const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log(`🚀 Potato is live on Render at port ${PORT}`));
