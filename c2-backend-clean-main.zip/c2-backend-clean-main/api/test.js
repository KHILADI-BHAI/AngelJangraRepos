// api/test.js — This is a fallback, but index.js already handles /api/test
// This file is here just in case you want to keep it separate.
// The main logic is in index.js

module.exports = (req, res) => {
    // Redirect to the main test handler in index.js
    res.setHeader('Location', '/api/test');
    res.status(302).end();
};