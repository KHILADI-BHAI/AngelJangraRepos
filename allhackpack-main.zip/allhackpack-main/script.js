// ============================================================
//  DATA
// ============================================================
const data = {
    categories: [
        { id: 'recon', icon: 'fa-eye', label: 'Reconnaissance' },
        { id: 'exploit', icon: 'fa-bolt', label: 'Exploitation' },
        { id: 'web', icon: 'fa-globe', label: 'Web Security' },
        { id: 'crypto', icon: 'fa-lock', label: 'Cryptography' },
        { id: 'forensics', icon: 'fa-search', label: 'Forensics' },
        { id: 'osint', icon: 'fa-map-pin', label: 'OSINT' },
        { id: 'movies', icon: 'fa-film', label: 'Movie Sites' }
    ],
    links: {
        recon: [
            { title: 'Nmap', desc: 'Network scanner', url: 'https://nmap.org' },
            { title: 'Shodan', desc: 'Internet device search', url: 'https://shodan.io' },
            { title: 'Amass', desc: 'Subdomain enumeration', url: 'https://github.com/OWASP/Amass' }
        ],
        exploit: [
            { title: 'Metasploit', desc: 'Exploit framework', url: 'https://metasploit.com' },
            { title: 'Searchsploit', desc: 'Exploit-db CLI', url: 'https://exploit-db.com' }
        ],
        web: [
            { title: 'Burp Suite', desc: 'Web proxy suite', url: 'https://portswigger.net/burp' },
            { title: 'OWASP ZAP', desc: 'Web vulnerability scanner', url: 'https://zaproxy.org' },
            { title: 'SQLmap', desc: 'SQL injection tool', url: 'https://sqlmap.org' }
        ],
        crypto: [
            { title: 'Hashcat', desc: 'Password recovery', url: 'https://hashcat.net' },
            { title: 'John the Ripper', desc: 'Password cracker', url: 'https://openwall.com/john' }
        ],
        forensics: [
            { title: 'Autopsy', desc: 'Digital forensics', url: 'https://autopsy.com' },
            { title: 'Wireshark', desc: 'Packet analyzer', url: 'https://wireshark.org' }
        ],
        osint: [
            { title: 'theHarvester', desc: 'Email & domain OSINT', url: 'https://github.com/laramies/theHarvester' },
            { title: 'Maltego', desc: 'Graphical OSINT', url: 'https://maltego.com' }
        ],
        movies: [
            { title: 'Vegamovies 2026', desc: 'The Ultimate Entertainment Hub — Bollywood, Hollywood, South Indian, Hindi Dubbed, Dual Audio, Web Series — all in one place.', url: 'https://vglist.top/' },
            { title: 'BollyFlix', desc: 'The official site for Bollywood & Hollywood Movies — extensive collection of Bollywood films, South Indian dubbed movies, Hollywood Hindi-dubbed movies, and web series.', url: 'https://bollyflix.to/' },
            { title: 'MovieBox', desc: 'Watch Movies Free Online, Watch TV Series Online — enjoy unlimited movies and shows, download your favorite content to watch offline.', url: 'https://moviebox.ph/' }
        ]
    }
};

// ============================================================
//  DOM REFS
// ============================================================
const catListEl = document.getElementById('categoryList');
const linkContainer = document.getElementById('linkContainer');
const currentCatLabel = document.getElementById('currentCategory');
const emptyMsg = document.getElementById('emptyMessage');
const homePage = document.getElementById('homePage');
const browseBtn = document.getElementById('browseBtn');
const logoHomeLink = document.getElementById('logoHomeLink');

let activeCategory = null;

// ============================================================
//  RENDER
// ============================================================
function renderCategories() {
    catListEl.innerHTML = '';
    data.categories.forEach(cat => {
        const div = document.createElement('div');
        div.className = `category ${cat.id === activeCategory ? 'active' : ''}`;
        div.dataset.id = cat.id;
        div.innerHTML = `<i class="fas ${cat.icon}"></i><span>${cat.label}</span>`;
        div.addEventListener('click', () => {
            activeCategory = cat.id;
            renderCategories();
            showCategory(cat.id);
        });
        catListEl.appendChild(div);
    });
}

function showCategory(categoryId) {
    homePage.style.display = 'none';
    linkContainer.style.display = 'grid';
    emptyMsg.style.display = 'none';
    const links = data.links[categoryId] || [];
    const catLabel = data.categories.find(c => c.id === categoryId)?.label || categoryId;
    currentCatLabel.textContent = catLabel;
    linkContainer.innerHTML = '';
    if (links.length === 0) {
        emptyMsg.style.display = 'block';
        return;
    }
    links.forEach(link => {
        const a = document.createElement('a');
        a.className = 'link-card';
        a.href = link.url;
        a.target = '_blank';
        a.innerHTML = `
            <div class="link-title">${link.title}</div>
            <div class="link-desc">${link.desc}</div>
            <div class="link-url">${link.url}</div>
        `;
        linkContainer.appendChild(a);
    });
}

function showHome() {
    activeCategory = null;
    renderCategories();
    homePage.style.display = 'flex';
    linkContainer.style.display = 'none';
    emptyMsg.style.display = 'none';
    currentCatLabel.textContent = 'Home';
}

// ============================================================
//  INIT
// ============================================================
renderCategories();
showHome();

browseBtn.addEventListener('click', () => {
    const firstCat = data.categories[0];
    if (firstCat) {
        activeCategory = firstCat.id;
        renderCategories();
        showCategory(firstCat.id);
    }
});
logoHomeLink.addEventListener('click', showHome);

// ============================================================
//  THEME TOGGLE
// ============================================================
const themeToggle = document.getElementById('themeToggle');
document.documentElement.setAttribute('data-theme', 'dark');
themeToggle.addEventListener('click', function(e) {
    e.stopPropagation();
    this.classList.toggle('active');
    const darkMode = this.classList.contains('active');
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
    const icon = this.parentElement.querySelector('i');
    icon.className = darkMode ? 'fas fa-moon' : 'fas fa-sun';
});