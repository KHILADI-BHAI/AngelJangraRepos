/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    optimizePackageImports: ['lucide-react'],
  },
  webpack: (config) => {
    config.output.chunkFilename = 'static/chunks/[name].[contenthash].js'
    return config
  },
  images: {
    // We can add remote image domains here later for user avatars or game banners
    remotePatterns: [],
  },
}

module.exports = nextConfig