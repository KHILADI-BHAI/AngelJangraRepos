export interface User {
  id: string
  email: string
  display_name: string
  balance: number
  winning_cash: number
  bonus_cash: number
  referral_code: string
  free_fire_uid?: string
  ff_nickname?: string
  ff_clan_name?: string
  ff_verified: boolean
  status: string
}

export interface Tournament {
  id: string
  name: string
  game_id: string
  game: { name: string; image_url: string }
  start_time: string
  status: 'upcoming' | 'ongoing' | 'completed' | 'result' | 'cancelled'
  entry_fee: number
  prize_pool: number
  max_players: number
  mode: string
  description?: string
  registered_players?: any[]
}

export interface Deposit {
  id: string
  amount: number
  payment_method: string
  utr: string
  screenshot_url: string
  status: 'pending' | 'completed' | 'rejected'
  timestamp: string
}
