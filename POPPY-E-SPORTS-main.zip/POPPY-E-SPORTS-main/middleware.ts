import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })
  const { data: { user }, error } = await supabase.auth.getUser()

  const publicPaths = ['/login', '/signup', '/api/auth', '/api/fetch-ff-data']
  const isPublicPath =
    req.nextUrl.pathname === '/' ||
    publicPaths.some(p => req.nextUrl.pathname.startsWith(p)) ||
    req.nextUrl.pathname.startsWith('/_next') ||
    req.nextUrl.pathname.startsWith('/favicon.ico') ||
    req.nextUrl.pathname.startsWith('/images') ||
    req.nextUrl.pathname.startsWith('/fonts') ||
    req.nextUrl.pathname.startsWith('/api/telegram-webhook')
  if (isPublicPath) return res

  if (req.nextUrl.pathname.startsWith('/admin')) {
    if (error || !user) return NextResponse.redirect(new URL('/login', req.url))

    const { data: profile, error: profileError } = await supabase
      .from('users')
      .select('is_admin')
      .eq('id', user.id)
      .maybeSingle()

    if (profileError) {
      console.error('Failed to verify admin access in middleware:', profileError.message)
      return NextResponse.redirect(new URL('/dashboard', req.url))
    }

    if (!profile?.is_admin) return NextResponse.redirect(new URL('/dashboard', req.url))
    return res
  }

  if (error || !user) {
    return NextResponse.redirect(new URL('/login', req.url))
  }
  return res
}