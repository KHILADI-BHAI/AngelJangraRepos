import { prisma } from '@/lib/prisma'

/**
 * Admin data layer.
 *
 * Primary path: Prisma (fast, typed, single transaction).
 * Fallback path: Supabase REST with the SERVICE ROLE key — bypasses RLS
 * and does NOT depend on DATABASE_URL being present in the host env.
 * This keeps the admin panel alive even if the deployed Prisma connection
 * is misconfigured.
 */

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY

interface SupabaseMeta {
  count: number
  range: { from: number; to: number; total: number } | null
}

let serviceHeaders: Record<string, string> | null = null

function supabaseHeaders(): Record<string, string> {
  if (!serviceHeaders) {
    serviceHeaders = {
      apikey: SERVICE_KEY!,
      Authorization: `Bearer ${SERVICE_KEY}`,
      'Content-Type': 'application/json',
      Prefer: 'return=representation',
    }
  }
  return serviceHeaders
}

function uuid() {
  return typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0
        const v = c === 'x' ? r : (r & 0x3) | 0x8
        return v.toString(16)
      })
}

// Tables whose id column has NO database default (Prisma @default(uuid()) is
// client-side) — REST inserts must supply id explicitly or the NOT NULL
// constraint fails.
const ID_NEEDED = new Set(['deposits', 'withdrawals', 'transactions', 'pending_referrals', 'notifications'])

function ensureId(table: string, row: Record<string, unknown>): Record<string, unknown> {
  if (ID_NEEDED.has(table) && !row.id) {
    return { id: uuid(), ...row }
  }
  return row
}

export async function restInsert(table: string, row: Record<string, unknown>) {
  if (!SUPABASE_URL || !SERVICE_KEY) throw new Error('Supabase not configured')
  const payload = ensureId(table, row)
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: supabaseHeaders(),
    body: JSON.stringify(payload),
    cache: 'no-store',
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Supabase ${table} insert failed (${res.status}): ${text}`)
  }
  const json = await res.json().catch(() => null)
  return Array.isArray(json) ? json[0] ?? null : json
}

export async function restUpdate(table: string, id: string, patch: Record<string, unknown>) {
  if (!SUPABASE_URL || !SERVICE_KEY) throw new Error('Supabase not configured')
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: supabaseHeaders(),
    body: JSON.stringify(patch),
    cache: 'no-store',
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Supabase ${table} update failed (${res.status}): ${text}`)
  }
  const json = await res.json().catch(() => null)
  return Array.isArray(json) ? json[0] ?? null : json
}

export async function restUpsert(table: string, row: Record<string, unknown>) {
  if (!SUPABASE_URL || !SERVICE_KEY) throw new Error('Supabase not configured')
  const payload = ensureId(table, row)
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: {
      ...supabaseHeaders(),
      Prefer: 'resolution=merge-duplicates,return=representation',
    },
    body: JSON.stringify(payload),
    cache: 'no-store',
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Supabase ${table} upsert failed (${res.status}): ${text}`)
  }
  const json = await res.json().catch(() => null)
  return Array.isArray(json) ? json[0] ?? null : json
}

async function restCount(table: string, eq?: { field: string; value: string }): Promise<number> {
  if (!SUPABASE_URL || !SERVICE_KEY) return 0
  let url = `${SUPABASE_URL}/rest/v1/${table}?select=id`
  if (eq) url += `&${eq.field}=eq.${encodeURIComponent(eq.value)}`
  const res = await fetch(url, {
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
      Prefer: 'count=exact',
      Range: '0-0',
    },
    cache: 'no-store',
  })
  if (!res.ok) return 0
  const meta = res.headers.get('content-range')?.match(/\/(\d+)\s*$/)
  return meta ? parseInt(meta[1], 10) : 0
}

export async function getAdminStatsFallback() {
  const [totalUsers, activeTournaments, pendingDeposits, pendingWithdrawals, completedWithdrawals, rejectedWithdrawals, totalGames, finishedTournaments] = await Promise.all([
    restCount('users'),
    restCount('tournaments', { field: 'status', value: 'upcoming' }),
    restCount('deposits', { field: 'status', value: 'pending' }),
    restCount('withdrawals', { field: 'status', value: 'pending' }),
    restCount('withdrawals', { field: 'status', value: 'completed' }),
    restCount('withdrawals', { field: 'status', value: 'rejected' }),
    restCount('games'),
    restCount('tournaments', { field: 'status', value: 'completed' }),
  ])

  return {
    totalUsers,
    activeTournaments,
    pendingDeposits,
    pendingWithdrawals,
    completedWithdrawals,
    rejectedWithdrawals,
    totalGames,
    totalPromotions: 0,
    finishedTournaments,
  }
}

async function restFetchUserNames(userIds: string[]): Promise<Record<string, { display_name: string | null; email: string | null }>> {
  if (!SUPABASE_URL || !SERVICE_KEY || userIds.length === 0) return {}
  const idList = userIds.map((id) => encodeURIComponent(id)).join(',')
  const url = `${SUPABASE_URL}/rest/v1/users?select=id,display_name,email&id=in.(${idList})`
  const res = await fetch(url, {
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
    },
    cache: 'no-store',
  })
  if (!res.ok) return {}
  const rows: any[] = await res.json()
  const map: Record<string, { display_name: string | null; email: string | null }> = {}
  for (const r of rows) {
    map[r.id] = { display_name: r.display_name ?? null, email: r.email ?? null }
  }
  return map
}

export async function getDepositsFallback() {
  if (!SUPABASE_URL || !SERVICE_KEY) return []
  const url = `${SUPABASE_URL}/rest/v1/deposits?select=id,amount,payment_method,utr,screenshot_url,timestamp,user_id&status=eq.pending&order=timestamp.desc&limit=50`
  const res = await fetch(url, {
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
    },
    cache: 'no-store',
  })
  if (!res.ok) return []
  const rows: any[] = await res.json()
  const userMap = await restFetchUserNames(rows.map((d) => d.user_id))
  return rows.map((d) => ({
    id: d.id,
    amount: d.amount,
    payment_method: d.payment_method,
    utr: d.utr,
    screenshot_url: d.screenshot_url,
    timestamp: d.timestamp,
    users: userMap[d.user_id] ?? { display_name: null, email: null },
  }))
}

export async function getWithdrawalsFallback() {
  if (!SUPABASE_URL || !SERVICE_KEY) return []
  const url = `${SUPABASE_URL}/rest/v1/withdrawals?select=id,amount,method_details,request_timestamp,user_id&status=eq.pending&order=request_timestamp.desc&limit=50`
  const res = await fetch(url, {
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
    },
    cache: 'no-store',
  })
  if (!res.ok) return []
  const rows: any[] = await res.json()
  const userMap = await restFetchUserNames(rows.map((w) => w.user_id))
  return rows.map((w) => ({
    id: w.id,
    amount: w.amount,
    methodDetails: w.method_details,
    requestTimestamp: w.request_timestamp,
    users: userMap[w.user_id] ?? { display_name: null, email: null },
  }))
}

export async function getAdminStats() {
  try {
    const [totalUsers, activeTournaments, pendingDeposits, pendingWithdrawals, completedWithdrawals, rejectedWithdrawals, totalGames, finishedTournaments] = await prisma.$transaction([
      prisma.user.count(),
      prisma.tournament.count({ where: { status: 'upcoming' } }),
      prisma.deposit.count({ where: { status: 'pending' } }),
      prisma.withdrawal.count({ where: { status: 'pending' } }),
      prisma.withdrawal.count({ where: { status: 'completed' } }),
      prisma.withdrawal.count({ where: { status: 'rejected' } }),
      prisma.game.count(),
      prisma.tournament.count({ where: { status: 'completed' } }),
    ])

    return {
      totalUsers,
      activeTournaments,
      pendingDeposits,
      pendingWithdrawals,
      completedWithdrawals,
      rejectedWithdrawals,
      totalGames,
      totalPromotions: 0,
      finishedTournaments,
    }
  } catch (error) {
    console.error('Prisma stats failed, falling back to Supabase REST:', error)
    return getAdminStatsFallback()
  }
}