import { createClientComponentClient } from '@supabase/auth-helpers-nextjs'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  if (typeof window !== 'undefined') {
    // Client-side: show a clear message instead of a white screen
    document.body.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;background:#0a0a0a;color:#fff;text-align:center;padding:20px;">
        <div>
          <h1 style="font-size:24px;margin-bottom:12px;">⚠️ Configuration Missing</h1>
          <p style="font-size:16px;color:#aaa;max-width:500px;line-height:1.6;">
            The Supabase environment variables are not set.<br/>
            Please add <code style="background:#222;padding:2px 6px;border-radius:4px;">NEXT_PUBLIC_SUPABASE_URL</code> and
            <code style="background:#222;padding:2px 6px;border-radius:4px;">NEXT_PUBLIC_SUPABASE_ANON_KEY</code>
            to your Vercel project settings.
          </p>
        </div>
      </div>
    `
  }
  throw new Error(
    'Missing Supabase environment variables. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.'
  )
}

export const supabase = createClientComponentClient({
  supabaseUrl,
  supabaseKey: supabaseAnonKey,
})