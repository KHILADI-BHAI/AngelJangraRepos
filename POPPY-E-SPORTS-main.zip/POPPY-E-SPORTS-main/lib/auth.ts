import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export const getSession = async () => {
  const supabaseServer = createServerComponentClient({ cookies })
  const { data: { session }, error } = await supabaseServer.auth.getSession()

  if (error) {
    console.error('Failed to read Supabase session:', error.message)
    return null
  }

  return session
}

export const getUser = async () => {
  const supabaseServer = createServerComponentClient({ cookies })
  const { data: { user }, error } = await supabaseServer.auth.getUser()

  if (error) {
    console.error('Failed to authenticate Supabase user:', error.message)
    return null
  }

  return user
}

export const getUserProfile = async () => {
  const supabaseServer = createServerComponentClient({ cookies })
  const { data: { user }, error: userError } = await supabaseServer.auth.getUser()

  if (userError || !user) {
    console.error('Failed to authenticate Supabase user profile:', userError?.message)
    return null
  }

  const { data: profile, error: profileError } = await supabaseServer
    .from('users')
    .select('id, is_admin')
    .eq('id', user.id)
    .maybeSingle()

  if (profileError) {
    console.error('Failed to load Supabase user profile:', profileError.message)
    return null
  }

  return {
    ...user,
    is_admin: profile?.is_admin ?? false,
  }
}