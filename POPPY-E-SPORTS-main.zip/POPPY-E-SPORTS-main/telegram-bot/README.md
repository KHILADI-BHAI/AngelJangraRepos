# POPPY ESPORTS — Telegram Deposit Bot

Fallback deposit channel when the web deposit system is offline.

## How it works

1. User submits a deposit on the Wallet page (`/api/deposits`).
2. The API tries **Prisma** → **Supabase REST**. If both fail, it returns `503 { fallbackToBot: true, botUrl }`.
3. The Wallet page shows a notice and opens the bot link in a new tab.
4. The bot captures the user's app ID via deep link (`?start=<user_id>`), asks for amount + screenshot, uploads the screenshot to ImgBB, then POSTs the record to `/api/telegram-webhook`.
5. The webhook inserts the deposit via Supabase REST (`restInsert`) — so it appears in the admin panel with status `pending`, and admins get a Telegram notification.

## Setup

### 1. Create the bot
- Open BotFather in Telegram → `/newbot` → copy the token.

### 2. Environment variables (Vercel project settings)
| Var | Value |
| --- | --- |
| `TELEGRAM_BOT_TOKEN` | Token from BotFather |
| `ADMIN_CHAT_ID` | Your admin Telegram chat ID (get from @userinfobot) |
| `NEXT_PUBLIC_TELEGRAM_BOT_URL` | `https://t.me/<your_bot_username>` |
| `TELEGRAM_WEBHOOK_SECRET` | Random long string — must match between Vercel **and** the bot host |
| `IMGBB_API_KEY` | Already used by web deposits |
| `NEXT_PUBLIC_APP_URL` | `https://poppy-e-sports.vercel.app` |

### 3. Keep the bot running (always-on host)
The bot uses long-polling (`getUpdates`), so run `telegram-bot/bot.js` on a **free always-on host** (Railway, Render, Fly.io, or a free VM). Run one instance per bot. The `offset` is tracked in-memory, so don't run two copies simultaneously.

### 4. Run
```bash
cd telegram-bot
TELEGRAM_BOT_TOKEN=... IMGBB_API_KEY=... node bot.js
```

### 5. Test
- Log in → Wallet → Add Money → submit a deposit.
- To force the fallback in testing, temporarily unset `SUPABASE_SERVICE_ROLE_KEY` on the deployed env.
- The page should show the notice and open the bot; complete the flow in Telegram; then check `/admin/deposits` — the pending deposit appears with the user's name.

## Notes
- `bot.js` is dependency-free (uses Node 18+ `fetch`/`FormData`).
- If the bot is /started without a deep link, it still records the deposit but `user_id` will be `null` — remind users to always open via the wallet page.
- The webhook endpoint (`/api/telegram-webhook`) is idempotent and also doubles as a generic deposit-notification sink for existing app deposits.