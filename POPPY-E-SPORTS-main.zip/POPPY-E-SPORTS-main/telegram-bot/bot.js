// POPPY ESPORTS Telegram deposit bot
// Long-polling, zero dependencies. Run: node bot.js
// Env: TELEGRAM_BOT_TOKEN, IMGBB_API_KEY, APP_WEBHOOK_URL (https://poppy-e-sports.vercel.app/api/telegram-webhook)
// Deep link: https://t.me/<bot>?start=<user_id>  -> links the app user to this chat.

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
const IMGBB_KEY = process.env.IMGBB_API_KEY
const WEBHOOK = process.env.APP_WEBHOOK_URL || 'https://poppy-e-sports.vercel.app/api/telegram-webhook'
const WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || ''
const UPI_ID = '9848988740'

if (!BOT_TOKEN || !IMGBB_KEY) {
  console.error('Missing TELEGRAM_BOT_TOKEN or IMGBB_API_KEY')
  process.exit(1)
}

const API = `https://api.telegram.org/bot${BOT_TOKEN}`
const sessions = new Map() // chatId -> { userId, amount }

const call = async (method, payload = {}) => {
  const res = await fetch(`${API}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error(`${method} failed: ${res.status}`)
  return res.json()
}

const send = (chatId, text, opts = {}) =>
  call('sendMessage', { chat_id: chatId, text, parse_mode: 'Markdown', ...opts })

async function uploadToImgBB(screenshot) {
  const fd = new FormData()
  fd.append('image', screenshot)
  const res = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_KEY}`, { method: 'POST', body: fd })
  const json = await res.json()
  if (!json.success) throw new Error('ImgBB upload failed')
  return json.data.url
}

async function recordDeposit(userId, amount, screenshotUrl, utr) {
  const res = await fetch(WEBHOOK, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(WEBHOOK_SECRET ? { 'x-webhook-secret': WEBHOOK_SECRET } : {}),
    },
    body: JSON.stringify({
      deposit: {
        user_id: userId,
        amount,
        payment_method: 'PhonePe',
        utr: utr || 'manual',
        screenshot_url: screenshotUrl,
      },
    }),
  })
  if (!res.ok) throw new Error(`Webhook failed: ${res.status}`)
  return res.json()
}

async function handleUpdate(u) {
  const msg = u.message
  if (!msg) return
  const chatId = msg.chat.id

  // /start with deep link ?start=<appUserId>
  if (msg.text && msg.text.startsWith('/start')) {
    const start = (msg.text.match(/\/start (.+)/) || [])[1]
    if (start) {
      sessions.set(chatId, { userId: start, amount: null })
      await send(
        chatId,
        `👋 Welcome to *POPPY ESPORTS* deposit bot!\n\nI've linked your account. Reply with the *amount* you want to deposit (₹):`
      )
    } else {
      sessions.set(chatId, { userId: null, amount: null })
      await send(
        chatId,
        `👋 Welcome to *POPPY ESPORTS*!\n\nOpen this bot from your wallet page to auto-link your account. Reply with the amount to deposit (₹):`
      )
    }
    return
  }

  const s = sessions.get(chatId)
  if (!s) {
    await send(chatId, 'Use /start to begin.')
    return
  }

  // Expecting amount
  if (s.amount === null) {
    const amount = parseFloat(msg.text)
    if (isNaN(amount) || amount <= 0) {
      await send(chatId, 'Please send a valid amount (e.g. 100).')
      return
    }
    s.amount = amount
    sessions.set(chatId, s)
    await send(chatId, `💰 Amount: ₹${amount}\n\nNow send the *payment screenshot* of the PhonePe/UPI transfer to \`${UPI_ID}\`.`)
    return
  }

  // Expecting screenshot (photo or document)
  const photo = msg.photo
  const doc = msg.document
  if (!photo && !doc) {
    await send(chatId, 'Please send the payment screenshot (photo).')
    return
  }

  try {
    await send(chatId, '⏳ Processing your deposit…')
    const fileId = photo ? photo[photo.length - 1].file_id : doc.file_id
    const fileInfo = await call('getFile', { file_id: fileId })
    const filePath = fileInfo.result.file_path
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${filePath}`
    const fileRes = await fetch(fileUrl)
    const blob = await fileRes.blob()
    const screenshotUrl = await uploadToImgBB(blob)

    const deposit = await recordDeposit(s.userId, s.amount, screenshotUrl)
    sessions.delete(chatId)
    await send(
      chatId,
      `✅ *Deposit submitted!*\n\n₹${s.amount} recorded as *pending*.\n\nOnce verified by admin, your balance will be credited. Thank you!`
    )
  } catch (err) {
    console.error('Deposit error:', err)
    await send(chatId, '❌ Something went wrong. Please try again in a bit.')
  }
}

async function poll() {
  let offset = 0
  console.log('🤖 Bot polling started…')
  for (;;) {
    try {
      const res = await call('getUpdates', { offset, timeout: 30 })
      for (const u of res.result || []) {
        offset = u.update_id + 1
        handleUpdate(u).catch((e) => console.error('handleUpdate error:', e))
      }
    } catch (err) {
      console.error('Poll error (retrying in 3s):', err.message)
      await new Promise((r) => setTimeout(r, 3000))
    }
  }
}

poll()