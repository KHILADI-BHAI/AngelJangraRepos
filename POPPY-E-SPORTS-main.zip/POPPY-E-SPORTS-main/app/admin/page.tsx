import { redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/auth'
import { getAdminStats } from '@/lib/admin-data'
import StatsCards from '@/components/admin/StatsCards'
import { Users, Trophy, Banknote, ArrowLeftRight, Share2, Sparkles } from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  let userProfile
  try {
    userProfile = await getUserProfile()
  } catch {
    redirect('/login')
  }
  if (!userProfile) redirect('/login')
  if (!userProfile.is_admin) redirect('/dashboard')

  // getAdminStats uses Prisma first, then falls back to Supabase REST (service role)
  // if the deployed DATABASE_URL is unreachable — the dashboard never goes down.
  let stats
  try {
    stats = await getAdminStats()
  } catch (error) {
    console.error('Unable to load admin dashboard stats:', error)
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
        <p className="text-red-400">The admin dashboard is temporarily unavailable because the data service is unreachable.</p>
      </div>
    )
  }

  const sections = [
    { title: 'User Management', description: 'View, ban, and manage accounts.', href: '/admin/users', icon: Users, accent: 'from-blue-500/20 to-blue-600/5 text-blue-400' },
    { title: 'Tournaments', description: 'Create and manage tournament listings.', href: '/admin/tournaments', icon: Trophy, accent: 'from-emerald-500/20 to-emerald-600/5 text-emerald-400' },
    { title: 'Deposits', description: `Review and verify deposit requests (${stats.pendingDeposits} pending).`, href: '/admin/deposits', icon: Banknote, accent: 'from-amber-500/20 to-amber-600/5 text-amber-400' },
    { title: 'Withdrawals', description: `Approve or reject withdrawals (${stats.pendingWithdrawals} pending).`, href: '/admin/withdrawals', icon: ArrowLeftRight, accent: 'from-yellow-500/20 to-yellow-600/5 text-yellow-400' },
    { title: 'Referrals', description: 'Track referral activity and rewards.', href: '/admin/referrals', icon: Share2, accent: 'from-purple-500/20 to-purple-600/5 text-purple-400' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
            Admin Dashboard
          </h1>
          <p className="text-gray-400 mt-1 text-sm sm:text-base">Manage users, tournaments, deposits, withdrawals, and referrals from one place.</p>
        </div>
      </div>

      <StatsCards stats={stats} />

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {sections.map((section) => (
          <a
            key={section.href}
            href={section.href}
            className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 hover:border-white/20 hover:bg-white/[0.08] transition-all"
          >
            <div className={`absolute inset-0 bg-gradient-to-br opacity-30 group-hover:opacity-50 transition-opacity ${section.accent}`} />
            <div className="relative flex items-start justify-between">
              <div>
                <h2 className="font-semibold text-lg">{section.title}</h2>
                <p className="text-sm text-gray-400 mt-1">{section.description}</p>
              </div>
              <div className={`h-11 w-11 rounded-xl bg-gradient-to-br flex items-center justify-center ${section.accent}`}>
                <section.icon className="h-5 w-5" />
              </div>
            </div>
            <div className="relative mt-4 flex items-center gap-1 text-sm text-gray-400 group-hover:text-white transition-colors">
              Open <Sparkles className="h-3.5 w-3.5" />
            </div>
          </a>
        ))}
      </div>
    </div>
  )
}