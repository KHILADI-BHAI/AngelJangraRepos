import { redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { getDepositsFallback } from '@/lib/admin-data'
import DepositsTable from '@/components/admin/deposits-table'

export const dynamic = 'force-dynamic'

type DepositRow = Prisma.DepositGetPayload<{
  include: { user: { select: { displayName: true; email: true } } }
}>

export default async function AdminDeposits() {
  let userProfile
  try {
    userProfile = await getUserProfile()
  } catch {
    redirect('/login')
  }
  if (!userProfile) redirect('/login')
  if (!userProfile.is_admin) redirect('/dashboard')

  // Server-side Prisma query — bypasses RLS, so deposits ALWAYS show.
  let deposits
  try {
    const rows: DepositRow[] = await prisma.deposit.findMany({
      where: { status: 'pending' },
      orderBy: { timestamp: 'desc' },
      include: { user: { select: { displayName: true, email: true } } },
      take: 50,
    })
    deposits = rows.map((d) => ({
      id: d.id,
      amount: d.amount,
      payment_method: d.paymentMethod,
      utr: d.utr,
      screenshot_url: d.screenshotUrl,
      timestamp: d.timestamp,
      users: {
        display_name: d.user?.displayName,
        email: d.user?.email,
      },
    }))
  } catch (error) {
    console.error('Prisma deposits failed, using Supabase REST fallback:', error)
    deposits = await getDepositsFallback()
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
          Pending Deposits
        </h1>
        <p className="text-gray-400 mt-1 text-sm sm:text-base">
          {deposits.length} deposit{deposits.length === 1 ? '' : 's'} awaiting verification.
        </p>
      </div>
      <DepositsTable initial={deposits} />
    </div>
  )
}