'use client'

import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, Users, Trophy, Banknote, ArrowLeftRight, Share2 } from 'lucide-react'
import { cn } from '@/lib/utils'

const nav = [
  { href: '/admin', label: 'Home', icon: LayoutDashboard },
  { href: '/admin/users', label: 'Users', icon: Users },
  { href: '/admin/tournaments', label: 'Games', icon: Trophy },
  { href: '/admin/deposits', label: 'Deposits', icon: Banknote },
  { href: '/admin/withdrawals', label: 'Payouts', icon: ArrowLeftRight },
  { href: '/admin/referrals', label: 'Referrals', icon: Share2 },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,rgba(99,102,241,0.12),transparent_50%)]">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 w-64 hidden lg:flex flex-col glass border-r border-white/10 p-4">
        <div className="flex items-center gap-2 px-2 mb-8">
          <Image
            src="/POPPY_ESPORTS.png"
            alt="POPPY ESPORTS logo"
            width={36}
            height={36}
            className="h-9 w-9 rounded-xl object-contain"
            priority
          />
          <div>
            <p className="font-bold leading-tight">POPPY</p>
            <p className="text-xs text-gray-400">Admin Portal</p>
          </div>
        </div>
        <nav className="space-y-1">
          {nav.map((item) => {
            const active = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                  active
                    ? 'bg-gradient-to-r from-indigo-500/20 to-purple-500/20 text-white border border-indigo-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>
      </aside>

      {/* Mobile bottom tab bar — app-style, thumb friendly */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 glass border-t border-white/10 pb-[env(safe-area-inset-bottom)]">
        <nav className="flex">
          {nav.map((item) => {
            const active = pathname === item.href || (item.href !== '/admin' && pathname?.startsWith(item.href))
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium transition-colors',
                  active ? 'text-indigo-400' : 'text-gray-500 hover:text-gray-300'
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </Link>
            )
          })}
        </nav>
      </div>

      {/* Mobile top brand bar */}
      <div className="lg:hidden sticky top-0 z-30 glass border-b border-white/10 px-4 py-3 flex items-center gap-2">
        <Image
          src="/POPPY_ESPORTS.png"
          alt="POPPY ESPORTS logo"
          width={28}
          height={28}
          className="h-7 w-7 rounded-lg object-contain"
        />
        <p className="font-bold text-sm leading-tight">POPPY Admin</p>
      </div>

      <main className="lg:pl-64 pb-20 lg:pb-0 px-3 sm:px-4 md:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl py-4 sm:py-6">{children}</div>
      </main>
    </div>
  )
}