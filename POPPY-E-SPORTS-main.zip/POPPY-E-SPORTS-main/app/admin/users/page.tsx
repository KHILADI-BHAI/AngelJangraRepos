'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import toast from 'react-hot-toast'

export default function AdminUsers() {
  const [users, setUsers] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [editingUserId, setEditingUserId] = useState<string | null>(null)
  const [balanceInput, setBalanceInput] = useState('')

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    const { data } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false })
    setUsers(data || [])
    setLoading(false)
  }

  const toggleBan = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'banned' : 'active'
    await supabase.from('users').update({ status: newStatus }).eq('id', id)
    fetchUsers()
    toast.success(`User ${newStatus}`)
  }

  const deleteUser = async (id: string) => {
    if (!confirm('Delete this user?')) return
    await supabase.from('users').delete().eq('id', id)
    fetchUsers()
  }

  const updateBalance = async (id: string) => {
    const nextBalance = Number(balanceInput)
    if (Number.isNaN(nextBalance)) {
      toast.error('Enter a valid number')
      return
    }

    const { error } = await supabase.from('users').update({ balance: nextBalance }).eq('id', id)
    if (error) {
      toast.error(error.message)
      return
    }

    toast.success('Balance updated')
    setEditingUserId(null)
    setBalanceInput('')
    fetchUsers()
  }

  const filtered = users.filter((u: any) =>
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.display_name?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">User Management</h1>
      <div className="flex gap-2 mb-4">
        <Input placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-sm" />
      </div>
      <div className="glass rounded-2xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-white/5">
            <tr>
              <th className="p-3 text-left">Name</th>
              <th>Email</th>
              <th>Balance</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u: any) => (
              <tr key={u.id} className="border-b border-white/5">
                <td className="p-3">{u.display_name}</td>
                <td>{u.email}</td>
                <td>₹{u.balance}</td>
                <td><span className={`px-2 py-1 rounded-full text-xs ${u.status === 'active' ? 'bg-green-500' : 'bg-red-500'}`}>{u.status}</span></td>
                <td>
                  {editingUserId === u.id ? (
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        value={balanceInput}
                        onChange={(e) => setBalanceInput(e.target.value)}
                        className="w-24"
                        placeholder="Balance"
                      />
                      <Button variant="ghost" size="sm" onClick={() => updateBalance(u.id)}>Save</Button>
                      <Button variant="ghost" size="sm" onClick={() => {
                        setEditingUserId(null)
                        setBalanceInput('')
                      }}>Cancel</Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={() => {
                        setEditingUserId(u.id)
                        setBalanceInput(String(u.balance ?? 0))
                      }}>Edit Balance</Button>
                      <Button variant="ghost" size="sm" onClick={() => toggleBan(u.id, u.status)}>
                        {u.status === 'active' ? 'Ban' : 'Unban'}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-red-400" onClick={() => deleteUser(u.id)}>Delete</Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}