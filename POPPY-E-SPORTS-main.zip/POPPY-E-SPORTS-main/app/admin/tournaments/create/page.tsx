'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import toast from 'react-hot-toast'

export default function CreateTournament() {
  const router = useRouter()
  const [games, setGames] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const [form, setForm] = useState({
    gameId: '',
    name: '',
    startTime: '',
    status: 'upcoming',
    entryFee: 0,
    prizePool: 0,
    perKillPrize: 0,
    maxPlayers: 0,
    mode: 'Solo',
    description: '',
    bannerUrl: '',
    roomId: '',
    roomPassword: '',
    showIdPass: false,
    registrationOpen: true,
  })

  useEffect(() => {
    fetchGames()
  }, [])

  const fallbackGameId = '56fd546b-22df-40e5-b495-a6bb97753bee'

  const fetchGames = async () => {
    const { data, error } = await supabase.from('games').select('id, name').order('name')

    if (error) {
      console.error('Failed to load games:', error.message)
      setGames([{ id: fallbackGameId, name: 'Free Fire' }])
      return
    }

    const availableGames = (data || []).filter((game: any) => game?.name)
    if (availableGames.length === 0) {
      setGames([{ id: fallbackGameId, name: 'Free Fire' }])
      return
    }

    setGames(availableGames)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const gameId = form.gameId || fallbackGameId
      const { data: existingGame } = await supabase.from('games').select('id').eq('id', gameId).maybeSingle()

      if (!existingGame) {
        const { data: createdGame, error: gameError } = await supabase
          .from('games')
          .insert([{ id: gameId, name: 'Free Fire' }])
          .select('id')
          .single()

        if (gameError || !createdGame) {
          throw new Error(gameError?.message || 'Unable to create game entry')
        }
      }

      const response = await fetch('/api/tournaments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          gameId,
          startTime: new Date(form.startTime).toISOString(),
        }),
      })

      let result: any = {}
      try {
        result = await response.json()
      } catch {
        result = { error: 'The server returned an empty response.' }
      }

      if (!response.ok) {
        throw new Error(result.error || 'Failed to create tournament')
      }

      toast.success('Tournament created!')
      router.push('/admin/tournaments')
    } catch (error: any) {
      console.error('Tournament create failed:', error)
      toast.error(error.message || 'Failed to create tournament')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Create Tournament</h1>
      <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-4 max-w-2xl">
        <div>
          <Label>Game</Label>
          <Select value={form.gameId} onValueChange={(v) => setForm({ ...form, gameId: v })}>
            <SelectTrigger><SelectValue placeholder="Select game" /></SelectTrigger>
            <SelectContent>
              {games.map((g: any) => (
                <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Name</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        </div>
        <div>
          <Label>Start Time</Label>
          <Input type="datetime-local" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} required />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Entry Fee (₹)</Label>
            <Input type="number" value={form.entryFee} onChange={(e) => setForm({ ...form, entryFee: parseFloat(e.target.value) })} />
          </div>
          <div>
            <Label>Prize Pool (₹)</Label>
            <Input type="number" value={form.prizePool} onChange={(e) => setForm({ ...form, prizePool: parseFloat(e.target.value) })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Per Kill Prize (₹)</Label>
            <Input type="number" value={form.perKillPrize} onChange={(e) => setForm({ ...form, perKillPrize: parseFloat(e.target.value) })} />
          </div>
          <div>
            <Label>Max Players</Label>
            <Input type="number" value={form.maxPlayers} onChange={(e) => setForm({ ...form, maxPlayers: parseInt(e.target.value) })} />
          </div>
        </div>
        <div>
          <Label>Mode</Label>
          <Select value={form.mode} onValueChange={(v) => setForm({ ...form, mode: v })}>
            <SelectTrigger><SelectValue placeholder="Select mode" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Solo">Solo</SelectItem>
              <SelectItem value="Duo">Duo</SelectItem>
              <SelectItem value="Squad">Squad</SelectItem>
              <SelectItem value="CS">CS</SelectItem>
              <SelectItem value="BR">BR</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Description</Label>
          <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </div>
        <div>
          <Label>Banner URL</Label>
          <Input value={form.bannerUrl} onChange={(e) => setForm({ ...form, bannerUrl: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Room ID</Label>
            <Input value={form.roomId} onChange={(e) => setForm({ ...form, roomId: e.target.value })} />
          </div>
          <div>
            <Label>Room Password</Label>
            <Input value={form.roomPassword} onChange={(e) => setForm({ ...form, roomPassword: e.target.value })} />
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Label className="flex items-center gap-2">
            <input type="checkbox" checked={form.showIdPass} onChange={(e) => setForm({ ...form, showIdPass: e.target.checked })} />
            Show ID/Password to users
          </Label>
          <Label className="flex items-center gap-2">
            <input type="checkbox" checked={form.registrationOpen} onChange={(e) => setForm({ ...form, registrationOpen: e.target.checked })} />
            Registration Open
          </Label>
        </div>
        <Button type="submit" disabled={loading} className="w-full">Create Tournament</Button>
      </form>
    </div>
  )
}