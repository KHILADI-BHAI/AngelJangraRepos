'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function AdminTournaments() {
  const [tournaments, setTournaments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTournaments()
  }, [])

  const fetchTournaments = async () => {
    const { data } = await supabase
      .from('tournaments')
      .select('*, games(name)')
      .order('created_at', { ascending: false })
    setTournaments(data || [])
    setLoading(false)
  }

  const deleteTournament = async (id: string) => {
    if (!confirm('Delete this tournament?')) return
    await supabase.from('tournaments').delete().eq('id', id)
    fetchTournaments()
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Tournaments</h1>
        <Link href="/admin/tournaments/create">
          <Button>Create Tournament</Button>
        </Link>
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5">
            <tr>
              <th className="p-3 text-left">Name</th>
              <th>Game</th>
              <th>Fee</th>
              <th>Prize</th>
              <th>Slots</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tournaments.map((t: any) => (
              <tr key={t.id} className="border-b border-white/5">
                <td className="p-3">{t.name}</td>
                <td>{t.games?.name}</td>
                <td>₹{t.entry_fee}</td>
                <td>₹{t.prize_pool}</td>
                <td>{t.max_players}</td>
                <td><span className={`px-2 py-1 rounded-full text-xs ${t.status === 'upcoming' ? 'bg-blue-500' : t.status === 'ongoing' ? 'bg-green-500' : 'bg-gray-500'}`}>{t.status}</span></td>
                <td>
                  <Button variant="ghost" size="sm" className="text-blue-400">Edit</Button>
                  <Button variant="ghost" size="sm" className="text-red-400" onClick={() => deleteTournament(t.id)}>Delete</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}