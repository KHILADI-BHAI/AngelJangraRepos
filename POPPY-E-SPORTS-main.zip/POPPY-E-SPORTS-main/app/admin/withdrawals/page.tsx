import { redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { getWithdrawalsFallback } from '@/lib/admin-data'
import WithdrawalsTable from '@/components/admin/withdrawals-table'

export const dynamic = 'force-dynamic'

type WithdrawalRow = Prisma.WithdrawalGetPayload<{
  include: { user: { select: { displayName: true; email: true } } }
}>

export default async function AdminWithdrawals() {
  let userProfile
  try {
    userProfile = await getUserProfile()
  } catch {
    redirect('/login')
  }
  if (!userProfile) redirect('/login')
  if (!userProfile.is_admin) redirect('/dashboard')

  let withdrawals
  try {
    const rows: WithdrawalRow[] = await prisma.withdrawal.findMany({
      where: { status: 'pending' },
      orderBy: { requestTimestamp: 'desc' },
      include: { user: { select: { displayName: true, email: true } } },
      take: 50,
    })
    withdrawals = rows.map((w) => ({
      id: w.id,
      amount: w.amount,
      methodDetails: w.methodDetails,
      requestTimestamp: w.requestTimestamp,
      users: { display_name: w.user?.displayName, email: w.user?.email },
    }))
  } catch (error) {
    console.error('Prisma withdrawals failed, using Supabase REST fallback:', error)
    withdrawals = await getWithdrawalsFallback()
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
          Pending Withdrawals
        </h1>
        <p className="text-gray-400 mt-1 text-sm sm:text-base">
          {withdrawals.length} withdrawal{withdrawals.length === 1 ? '' : 's'} awaiting verification.
        </p>
      </div>
      <WithdrawalsTable initial={withdrawals} />
    </div>
  )
}