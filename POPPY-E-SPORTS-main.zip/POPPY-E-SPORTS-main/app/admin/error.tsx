'use client'

import { Button } from '@/components/ui/button'

export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="glass rounded-2xl border border-white/10 p-10 max-w-md text-center space-y-4">
        <div className="text-5xl">⚠️</div>
        <h1 className="text-xl font-bold">Something went wrong</h1>
        <p className="text-sm text-gray-400">
          The admin page hit an unexpected error. This is usually temporary — try again.
        </p>
        {error.digest && (
          <p className="text-xs text-gray-500 font-mono">Error ID: {error.digest}</p>
        )}
        <Button onClick={reset}>Try again</Button>
      </div>
    </div>
  )
}