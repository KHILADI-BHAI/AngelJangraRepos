'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import toast from 'react-hot-toast'

export default function AdminReferralsPage() {
  const [referrals, setReferrals] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchReferrals()
  }, [])

  const fetchReferrals = async () => {
    setLoading(true)
    const { data } = await supabase
      .from('pending_referrals')
      .select('*')
      .order('timestamp', { ascending: false })
    setReferrals(data || [])
    setLoading(false)
  }

  const handleMarkCredited = async (id: string) => {
    if (!confirm('Mark this referral as credited?')) return
    const { error } = await supabase
      .from('pending_referrals')
      .update({ status: 'credited', credited_at: new Date() })
      .eq('id', id)
    if (error) {
      toast.error('Unable to update referral')
    } else {
      toast.success('Referral marked as credited')
      fetchReferrals()
    }
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Pending Referrals</h1>
      </div>
      <div className="glass rounded-2xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-white/5">
            <tr>
              <th className="p-3 text-left">Referrer UID</th>
              <th>Referred UID</th>
              <th>Status</th>
              <th>Bonus</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {referrals.map((ref) => (
              <tr key={ref.id} className="border-b border-white/5">
                <td className="p-3">{ref.referrer_uid}</td>
                <td>{ref.referred_uid}</td>
                <td>{ref.status}</td>
                <td>{ref.bonus_amount || '-'}</td>
                <td>
                  {ref.status !== 'credited' ? (
                    <Button size="sm" onClick={() => handleMarkCredited(ref.id)}>
                      Credit
                    </Button>
                  ) : (
                    <span className="text-green-400">Credited</span>
                  )}
                </td>
              </tr>
            ))}
            {!loading && referrals.length === 0 && (
              <tr>
                <td colSpan={5} className="p-4 text-center text-gray-400">
                  No pending referrals found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
