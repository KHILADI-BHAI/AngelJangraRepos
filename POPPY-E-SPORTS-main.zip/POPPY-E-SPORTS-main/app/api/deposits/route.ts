// app/api/deposits/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'
import { restInsert } from '@/lib/admin-data'

const IMGBB_API_KEY = process.env.IMGBB_API_KEY

export async function POST(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const formData = await req.formData()
  const amount = parseFloat(formData.get('amount') as string)
  const paymentMethod = formData.get('paymentMethod') as string
  const utr = formData.get('utr') as string
  const screenshot = formData.get('screenshot') as File

  if (!amount || !paymentMethod || !utr || !screenshot) {
    return NextResponse.json({ error: 'All fields are required' }, { status: 400 })
  }

  // Upload screenshot to ImgBB
  const imgbbFormData = new FormData()
  imgbbFormData.append('image', screenshot)
  const uploadRes = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
    method: 'POST',
    body: imgbbFormData,
  })
  const uploadJson = await uploadRes.json()
  if (!uploadJson.success) {
    return NextResponse.json({ error: 'Failed to upload screenshot' }, { status: 500 })
  }
  const screenshotUrl = uploadJson.data.url

  let deposit
  try {
    // Primary: Prisma (direct Postgres)
    deposit = await prisma.deposit.create({
      data: {
        userId: user.id,
        amount,
        paymentMethod,
        upiId: '9848988740', // you can fetch from settings
        utr,
        screenshotUrl,
        status: 'pending',
        timestamp: new Date(),
      },
    })
  } catch (error) {
    console.error('Prisma deposit create failed, trying Supabase REST:', error)
    try {
      // Fallback: Supabase REST (service role) — works even if DATABASE_URL is unreachable on the host
      deposit = await restInsert('deposits', {
        user_id: user.id,
        amount,
        payment_method: paymentMethod,
        upi_id: '9848988740',
        utr,
        screenshot_url: screenshotUrl,
        status: 'pending',
        timestamp: new Date().toISOString(),
      })
    } catch (restError) {
      console.error('Supabase REST deposit insert failed too:', restError)
      // Both DB paths failed — tell the client to fall back to the Telegram bot.
      return NextResponse.json(
        {
          success: false,
          error: 'Deposit system offline, please complete your deposit via Telegram',
          fallbackToBot: true,
          botUrl: process.env.NEXT_PUBLIC_TELEGRAM_BOT_URL || 'https://t.me/your_bot_username',
          depositPayload: {
            amount,
            paymentMethod,
            utr,
            screenshotUrl,
          },
        },
        { status: 503 }
      )
    }
  }

  // Send Telegram notification (async, don't await)
  fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/telegram-webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ record: deposit }),
  }).catch(console.error)

  return NextResponse.json({ success: true, deposit })
}
