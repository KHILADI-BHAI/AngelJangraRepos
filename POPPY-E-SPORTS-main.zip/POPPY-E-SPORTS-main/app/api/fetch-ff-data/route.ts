import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const uid = req.nextUrl.searchParams.get('uid')
  if (!uid) {
    return NextResponse.json({ error: 'UID is required' }, { status: 400 })
  }

  try {
    const response = await fetch(`http://187.127.175.208:5000/Bmw?uid=${uid}`)
    if (!response.ok) {
      throw new Error(`API responded with ${response.status}`)
    }
    const data = await response.json()
    return NextResponse.json(data)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Fetch failed' }, { status: 500 })
  }
}
