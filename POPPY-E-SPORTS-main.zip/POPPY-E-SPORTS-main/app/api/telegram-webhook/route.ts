import { NextRequest, NextResponse } from 'next/server'
import { restInsert } from '@/lib/admin-data'

// Bot-originated deposit persistence is guarded by a shared secret so that
// random callers can't inject fake deposits.
const WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { record, source } = body

  // Bot-originated deposits require the secret header
  if (body.deposit) {
    const presented = req.headers.get('x-webhook-secret') || ''
    if (!WEBHOOK_SECRET || presented !== WEBHOOK_SECRET) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }
  }

  const botToken = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.ADMIN_CHAT_ID

  // PhonePe UPI ID used for receiving deposits
  const UPI_ID = '9848988740'

  // BOT-ORIGINATED DEPOSIT: the Telegram bot just took a deposit from a user.
  // Persist it so it shows up in the admin panel, then notify admins on Telegram.
  if (body.deposit) {
    const d = body.deposit
    let saved: any = null
    try {
      saved = await restInsert('deposits', {
        user_id: d.user_id,
        amount: d.amount,
        payment_method: d.payment_method || 'PhonePe',
        upi_id: UPI_ID,
        utr: d.utr || '',
        screenshot_url: d.screenshot_url || '',
        status: 'pending',
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error('Failed to persist bot deposit:', error)
    }

    if (botToken && chatId) {
      const message = `
💰 *New Deposit via Telegram Bot*
User ID: ${d.user_id}
Amount: ₹${d.amount}
Payment proof: ${d.screenshot_url ? d.screenshot_url : d.utr || '—'}
      `
      await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      }).catch(console.error)
    }

    return NextResponse.json({ success: true, deposit: saved })
  }

  // SUPABASE/APP NOTIFICATION: a deposit was recorded by the app — just notify admins.
  if (record) {
    if (!botToken || !chatId) return NextResponse.json({ error: 'Missing config' }, { status: 500 })

    const message = `
💰 *New Deposit Request*
User: ${record.user_id}
Amount: ₹${record.amount}
Method: ${record.payment_method}
UTR: ${record.utr}
Screenshot: ${record.screenshot_url}
    `

    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown',
      }),
    })

    return NextResponse.json({ success: true })
  }

  // Otherwise: this is the Telegram webhook endpoint for the bot itself.
  // Bots here should be operated with a proper polling/setWebhook setup —
  // we keep this endpoint idempotent and just acknowledge.
  return NextResponse.json({ success: true })
}
