import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'
import { restInsert } from '@/lib/admin-data'

export async function POST(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { amount, method, accountDetails } = await req.json()
  if (!amount || !method || !accountDetails) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
  }

  let winningCash = 0
  try {
    const p = await prisma.user.findUnique({ where: { id: user.id } })
    winningCash = p?.winningCash ?? 0
  } catch (error) {
    console.error('Prisma balance fetch failed, using Supabase REST fallback:', error)
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/users?select=winning_cash&id=eq.${user.id}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      )
      const rows = await res.json()
      winningCash = rows?.[0]?.winning_cash ?? 0
    } catch {
      winningCash = 0
    }
  }
  if (winningCash < amount) {
    return NextResponse.json({ error: 'Insufficient winning balance' }, { status: 400 })
  }

  let withdrawal
  try {
    // Primary: Prisma (direct Postgres)
    withdrawal = await prisma.withdrawal.create({
      data: {
        userId: user.id,
        amount,
        methodDetails: { method, accountDetails },
        status: 'pending',
        requestTimestamp: new Date(),
      },
    })
  } catch (error) {
    // Fallback: Supabase REST (service role) — works even if DATABASE_URL is unreachable on the host
    console.error('Prisma withdrawal create failed, using Supabase REST fallback:', error)
    withdrawal = await restInsert('withdrawals', {
      user_id: user.id,
      amount,
      method_details: { method, accountDetails },
      status: 'pending',
      request_timestamp: new Date().toISOString(),
    })
  }

  const botToken = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.ADMIN_CHAT_ID
  if (botToken && chatId) {
    const message = `\n💸 *New Withdrawal Request*\nUser: ${user.id}\nAmount: ₹${withdrawal.amount}\nMethod: ${method}\nDetails: ${accountDetails}\nRequest ID: ${withdrawal.id}\n    `

    await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown',
      }),
    }).catch(console.error)
  }

  return NextResponse.json({ success: true, withdrawal })
}