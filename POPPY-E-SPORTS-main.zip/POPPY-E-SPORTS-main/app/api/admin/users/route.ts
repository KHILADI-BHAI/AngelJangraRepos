import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'

export async function PATCH(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await prisma.adminConfig.findFirst({ where: { adminUid: user.id } })
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { userId, balance, status } = await req.json()
  const updateData: any = {}
  if (balance !== undefined) updateData.balance = balance
  if (status) updateData.status = status

  await prisma.user.update({ where: { id: userId }, data: updateData })
  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const admin = await prisma.adminConfig.findFirst({ where: { adminUid: user.id } })
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { userId } = await req.json()
  await prisma.user.delete({ where: { id: userId } })
  return NextResponse.json({ success: true })
}