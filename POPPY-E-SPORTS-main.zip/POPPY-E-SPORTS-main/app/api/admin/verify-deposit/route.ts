import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'
import { restInsert, restUpdate } from '@/lib/admin-data'

export async function POST(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // Admin check — Prisma first, fallback to Supabase REST (users table has is_admin)
  let isAdmin: boolean | null = null
  try {
    const admin = await prisma.adminConfig.findFirst({ where: { adminUid: user.id } })
    isAdmin = !!admin
  } catch {
    isAdmin = null
  }
  if (isAdmin === null) {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/users?select=is_admin,id&id=eq.${user.id}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      )
      const rows = await res.json()
      isAdmin = !!(rows?.[0]?.is_admin)
    } catch {
      isAdmin = false
    }
  }
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { depositId, action } = await req.json()
  if (!depositId || !['complete', 'reject'].includes(action)) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  let deposit: any = null
  try {
    deposit = await prisma.deposit.findUnique({ where: { id: depositId } })
  } catch {
    deposit = null
  }
  if (!deposit) {
    // fallback: read from Supabase REST
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/deposits?select=id,user_id,amount,status&id=eq.${depositId}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      )
      const rows = await res.json()
      deposit = rows?.[0] || null
    } catch {
      deposit = null
    }
  }
  if (!deposit) return NextResponse.json({ error: 'Deposit not found' }, { status: 404 })
  if (deposit.status !== 'pending') {
    return NextResponse.json({ error: 'Deposit already processed' }, { status: 400 })
  }

  const userId = deposit.userId || deposit.user_id
  const amount = deposit.amount

  if (action === 'complete') {
    // Credit the user's balance
    let updatedBalance: number | null = null
    try {
      const updatedUser = await prisma.user.update({
        where: { id: userId },
        data: {
          balance: { increment: amount },
          winningCash: { increment: amount },
        },
      })
      updatedBalance = updatedUser.balance
      await prisma.deposit.update({
        where: { id: depositId },
        data: { status: 'completed', processedAt: new Date(), processedBy: user.id },
      })
      await prisma.transaction.create({
        data: {
          userId,
          type: 'deposit_completed',
          amount,
          description: 'Deposit verified by admin',
          timestamp: new Date(),
          balanceAfter: updatedBalance,
        },
      })
      // Referral bonus (10%)
      const userProfile = await prisma.user.findUnique({ where: { id: userId } })
      if (userProfile?.referredBy) {
        const referrer = await prisma.user.findUnique({ where: { id: userProfile.referredBy } })
        if (referrer) {
          const bonus = amount * 0.1
          await prisma.user.update({
            where: { id: referrer.id },
            data: { balance: { increment: bonus }, referralEarnings: { increment: bonus } },
          })
          await prisma.transaction.create({
            data: {
              userId: referrer.id,
              type: 'referral_spending_bonus',
              amount: bonus,
              description: `10% of spending from ${userId}`,
              timestamp: new Date(),
              balanceAfter: referrer.balance + bonus,
            },
          })
        }
      }
    } catch (error) {
      console.error('Prisma verify-deposit failed, using Supabase REST fallback:', error)
      const current = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/users?select=balance,winning_cash&id=eq.${userId}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      ).then((r) => r.json())
      const userRow = current?.[0]
      updatedBalance = (userRow?.balance ?? 0) + amount
      await restUpdate('users', userId, {
        balance: updatedBalance,
        winning_cash: (userRow?.winning_cash ?? 0) + amount,
      })
      await restUpdate('deposits', depositId, {
        status: 'completed',
        processed_at: new Date().toISOString(),
        processed_by: user.id,
      })
      await restInsert('transactions', {
        user_id: userId,
        type: 'deposit_completed',
        amount,
        description: 'Deposit verified by admin',
        timestamp: new Date().toISOString(),
        balance_after: updatedBalance,
      })
    }
  } else {
    try {
      await prisma.deposit.update({
        where: { id: depositId },
        data: { status: 'rejected', processedAt: new Date(), processedBy: user.id },
      })
    } catch (error) {
      console.error('Prisma deposit reject failed, using Supabase REST fallback:', error)
      await restUpdate('deposits', depositId, {
        status: 'rejected',
        processed_at: new Date().toISOString(),
        processed_by: user.id,
      })
    }
  }

  return NextResponse.json({ success: true })
}
