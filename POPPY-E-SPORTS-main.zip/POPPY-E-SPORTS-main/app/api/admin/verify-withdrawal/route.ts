import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'
import { restInsert, restUpdate } from '@/lib/admin-data'

export async function POST(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // Admin check — Prisma first, fallback to Supabase REST (users table has is_admin)
  let isAdmin: boolean | null = null
  try {
    const admin = await prisma.adminConfig.findFirst({ where: { adminUid: user.id } })
    isAdmin = !!admin
  } catch {
    isAdmin = null
  }
  if (isAdmin === null) {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/users?select=is_admin,id&id=eq.${user.id}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      )
      const rows = await res.json()
      isAdmin = !!(rows?.[0]?.is_admin)
    } catch {
      isAdmin = false
    }
  }
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { withdrawalId, action } = await req.json()
  if (!withdrawalId || !['approve', 'reject'].includes(action)) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  let withdrawal: any = null
  try {
    withdrawal = await prisma.withdrawal.findUnique({ where: { id: withdrawalId } })
  } catch {
    withdrawal = null
  }
  if (!withdrawal) {
    // fallback: read from Supabase REST
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/withdrawals?select=id,user_id,amount,status&id=eq.${withdrawalId}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      )
      const rows = await res.json()
      withdrawal = rows?.[0] || null
    } catch {
      withdrawal = null
    }
  }
  if (!withdrawal || withdrawal.status !== 'pending') {
    return NextResponse.json({ error: 'Withdrawal not pending' }, { status: 400 })
  }

  const userId = withdrawal.userId || withdrawal.user_id
  const amount = withdrawal.amount

  if (action === 'approve') {
    try {
      // Deduct from winningCash
      await prisma.user.update({
        where: { id: userId },
        data: { winningCash: { decrement: amount } },
      })
      await prisma.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: 'completed',
          processedAt: new Date(),
          processedBy: user.id,
        },
      })
      // Add transaction
      const userAfterUpdate = await prisma.user.findUnique({ where: { id: userId } })
      await prisma.transaction.create({
        data: {
          userId,
          type: 'withdrawal_completed',
          amount: -amount,
          description: `Withdrawal approved`,
          timestamp: new Date(),
          balanceAfter: userAfterUpdate?.winningCash ?? 0,
        },
      })
    } catch (error) {
      console.error('Prisma verify-withdrawal failed, using Supabase REST fallback:', error)
      const current = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/users?select=winning_cash&id=eq.${userId}`,
        {
          headers: {
            apikey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
            Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          },
          cache: 'no-store',
        }
      ).then((r) => r.json())
      const userRow = current?.[0]
      const newWinningCash = (userRow?.winning_cash ?? 0) - amount
      await restUpdate('users', userId, { winning_cash: newWinningCash })
      await restUpdate('withdrawals', withdrawalId, {
        status: 'completed',
        processed_at: new Date().toISOString(),
        processed_by: user.id,
      })
      await restInsert('transactions', {
        user_id: userId,
        type: 'withdrawal_completed',
        amount: -amount,
        description: 'Withdrawal approved',
        timestamp: new Date().toISOString(),
        balance_after: newWinningCash,
      })
    }
  } else {
    // Reject – no balance change
    try {
      await prisma.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: 'rejected',
          processedAt: new Date(),
          processedBy: user.id,
          rejectReason: 'Rejected by admin',
        },
      })
    } catch (error) {
      console.error('Prisma withdrawal reject failed, using Supabase REST fallback:', error)
      await restUpdate('withdrawals', withdrawalId, {
        status: 'rejected',
        processed_at: new Date().toISOString(),
        processed_by: user.id,
        reject_reason: 'Rejected by admin',
      })
    }
  }

  return NextResponse.json({ success: true })
}
