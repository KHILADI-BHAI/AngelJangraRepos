import { NextRequest, NextResponse } from 'next/server'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { fee } = await req.json()
    const tournamentId = params.id

    const { data: tournament, error: tournamentError } = await supabase
      .from('tournaments')
      .select('id, name, status, max_players')
      .eq('id', tournamentId)
      .single()

    if (tournamentError || !tournament) {
      return NextResponse.json({ error: 'Tournament not found' }, { status: 404 })
    }

    if (tournament.status !== 'upcoming') {
      return NextResponse.json({ error: 'Registration is closed' }, { status: 400 })
    }

    const { data: joinedPlayers, error: joinCheckError } = await supabase
      .from('registered_players')
      .select('tournament_id')
      .eq('tournament_id', tournamentId)
      .eq('user_id', user.id)

    if (joinCheckError) {
      return NextResponse.json({ error: joinCheckError.message }, { status: 500 })
    }

    if ((joinedPlayers || []).length > 0) {
      return NextResponse.json({ error: 'Already joined' }, { status: 400 })
    }

    const { count: registeredCount, error: countError } = await supabase
      .from('registered_players')
      .select('tournament_id', { count: 'exact', head: true })
      .eq('tournament_id', tournamentId)

    if (countError) {
      return NextResponse.json({ error: countError.message }, { status: 500 })
    }

    if (tournament.max_players > 0 && (registeredCount || 0) >= tournament.max_players) {
      return NextResponse.json({ error: 'Tournament is full' }, { status: 400 })
    }

    const { data: userProfile, error: profileError } = await supabase
      .from('users')
      .select('id, balance, display_name, game_uid, email')
      .eq('id', user.id)
      .single()

    if (profileError || !userProfile) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    if ((userProfile.balance || 0) < fee) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 })
    }

    const nextBalance = (userProfile.balance || 0) - fee

    const { error: balanceError } = await supabase
      .from('users')
      .update({ balance: nextBalance })
      .eq('id', user.id)

    if (balanceError) {
      return NextResponse.json({ error: balanceError.message }, { status: 500 })
    }

    const { error: registerError } = await supabase.from('registered_players').insert([
      {
        tournament_id: tournamentId,
        user_id: user.id,
        username: userProfile.display_name || userProfile.email,
        game_uid: userProfile.game_uid || null,
        joined_at: new Date().toISOString(),
      },
    ])

    if (registerError) {
      return NextResponse.json({ error: registerError.message }, { status: 500 })
    }

    const { error: transactionError } = await supabase.from('transactions').insert([
      {
        id: crypto.randomUUID(),
        user_id: user.id,
        type: 'tournament_join',
        amount: -fee,
        description: `Joined tournament ${tournament.name}`,
        timestamp: new Date().toISOString(),
        balance_after: nextBalance,
      },
    ])

    if (transactionError) {
      return NextResponse.json({ error: transactionError.message }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Tournament join failed:', error)
    return NextResponse.json({ error: error?.message || 'Failed to join tournament' }, { status: 500 })
  }
}
