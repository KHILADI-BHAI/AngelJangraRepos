import { NextRequest, NextResponse } from 'next/server'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export async function GET() {
  const supabase = createRouteHandlerClient({ cookies })
  const { data: tournaments, error } = await supabase
    .from('tournaments')
    .select('*, games:game_id(*)')
    .eq('status', 'upcoming')
    .order('start_time', { ascending: true })
    .limit(20)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json(tournaments)
}

export async function POST(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()

    if (userError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile, error: profileError } = await supabase
      .from('users')
      .select('is_admin')
      .eq('id', user.id)
      .maybeSingle()

    if (profileError || !profile?.is_admin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await req.json()
    const { data, error } = await supabase.from('tournaments').insert([
      {
        id: crypto.randomUUID(),
        game_id: body.gameId,
        name: body.name,
        start_time: body.startTime,
        status: body.status || 'upcoming',
        entry_fee: body.entryFee ?? 0,
        prize_pool: body.prizePool ?? 0,
        per_kill_prize: body.perKillPrize ?? 0,
        max_players: body.maxPlayers ?? 0,
        mode: body.mode || 'Solo',
        description: body.description || '',
        banner_url: body.bannerUrl || null,
        room_id: body.roomId || null,
        room_password: body.roomPassword || null,
        show_id_pass: body.showIdPass ?? false,
        registration_open: body.registrationOpen ?? true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ]).select('*')

    if (error) {
      throw new Error(error.message)
    }

    return NextResponse.json(data?.[0] || null, { status: 201 })
  } catch (error: any) {
    console.error('Tournament creation failed:', error)
    return NextResponse.json(
      { error: error?.message || 'Failed to create tournament' },
      { status: 500 }
    )
  }
}
