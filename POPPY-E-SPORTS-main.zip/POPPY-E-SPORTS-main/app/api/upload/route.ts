import { NextRequest, NextResponse } from 'next/server'

const IMGBB_API_KEY = process.env.IMGBB_API_KEY

export async function POST(req: NextRequest) {
  const formData = await req.formData()
  const file = formData.get('file') as File
  if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 })

  const imgbbForm = new FormData()
  imgbbForm.append('image', file)

  const res = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
    method: 'POST',
    body: imgbbForm,
  })
  const data = await res.json()
  if (!data.success) return NextResponse.json({ error: 'Upload failed' }, { status: 500 })
  return NextResponse.json({ url: data.data.url })
}
