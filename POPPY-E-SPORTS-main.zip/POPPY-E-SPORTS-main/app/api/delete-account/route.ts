// app/api/delete-account/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getUser } from '@/lib/auth'
import { createClient } from '@supabase/supabase-js'

export async function POST(req: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { userId } = await req.json()
  if (userId !== user.id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  try {
    // Delete all user data
    await prisma.$transaction([
      prisma.transaction.deleteMany({ where: { userId } }),
      prisma.registeredPlayer.deleteMany({ where: { userId } }),
      prisma.pendingReferral.deleteMany({ where: { OR: [{ referrerUid: userId }, { referredUid: userId }] } }),
      prisma.userNotification.deleteMany({ where: { userId } }),
      prisma.withdrawal.deleteMany({ where: { userId } }),
      prisma.deposit.deleteMany({ where: { userId } }),
      prisma.user.delete({ where: { id: userId } }),
    ])

    // Delete auth user using admin API (requires service role key)
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    )
    await supabaseAdmin.auth.admin.deleteUser(userId)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}