'use client'

import { useState } from 'react'
import Image from 'next/image'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'

export default function SignupPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [referral, setReferral] = useState('')

  const [uid, setUid] = useState('')
  const [fetchedData, setFetchedData] = useState<any>(null)
  const [uidError, setUidError] = useState('')

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name || !email || !phone || !password) {
      setError('All fields are required')
      return
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    setError('')
    setStep(2)
  }

  const handleFetchUID = async () => {
    if (!uid) {
      setUidError('Enter your Free Fire UID')
      return
    }
    setUidError('')
    setLoading(true)
    console.log('[SIGNUP] Fetching FF UID:', uid)

    try {
      const res = await fetch(`/api/fetch-ff-data?uid=${uid}`)
      console.log('[SIGNUP] FF API status:', res.status)
      if (!res.ok) throw new Error('UID not found')
      const data = await res.json()
      console.log('[SIGNUP] FF API data:', data)
      setFetchedData(data)
    } catch (err: any) {
      console.log('[SIGNUP] FF API error:', err.message)
      setUidError(err.message || 'Failed to fetch UID')
    } finally {
      setLoading(false)
    }
  }

  const handleFinalSignup = async () => {
    if (!fetchedData) return
    setLoading(true)
    setError('')
    console.log('[SIGNUP] Beginning final signup for email:', email)

    try {
      console.log('[SIGNUP] Calling supabase.auth.signUp...')
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { display_name: name, phone_number: phone } },
      })
      console.log('[SIGNUP] signUp result:', { authData, authError })
      if (authError) throw authError

      const userId = authData.user?.id
      if (!userId) throw new Error('User creation failed')

      const basic = fetchedData.basic_info || {}
      const clan = fetchedData.clan_basic_info || {}
      const profile = {
        id: userId,
        email,
        display_name: name,
        phone_number: phone,
        balance: 10,
        winning_cash: 0,
        bonus_cash: 10,
        status: 'active',
        referral_code: Math.random().toString(36).substring(2, 10).toUpperCase(),
        referred_by: null,
        created_at: new Date(),
        free_fire_uid: uid,
        ff_nickname: basic.nickname || null,
        ff_clan_id: clan.clan_id || null,
        ff_clan_name: clan.clan_name || null,
        ff_verified: true,
        deleted: false,
      }

      const { data: existingUser, error: existingError } = await supabase
        .from('users')
        .select('id')
        .eq('email', email)
        .maybeSingle()

      if (existingError) throw existingError

      if (existingUser) {
        const { error: profileError } = await supabase
          .from('users')
          .update({
            display_name: name,
            phone_number: phone,
            balance: 10,
            winning_cash: 0,
            bonus_cash: 10,
            status: 'active',
            referral_code: profile.referral_code,
            referred_by: profile.referred_by,
            free_fire_uid: uid,
            ff_nickname: profile.ff_nickname,
            ff_clan_id: profile.ff_clan_id,
            ff_clan_name: profile.ff_clan_name,
            ff_verified: profile.ff_verified,
            deleted: profile.deleted,
          })
          .eq('email', email)

        if (profileError) throw profileError
      } else {
        const { error: profileError } = await supabase
          .from('users')
          .insert(profile)
        if (profileError) throw profileError
      }

      if (referral) {
        const { data: referrer } = await supabase
          .from('users')
          .select('id, balance')
          .eq('referral_code', referral)
          .single()

        if (referrer) {
          const bonus = 10
          await supabase
            .from('users')
            .update({ balance: (referrer.balance || 0) + bonus })
            .eq('id', referrer.id)
          await supabase
            .from('transactions')
            .insert({
              user_id: referrer.id,
              type: 'referral_bonus',
              amount: bonus,
              description: `Referral bonus for inviting ${email}`,
              timestamp: new Date(),
              balance_after: (referrer.balance || 0) + bonus,
            })
          await supabase
            .from('pending_referrals')
            .insert({
              referrer_uid: referrer.id,
              referred_uid: userId,
              status: 'credited',
              timestamp: new Date(),
              credited_at: new Date(),
              bonus_amount: bonus,
            })
          await supabase
            .from('users')
            .update({ referred_by: referrer.id })
            .eq('id', userId)
        }
      }

      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password })
      if (signInError) throw signInError

      router.push('/dashboard')
    } catch (err: any) {
      setError(err.message || 'Signup failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <Card className="glass border-0 shadow-2xl">
        <CardHeader>
          <div className="flex justify-center mb-3">
            <Image
              src="/POPPY_ESPORTS.png"
              alt="POPPY ESPORTS logo"
              width={56}
              height={56}
              className="h-14 w-14 rounded-2xl object-contain"
              priority
            />
          </div>
          <CardTitle className="text-2xl text-center text-primary">Join POPPY ESPORTS</CardTitle>
          <CardDescription className="text-center">Create your account and verify your Free Fire UID</CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <form onSubmit={handleStep1Submit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password (min 6 chars)</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="referral">Referral Code (optional)</Label>
                <Input id="referral" value={referral} onChange={(e) => setReferral(e.target.value)} />
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button type="submit" className="w-full">Next →</Button>
            </form>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-gray-400 text-sm">Verify your Free Fire UID</p>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter Free Fire UID"
                  value={uid}
                  onChange={(e) => setUid(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={handleFetchUID} disabled={loading} variant="outline">Fetch</Button>
              </div>
              {uidError && <p className="text-red-500 text-sm">{uidError}</p>}
              {fetchedData && (
                <div className="glass p-4 rounded-xl space-y-2">
                  <div className="flex justify-between"><span>Nickname</span><span className="text-primary">{fetchedData.basic_info?.nickname || 'N/A'}</span></div>
                  <div className="flex justify-between"><span>Region</span><span>{fetchedData.basic_info?.region || 'N/A'}</span></div>
                  <div className="flex justify-between"><span>Level</span><span>{fetchedData.basic_info?.level || 'N/A'}</span></div>
                  {fetchedData.clan_basic_info?.clan_name && (
                    <div className="flex justify-between"><span>Clan</span><span>{fetchedData.clan_basic_info.clan_name}</span></div>
                  )}
                  <Button onClick={handleFinalSignup} disabled={loading} className="w-full bg-green-500 hover:bg-green-400 text-black">
                    {loading ? 'Creating...' : 'Verify & Create Account'}
                  </Button>
                </div>
              )}
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button variant="ghost" onClick={() => setStep(1)} className="w-full text-gray-400">← Back</Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-gray-400">
            Already have an account? <Link href="/login" className="text-primary hover:underline">Login</Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}
