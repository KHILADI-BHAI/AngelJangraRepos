'use client'

import { useState } from 'react'
import Image from 'next/image'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    console.log('[LOGIN] Attempting login with email:', email)
    console.log('[LOGIN] Supabase URL:', process.env.NEXT_PUBLIC_SUPABASE_URL)
    console.log('[LOGIN] App URL:', process.env.NEXT_PUBLIC_APP_URL)
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password })
      console.log('[LOGIN] Response data:', data)
      console.log('[LOGIN] Response error:', error)
      if (error) {
        setError(error.message)
        console.log('[LOGIN] FAILED:', error.message)
      } else {
        console.log('[LOGIN] SUCCESS - redirecting to /dashboard')
        router.push('/dashboard')
      }
    } catch (err) {
      console.log('[LOGIN] EXCEPTION:', err)
      setError('Something went wrong. Please check the console for details.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-md">
      <Card className="glass border-0 shadow-2xl">
        <CardHeader>
          <div className="flex justify-center mb-3">
            <Image
              src="/POPPY_ESPORTS.png"
              alt="POPPY ESPORTS logo"
              width={56}
              height={56}
              className="h-14 w-14 rounded-2xl object-contain"
              priority
            />
          </div>
          <CardTitle className="text-2xl text-center text-primary">Login</CardTitle>
          <CardDescription className="text-center">Welcome back to POPPY ESPORTS</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            {error && <p className="text-red-500 text-sm">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <p className="text-sm text-gray-400">
            Don't have an account? <Link href="/signup" className="text-primary hover:underline">Sign Up</Link>
          </p>
          <p className="text-sm">
            <Link href="/forgot-password" className="text-gray-500 hover:text-primary">Forgot password?</Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}