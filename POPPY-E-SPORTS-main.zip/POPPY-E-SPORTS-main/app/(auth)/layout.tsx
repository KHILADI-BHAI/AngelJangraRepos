export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="min-h-screen flex items-center justify-center px-4 sm:px-6 py-6 sm:py-10">
      <div className="w-full max-w-md">
        {children}
      </div>
    </main>
  )
}