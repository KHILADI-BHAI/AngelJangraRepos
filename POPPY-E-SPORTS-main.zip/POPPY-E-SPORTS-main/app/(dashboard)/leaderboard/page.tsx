'use client'

import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export default function LeaderboardPage() {
  const { data: players } = useQuery({
    queryKey: ['leaderboard'],
    queryFn: async () => {
      const { data } = await supabase
        .from('users')
        .select('display_name, total_earnings, photo_url')
        .order('total_earnings', { ascending: false })
        .limit(50)
      return data
    },
  })

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Leaderboard</h1>
      <div className="glass rounded-2xl p-6 space-y-2">
        {players?.map((player, index) => (
          <div key={index} className="flex items-center justify-between py-2 border-b border-white/5">
            <div className="flex items-center gap-4">
              <span className="font-bold text-lg">#{index + 1}</span>
              <span>{player.display_name}</span>
            </div>
            <span className="text-primary">₹{player.total_earnings || 0}</span>
          </div>
        ))}
      </div>
    </div>
  )
}