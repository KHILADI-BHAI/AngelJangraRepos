'use client'

import { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'

export default function ReferralsPage() {
  const { user } = useAuth()
  const [origin, setOrigin] = useState('')

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setOrigin(window.location.origin)
    }
  }, [])

  const { data: referrals } = useQuery({
    queryKey: ['referrals', user?.id],
    queryFn: async () => {
      if (!user?.id) return []
      const { data } = await supabase
        .from('pending_referrals')
        .select('*, referred:users!referred_uid(display_name, email)')
        .eq('referrer_uid', user.id)
        .order('timestamp', { ascending: false })
      return data
    },
    enabled: !!user,
  })

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Referrals</h1>
      <div className="glass rounded-2xl p-6">
        <p className="text-gray-400">Your referral link:</p>
        <p className="text-primary font-mono">{origin ? `${origin}/signup?ref=${user?.id}` : 'Loading...'}</p>
        <div className="mt-6 space-y-2">
          {referrals?.map((ref) => (
            <div key={ref.id} className="flex justify-between py-2 border-b border-white/5">
              <span>{ref.referred?.display_name}</span>
              <span className={ref.status === 'credited' ? 'text-green-400' : 'text-yellow-400'}>
                {ref.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}