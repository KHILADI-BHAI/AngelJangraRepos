'use client'

import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'
import { useAuth } from '@/hooks/useAuth'
import { TournamentCard } from '@/components/tournament/TournamentCard'
import { BalanceCard } from '@/components/wallet/BalanceCard'

export default function DashboardPage() {
  const { user, profile } = useAuth()

  const { data: tournaments } = useQuery({
    queryKey: ['upcoming-tournaments'],
    queryFn: async () => {
      const { data } = await supabase
        .from('tournaments')
        .select('*, games(name, image_url)')
        .eq('status', 'upcoming')
        .order('start_time', { ascending: true })
        .limit(6)
      return data
    },
  })

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 glass rounded-2xl p-6">
          <h2 className="text-xl font-bold mb-4">🔥 Upcoming Tournaments</h2>
          <div className="space-y-4">
            {tournaments?.map((t) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
          {(!tournaments || tournaments.length === 0) && (
            <p className="text-gray-400">No upcoming tournaments at the moment.</p>
          )}
          <div className="mt-4">
            <Link href="/tournaments" className="text-primary hover:underline">View all →</Link>
          </div>
        </div>
        <div className="glass rounded-2xl p-6">
          <BalanceCard profile={profile} />
        </div>
      </div>
    </div>
  )
}