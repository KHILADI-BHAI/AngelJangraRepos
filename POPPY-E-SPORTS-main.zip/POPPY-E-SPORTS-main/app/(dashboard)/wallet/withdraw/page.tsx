'use client'

import { useState } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import toast from 'react-hot-toast'

export default function WithdrawPage() {
  const { profile } = useAuth()
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('UPI')
  const [details, setDetails] = useState('')
  const [loading, setLoading] = useState(false)

  const availableBalance = profile?.winningCash ?? 0

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    const withdrawAmount = parseFloat(amount)
    if (!withdrawAmount || withdrawAmount <= 0) {
      toast.error('Enter a valid withdrawal amount')
      return
    }

    if (withdrawAmount > availableBalance) {
      toast.error('Insufficient withdrawal balance')
      return
    }

    if (!details.trim()) {
      toast.error('Please enter account details or UPI ID')
      return
    }

    setLoading(true)

    try {
      const res = await fetch('/api/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: withdrawAmount,
          method,
          accountDetails: details.trim(),
        }),
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to request withdrawal')

      toast.success('Withdrawal request submitted')
      setAmount('')
      setDetails('')
    } catch (error: any) {
      toast.error(error.message || 'Unable to submit withdrawal')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold">Withdraw Funds</h1>
        <p className="text-sm text-gray-400 max-w-2xl">
          Request a withdrawal from your winning balance. Your request will be forwarded to the admin team via Telegram.
        </p>
      </div>

      <div className="glass rounded-3xl p-6 space-y-6">
        <div>
          <p className="text-sm text-gray-400">Available withdrawable balance</p>
          <p className="text-3xl font-bold text-green-400">₹{availableBalance}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            id="withdraw-amount"
            name="amount"
            type="number"
            placeholder="Amount (₹)"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
            min="1"
            step="0.01"
            required
          />

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-200">Withdrawal Method</label>
            <select
              id="withdraw-method"
              name="method"
              className="w-full rounded-xl border border-white/10 bg-black/10 px-4 py-3 text-white outline-none focus:border-primary"
              value={method}
              onChange={(event) => setMethod(event.target.value)}
            >
              <option value="UPI">UPI</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Paytm">Paytm</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-200">Account details / UPI ID</label>
            <textarea
              id="withdraw-details"
              name="details"
              className="w-full min-h-[120px] rounded-xl border border-white/10 bg-black/10 px-4 py-3 text-white outline-none focus:border-primary"
              placeholder="Enter your UPI ID, bank account details, or other payout information"
              value={details}
              onChange={(event) => setDetails(event.target.value)}
              required
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? 'Submitting...' : 'Request Withdrawal'}
          </Button>
        </form>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-gray-300">
          <p className="font-medium">Need help?</p>
          <p>
            Once submitted, the admin will receive a Telegram notification and can process your request.
          </p>
        </div>
      </div>
    </div>
  )
}
