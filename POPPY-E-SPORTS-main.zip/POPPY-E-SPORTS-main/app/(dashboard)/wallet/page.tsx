'use client'

import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import toast from 'react-hot-toast'

export default function WalletPage() {
  const { user, profile } = useAuth()
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const [file, setFile] = useState<File | null>(null)

  const { data: transactions, refetch } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user?.id)
        .order('timestamp', { ascending: false })
        .limit(10)
      return data
    },
    enabled: !!user,
  })

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount || !file) {
      toast.error('Amount and screenshot are required')
      return
    }
    setLoading(true)
    const formData = new FormData()
    formData.append('amount', amount)
    formData.append('paymentMethod', 'PhonePe')
    formData.append('utr', 'manual')
    formData.append('screenshot', file)
    try {
      const res = await fetch('/api/deposits', {
        method: 'POST',
        body: formData,
      })
      const data = await res.json()
      if (!res.ok) {
        // Deposit system is down — offer the Telegram bot fallback
        if (data.fallbackToBot) {
          toast.error(data.error || 'Deposit system offline')
          const botUrl = data.botUrl || 'https://t.me/your_bot_username'
          const confirmed = window.confirm(
            '⚠️ The web deposit is temporarily unavailable.\n\nYou will be redirected to our Telegram bot to complete the deposit. Continue?'
          )
          if (confirmed) {
            window.open(botUrl, '_blank', 'noopener,noreferrer')
          }
          setAmount('')
          setFile(null)
          return
        }
        throw new Error(data.error)
      }
      toast.success('Deposit submitted for verification')
      setAmount('')
      setFile(null)
      refetch()
    } catch (error: any) {
      toast.error(error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Wallet</h1>
      <div className="glass rounded-2xl p-6">
        <p className="text-3xl font-bold text-green-400">₹{profile?.balance || 0}</p>
        <p className="text-gray-400">Total Balance</p>
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="text-xl font-bold mb-4">Add Money</h2>
        <form onSubmit={handleDeposit} className="space-y-4">
          <Input
            id="deposit-amount"
            name="amount"
            type="number"
            placeholder="Amount (₹)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min="10"
            required
          />
          <Input
            id="deposit-screenshot"
            name="screenshot"
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            required
          />
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? 'Submitting...' : 'Submit Deposit'}
          </Button>
        </form>
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="text-xl font-bold mb-4">Recent Transactions</h2>
        {transactions?.map((t) => (
          <div key={t.id} className="flex justify-between py-2 border-b border-white/5">
            <div>
              <p className="font-medium">{t.description}</p>
              <p className="text-sm text-gray-400">{new Date(t.timestamp).toLocaleString()}</p>
            </div>
            <span className={t.amount > 0 ? 'text-green-400' : 'text-red-400'}>
              {t.amount > 0 ? '+' : ''}{t.amount}
            </span>
          </div>
        ))}
        {(!transactions || transactions.length === 0) && (
          <p className="text-gray-400">No transactions yet.</p>
        )}
      </div>
    </div>
  )
}