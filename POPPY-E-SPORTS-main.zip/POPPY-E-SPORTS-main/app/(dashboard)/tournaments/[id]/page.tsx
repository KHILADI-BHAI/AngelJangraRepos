'use client'

import { useQuery } from '@tanstack/react-query'
import { useParams } from 'next/navigation'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/hooks/useAuth'
import toast from 'react-hot-toast'

export default function TournamentDetailPage() {
  const { id } = useParams()
  const { user, refetch: refetchProfile } = useAuth()
  const [joining, setJoining] = useState(false)

  const { data: tournament, refetch } = useQuery({
    queryKey: ['tournament', id],
    queryFn: async () => {
      const { data } = await supabase
        .from('tournaments')
        .select('*, game:games(name, image_url), registered_players(*)')
        .eq('id', id)
        .single()
      return data
    },
    enabled: !!id,
  })

  const handleJoin = async () => {
    if (!id || !tournament) return
    setJoining(true)

    try {
      const res = await fetch(`/api/tournaments/${id}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fee: tournament.entry_fee }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Unable to join tournament')
      toast.success('Joined tournament successfully')
      // Immediately refresh the balance/profile on screen (no reload needed)
      void refetchProfile()
      refetch()
    } catch (error: any) {
      toast.error(error.message)
    } finally {
      setJoining(false)
    }
  }

  if (!tournament) {
    return <div>Loading tournament...</div>
  }

  const joined = tournament.registered_players?.some((player: any) => player.user_id === user?.id)
  const isUpcoming = tournament.status === 'upcoming'
  const registeredCount = tournament.registered_players?.length || 0

  return (
    <div className="space-y-6">
      <div className="glass rounded-2xl p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">{tournament.name}</h1>
            <p className="text-gray-400">{new Date(tournament.start_time).toLocaleString()}</p>
          </div>
          <div className="space-y-2 text-right">
            <p className="text-sm text-gray-400">Status</p>
            <span className="inline-flex rounded-full bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
              {tournament.status}
            </span>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 mt-6">
          <div className="space-y-3">
            <p className="text-gray-400">Game</p>
            <p className="text-lg font-semibold">{tournament.game?.name || 'Unknown'}</p>
          </div>
          <div className="space-y-3">
            <p className="text-gray-400">Entry Fee</p>
            <p className="text-lg font-semibold">₹{tournament.entry_fee}</p>
          </div>
          <div className="space-y-3">
            <p className="text-gray-400">Prize Pool</p>
            <p className="text-lg font-semibold">₹{tournament.prize_pool}</p>
          </div>
          <div className="space-y-3">
            <p className="text-gray-400">Registered</p>
            <p className="text-lg font-semibold">{registeredCount}/{tournament.max_players || '∞'}</p>
          </div>
        </div>

        {tournament.description && (
          <div className="mt-6 rounded-2xl bg-white/5 p-4">
            <h2 className="text-lg font-semibold">Description</h2>
            <p className="mt-2 text-gray-300">{tournament.description}</p>
          </div>
        )}

        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button
            onClick={handleJoin}
            disabled={!isUpcoming || joining || joined || (tournament.max_players > 0 && registeredCount >= tournament.max_players)}
          >
            {joined ? 'Already Joined' : isUpcoming ? joining ? 'Joining...' : 'Join Tournament' : 'Registration closed'}
          </Button>
          {!user && (
            <span className="text-sm text-gray-400">You must be logged in to join.</span>
          )}
          {user && (
            <span className="text-sm text-gray-400">
              {joined ? 'You have joined this tournament.' : isUpcoming ? 'Registration is open for upcoming tournaments.' : 'Only upcoming tournaments can be joined.'}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
