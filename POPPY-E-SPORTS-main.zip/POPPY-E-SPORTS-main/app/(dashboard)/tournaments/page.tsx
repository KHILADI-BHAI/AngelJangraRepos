'use client'

import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { useState } from 'react'
import { TournamentCard } from '@/components/tournament/TournamentCard'

export default function TournamentsPage() {
  const [filter, setFilter] = useState('upcoming')

  const { data: tournaments } = useQuery({
    queryKey: ['tournaments', filter],
    queryFn: async () => {
      const { data } = await supabase
        .from('tournaments')
        .select('*, games(name, image_url)')
        .eq('status', filter)
        .order('start_time', { ascending: true })
      return data
    },
  })

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Tournaments</h1>
      <div className="flex gap-2 mb-6">
        {['upcoming', 'ongoing', 'completed'].map((status) => (
          <button
            key={status}
            className={`px-4 py-2 rounded-lg ${filter === status ? 'bg-primary text-black' : 'bg-white/5'}`}
            onClick={() => setFilter(status)}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>
      <div className="space-y-4">
        {tournaments?.map((t: any) => (
          <TournamentCard key={t.id} tournament={t} />
        ))}
        {(!tournaments || tournaments.length === 0) && (
          <p className="text-gray-400">No {filter} tournaments found.</p>
        )}
      </div>
    </div>
  )
}
