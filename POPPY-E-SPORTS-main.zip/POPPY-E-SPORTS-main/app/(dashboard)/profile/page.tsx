'use client'

import { useState } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

export default function ProfilePage() {
  const { user, profile, refetch } = useAuth()
  const router = useRouter()
  const [displayName, setDisplayName] = useState(profile?.display_name || '')
  const [loading, setLoading] = useState(false)

  const updateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user?.id) return
    setLoading(true)
    const { error } = await supabase
      .from('users')
      .update({ display_name: displayName })
      .eq('id', user.id)
    if (error) {
      toast.error(error.message)
    } else {
      toast.success('Profile updated')
      refetch()
    }
    setLoading(false)
  }

  const deleteAccount = async () => {
    if (!user?.id) return
    if (!confirm('Are you sure you want to permanently delete your account? This cannot be undone.')) return
    setLoading(true)
    try {
      const res = await fetch('/api/delete-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success('Account deleted')
      router.push('/')
    } catch (error: any) {
      toast.error(error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Profile</h1>
      <div className="glass rounded-2xl p-6">
        <form onSubmit={updateProfile} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400">Email</label>
            <p className="font-medium">{user?.email}</p>
          </div>
          <div>
            <label className="block text-sm text-gray-400">Display Name</label>
            <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          </div>
          <Button type="submit" disabled={loading}>Update Profile</Button>
        </form>
      </div>
      <div className="glass rounded-2xl p-6 border border-red-500/20">
        <h2 className="text-xl font-bold text-red-500">Danger Zone</h2>
        <Button variant="destructive" onClick={deleteAccount} disabled={loading}>
          Delete Account
        </Button>
      </div>
    </div>
  )
}
