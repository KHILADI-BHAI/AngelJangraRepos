# 🎮 POPPY ESPORTS – Full‑Stack Tournament Platform

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FAngelJangra%2FPOPPY-E-SPORTS)

**POPPY ESPORTS** is a complete, production‑ready Free Fire tournament platform. Players can register, verify their Free Fire UID, join tournaments, pay entry fees, and earn real rewards – all automated.

---

## 🚀 Features

- **Authentication** – Email/Password, Google, Phone OTP (via Supabase)
- **UID Verification** – Fetch and verify Free Fire UID, clan, and player details
- **Tournaments** – Upcoming, live, completed; join with fee deduction
- **Wallet** – Balance, deposit (with screenshot upload), withdraw, transaction history
- **Admin Panel** – Full CRUD for tournaments, users, deposits, withdrawals, referrals
- **Referral System** – ₹10 instant bonus per referral + 10% of referred user's spending
- **Real‑time** – Live leaderboard, chat (via Supabase Realtime)
- **Responsive** – Works on mobile, tablet, desktop
- **Modern UI** – Dark theme, glassmorphism, neon accents, smooth animations
- **Security** – JWT, CORS, rate limiting, input validation, audit logs
- **Deployment** – Vercel (frontend + serverless APIs) + Supabase (PostgreSQL + Auth)

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | Next.js (App Router), React, TypeScript, TailwindCSS, Framer Motion, React Query, ShadCN UI |
| **Backend** | Next.js API Routes (Node.js), Prisma ORM, Supabase Auth, JWT |
| **Database** | PostgreSQL (Supabase), Prisma schema |
| **Storage** | ImgBB (screenshots), Supabase Storage (avatars) |
| **Real‑time** | Supabase Realtime |
| **Payments** | Manual verification via UPI/QR, Telegram notifications |
| **Hosting** | Vercel (free tier) |
| **CI/CD** | GitHub Actions (auto‑deploy on push) |

---

## 🗂️ Folder Structure

```
poppy-esports/
├── .env.local.example
├── .gitignore
├── README.md
├── package.json
├── tsconfig.json
├── tailwind.config.js
├── postcss.config.js
├── next.config.js
├── middleware.ts
├── prisma/
│   ├── schema.prisma
│   └── migrations/
│       └── 20240801000000_init/
│           └── migration.sql
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   │   └── page.tsx
│   │   ├── signup/
│   │   │   └── page.tsx
│   │   └── layout.tsx
│   ├── (dashboard)/
│   │   ├── dashboard/
│   │   │   └── page.tsx
│   │   ├── tournaments/
│   │   │   ├── page.tsx
│   │   │   └── [id]/
│   │   │       └── page.tsx
│   │   ├── wallet/
│   │   │   ├── page.tsx
│   │   │   └── withdraw/
│   │   │       └── page.tsx
│   │   ├── leaderboard/
│   │   │   └── page.tsx
│   │   ├── referrals/
│   │   │   └── page.tsx
│   │   ├── profile/
│   │   │   └── page.tsx
│   │   └── layout.tsx
│   ├── admin/
│   │   ├── page.tsx
│   │   ├── tournaments/
│   │   │   ├── page.tsx
│   │   │   └── create/
│   │   │       └── page.tsx
│   │   ├── users/
│   │   │   └── page.tsx
│   │   ├── deposits/
│   │   │   └── page.tsx
│   │   ├── withdrawals/
│   │   │   └── page.tsx
│   │   └── referrals/
│   │       └── page.tsx
│   ├── api/
│   │   ├── auth/
│   │   │   ├── me/
│   │   │   │   └── route.ts
│   │   │   └── logout/
│   │   │       └── route.ts
│   │   ├── tournaments/
│   │   │   ├── route.ts
│   │   │   └── [id]/
│   │   │       ├── route.ts
│   │   │       └── join/
│   │   │           └── route.ts
│   │   ├── deposits/
│   │   │   └── route.ts
│   │   ├── withdrawals/
│   │   │   └── route.ts
│   │   ├── admin/
│   │   │   ├── users/
│   │   │   │   └── route.ts
│   │   │   ├── verify-deposit/
│   │   │   │   └── route.ts
│   │   │   └── verify-withdrawal/
│   │   │       └── route.ts
│   │   ├── fetch-ff-data/
│   │   │   └── route.ts
│   │   ├── delete-account/
│   │   │   └── route.ts
│   │   ├── telegram-webhook/
│   │   │   └── route.ts
│   │   └── upload/
│   │       └── route.ts
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── ui/
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── input.tsx
│   │   ├── label.tsx
│   │   └── select.tsx
│   ├── layout/
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   ├── tournament/
│   │   └── TournamentCard.tsx
│   ├── wallet/
│   │   └── BalanceCard.tsx
│   ├── admin/
│   │   └── StatsCards.tsx
│   ├── query-provider.tsx
│   └── theme-provider.tsx
├── hooks/
│   ├── useAuth.ts
│   └── useTournaments.ts
├── lib/
│   ├── prisma.ts
│   ├── supabase.ts
│   ├── auth.ts
│   └── utils.ts
└── types/
    └── index.ts
```

---

## 🔧 Environment Variables

Create a `.env.local` file in the project root with the following variables:

```env
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
DATABASE_URL=your-postgres-connection-string
IMGBB_API_KEY=your-imgbb-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
```

> **Note:** The `.env.local` file contains sensitive credentials and should **never** be committed to version control. It is already excluded via `.gitignore`.

---

## 🚀 Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/AngelJangra/POPPY-E-SPORTS.git
cd poppy-esports
```

### 2. Install dependencies

```bash
npm install
```

### 3. Set up environment variables

Copy `.env.local.example` to `.env.local` and fill in your values.

### 4. Run Prisma migrations

```bash
npx prisma generate
npx prisma db push
```

### 5. Start the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🔐 Admin Setup

1. Sign up a user via the `/signup` page.
2. In the **Supabase SQL Editor**, run the following (replace `YOUR-USER-ID` with the user's UUID):

```sql
INSERT INTO admin_config (admin_uid, setup_complete) VALUES ('YOUR-USER-ID', true);
UPDATE users SET is_admin = true WHERE id = 'YOUR-USER-ID';
```

3. Log in to `/admin` with that user.

---

## 🧪 Testing

```bash
# Unit tests
npm run test

# E2E tests
npm run test:e2e
```

---

## 📦 Deployment

- **Frontend + APIs:** [Vercel](https://vercel.com) (free) – connect your GitHub repo and it auto‑deploys.
- **Database:** Supabase (free tier) – already configured.
- **File Storage:** ImgBB (free) – for payment screenshots.

---

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

---

## 📄 License

[MIT](LICENSE)

---

## 🙏 Acknowledgements

- [Supabase](https://supabase.com) – backend & auth
- [Vercel](https://vercel.com) – hosting
- [ImgBB](https://imgbb.com) – image hosting
- All contributors

---

Made with ❤️ by **POPPY ESPORTS**