import Link from 'next/link'

export function BalanceCard({ profile }: { profile: any }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">My Wallet</h2>
      <p className="text-3xl font-bold text-green-400">₹{profile?.balance || 0}</p>
      <div className="flex gap-2">
        <Link href="/wallet" className="flex-1 text-center py-2 bg-primary text-black rounded-lg font-semibold">Add Money</Link>
        <Link href="/wallet/withdraw" className="flex-1 text-center py-2 bg-white/10 rounded-lg font-semibold">Withdraw</Link>
      </div>
      <div className="border-t border-gray-700 pt-4">
        <p className="text-sm text-gray-400">Referral Code: <span className="text-primary font-mono">{profile?.referral_code}</span></p>
      </div>
    </div>
  )
}