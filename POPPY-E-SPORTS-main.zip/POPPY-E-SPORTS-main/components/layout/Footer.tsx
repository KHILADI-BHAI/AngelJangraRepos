import Image from 'next/image'

export function Footer() {
  return (
    <footer className="border-t border-white/10 py-4 text-center text-gray-500 text-sm">
      <div className="flex items-center justify-center gap-2 mb-1">
        <Image
          src="/POPPY_ESPORTS.png"
          alt="POPPY ESPORTS logo"
          width={20}
          height={20}
          className="h-5 w-5 rounded object-contain"
        />
        <span className="font-semibold text-gray-400">POPPY ESPORTS</span>
      </div>
      © 2025 POPPY ESPORTS. All rights reserved.
    </footer>
  )
}
