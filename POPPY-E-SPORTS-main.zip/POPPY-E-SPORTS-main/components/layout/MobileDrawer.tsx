'use client'

import { useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Trophy,
  Wallet,
  User,
  Users,
  LayoutDashboard,
  LogOut,
  X,
  Gamepad2,
  Crown,
} from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'

interface MobileDrawerProps {
  open: boolean
  onClose: () => void
}

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/tournaments', label: 'Tournaments', icon: Gamepad2 },
  { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
  { href: '/wallet', label: 'Wallet', icon: Wallet },
  { href: '/profile', label: 'Profile', icon: User },
  { href: '/referrals', label: 'Referrals', icon: Users },
]

export function MobileDrawer({ open, onClose }: MobileDrawerProps) {
  const pathname = usePathname()
  const router = useRouter()
  const { profile } = useAuth()

  // Lock body scroll when drawer is open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  // Close on route change
  useEffect(() => {
    onClose()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />
          {/* Drawer */}
          <motion.div
            key="drawer"
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween', duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-y-0 left-0 w-[280px] max-w-[80vw] bg-[#121212] border-r border-white/10 z-50 flex flex-col lg:hidden"
          >
            {/* Header */}
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image
                  src="/POPPY_ESPORTS.png"
                  alt="POPPY ESPORTS logo"
                  width={28}
                  height={28}
                  className="h-7 w-7 rounded-lg object-contain"
                />
                <span className="text-xl font-bold text-primary">POPPY</span>
                <span className="text-xl font-light">ESPORTS</span>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-white/5 text-gray-400"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* User card */}
            <div className="px-5 py-4 border-b border-white/10 bg-white/[0.03]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Crown className="w-5 h-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold truncate">
                    {profile?.display_name || 'Player'}
                  </p>
                  <p className="text-xs text-gray-400 truncate">
                    {profile?.email || 'Free Fire Player'}
                  </p>
                </div>
              </div>
              {profile && (
                <div className="mt-3 flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
                  <span className="text-xs text-gray-400">Balance</span>
                  <span className="text-sm font-bold text-green-400">
                    ₹{profile.balance?.toFixed(2) ?? '0.00'}
                  </span>
                </div>
              )}
            </div>

            {/* Nav Items */}
            <nav className="flex-1 overflow-y-auto py-3">
              {navItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
                const Icon = item.icon
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-3 px-5 py-3.5 text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-primary bg-primary/10 border-r-2 border-primary'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-5 h-5 shrink-0" />
                    {item.label}
                  </Link>
                )
              })}

              {/* Admin link - only shown to admin users */}
              {profile?.is_admin && (
                <Link
                  href="/admin"
                  className="flex items-center gap-3 px-5 py-3.5 text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
                >
                  <Trophy className="w-5 h-5 shrink-0" />
                  Admin Panel
                </Link>
              )}
            </nav>

            {/* Footer */}
            <div className="px-5 py-4 border-t border-white/10">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-2 py-2.5 text-sm font-medium text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <LogOut className="w-5 h-5 shrink-0" />
                Logout
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}