'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { MobileDrawer } from '@/components/layout/MobileDrawer'
import Image from 'next/image'
import { Menu, LogOut, Home, Wallet, Trophy, User, Gamepad2 } from 'lucide-react'

export function Header() {
  const router = useRouter()
  const { profile } = useAuth()
  const [drawerOpen, setDrawerOpen] = useState(false)

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <>
      <header className="glass border-b border-white/10 sticky top-0 z-30">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            {/* Hamburger (mobile only) */}
            <button
              onClick={() => setDrawerOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-white/5 text-gray-300"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6" />
            </button>
            <Link href="/dashboard" className="flex items-center space-x-2">
              <Image
                src="/POPPY_ESPORTS.png"
                alt="POPPY ESPORTS logo"
                width={32}
                height={32}
                className="h-8 w-8 rounded-lg object-contain"
                priority
              />
              <span className="text-xl sm:text-2xl font-bold text-primary">POPPY</span>
              <span className="text-xl sm:text-2xl font-light hidden sm:inline">ESPORTS</span>
            </Link>
          </div>

          {/* Desktop nav (lg and up) */}
          <nav className="hidden lg:flex items-center space-x-6">
            <Link href="/dashboard" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
              <Home className="w-4 h-4" /> Dashboard
            </Link>
            <Link href="/tournaments" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
              <Gamepad2 className="w-4 h-4" /> Tournaments
            </Link>
            <Link href="/wallet" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
              <Wallet className="w-4 h-4" /> Wallet
            </Link>
            <Link href="/leaderboard" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
              <Trophy className="w-4 h-4" /> Leaderboard
            </Link>
            <Link href="/profile" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
              <User className="w-4 h-4" /> Profile
            </Link>
            {profile?.is_admin && (
              <Link href="/admin" className="flex items-center gap-2 text-gray-400 hover:text-white transition text-sm font-medium">
                <Trophy className="w-4 h-4" /> Admin
              </Link>
            )}
          </nav>

          <div className="flex items-center space-x-3">
            {/* Balance chip (hidden on very small screens) */}
            {profile && (
              <span className="hidden sm:inline-flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1 text-sm font-semibold text-green-400">
                ₹{profile.balance?.toFixed(2) ?? '0.00'}
              </span>
            )}
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-red-400 hover:text-red-300">
              <LogOut className="w-4 h-4 mr-1" /> <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile slide-out drawer */}
      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </>
  )
}