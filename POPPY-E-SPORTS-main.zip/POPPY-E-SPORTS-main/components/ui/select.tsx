'use client'

import { createContext, ReactNode, useContext } from 'react'
import { cn } from '@/lib/utils'

interface SelectContextValue {
  value: string
  onValueChange: (value: string) => void
}

const SelectContext = createContext<SelectContextValue | null>(null)

interface SelectProps {
  value: string
  onValueChange: (value: string) => void
  children: ReactNode
}

export function Select({ value, onValueChange, children }: SelectProps) {
  return (
    <SelectContext.Provider value={{ value, onValueChange }}>
      <div className="w-full">{children}</div>
    </SelectContext.Provider>
  )
}

export function SelectTrigger({ children }: { children: ReactNode }) {
  return <div className="cursor-pointer rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-white">{children}</div>
}

export function SelectValue({ placeholder }: { placeholder?: string }) {
  const context = useContext(SelectContext)
  return <span>{context?.value || placeholder || 'Select an option'}</span>
}

export function SelectContent({ children }: { children: ReactNode }) {
  return <div className="mt-2 rounded-xl border border-white/10 bg-white/5 p-2">{children}</div>
}

interface SelectItemProps {
  value: string
  children: ReactNode
}

export function SelectItem({ value, children }: SelectItemProps) {
  const context = useContext(SelectContext)
  return (
    <div
      onClick={() => context?.onValueChange(value)}
      className={cn('cursor-pointer rounded-md px-3 py-2 text-sm text-white hover:bg-white/10')}
    >
      {children}
    </div>
  )
}
