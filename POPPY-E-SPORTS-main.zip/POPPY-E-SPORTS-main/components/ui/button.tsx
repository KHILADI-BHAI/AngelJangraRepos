'use client'

import { ButtonHTMLAttributes, forwardRef } from 'react'
import { cn } from '@/lib/utils'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'ghost' | 'destructive' | 'outline'
  size?: 'default' | 'sm' | 'lg'
}

const variantClasses: Record<string, string> = {
  default: 'bg-primary text-black hover:bg-primary/90',
  ghost: 'bg-transparent hover:bg-white/5',
  destructive: 'bg-red-500 text-white hover:bg-red-600',
  outline: 'border border-white/10 bg-transparent text-white hover:bg-white/5',
}

const sizeClasses: Record<string, string> = {
  default: 'px-4 py-2 text-sm',
  sm: 'px-3 py-1.5 text-xs',
  lg: 'px-5 py-3 text-base',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'default', size = 'default', ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/80 disabled:opacity-50 disabled:pointer-events-none',
          variantClasses[variant],
          sizeClasses[size],
          className,
        )}
        {...props}
      />
    )
  }
)
Button.displayName = 'Button'
