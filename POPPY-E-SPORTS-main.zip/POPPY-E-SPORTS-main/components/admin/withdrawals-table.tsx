'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import toast from 'react-hot-toast'
import { CheckCircle2, XCircle, Loader2, Copy } from 'lucide-react'

export default function WithdrawalsTable({ initial }: { initial: any[] }) {
  const [withdrawals, setWithdrawals] = useState<any[]>(initial)
  const [busy, setBusy] = useState<string | null>(null)

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    if (!confirm(`Confirm ${action} withdrawal?`)) return
    setBusy(id)
    try {
      const res = await fetch('/api/admin/verify-withdrawal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalId: id, action }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to update withdrawal')
      toast.success(`Withdrawal ${action === 'approve' ? 'approved' : 'rejected'}`)
      setWithdrawals((prev) => prev.filter((w) => w.id !== id))
    } catch (error: any) {
      toast.error(error.message)
    } finally {
      setBusy(null)
    }
  }

  const getUpi = (w: any) =>
    typeof w.methodDetails === 'object' && w.methodDetails ? (w.methodDetails as any).upiId || (w.methodDetails as any).upi_id : w.methodDetails ?? 'N/A'

  const copyUpi = (upi: string) => {
    navigator.clipboard?.writeText(upi)
    toast.success('UPI ID copied')
  }

  const renderActions = (w: any) => (
    <div className="flex gap-2">
      <Button size="sm" disabled={busy === w.id} onClick={() => handleAction(w.id, 'approve')}>
        {busy === w.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1" />}
        Approve
      </Button>
      <Button size="sm" variant="destructive" disabled={busy === w.id} onClick={() => handleAction(w.id, 'reject')}>
        <XCircle className="h-3.5 w-3.5 mr-1" />
        Reject
      </Button>
    </div>
  )

  if (withdrawals.length === 0) {
    return (
      <div className="glass rounded-2xl p-10 text-center text-gray-400 border border-white/10">
        🎉 No pending withdrawals right now.
      </div>
    )
  }

  return (
    <>
      {/* Mobile: stacked cards */}
      <div className="md:hidden space-y-3">
        {withdrawals.map((w) => {
          const upi = getUpi(w)
          return (
            <div key={w.id} className="glass rounded-2xl border border-white/10 p-4 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-medium truncate">{w.users?.display_name || 'Unknown'}</p>
                  <p className="text-xs text-gray-500 truncate">{w.users?.email}</p>
                </div>
                <span className="shrink-0 font-semibold text-red-400">₹{w.amount}</span>
              </div>
              <div className="space-y-1.5 text-xs text-gray-400">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] uppercase tracking-wide text-gray-500">UPI ID</span>
                  <span className="inline-flex items-center gap-1 font-mono text-white">
                    {upi}
                    {upi !== 'N/A' && (
                      <button onClick={() => copyUpi(upi as string)} className="text-gray-500 hover:text-white">
                        <Copy className="h-3 w-3" />
                      </button>
                    )}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] uppercase tracking-wide text-gray-500">Date</span>
                  <span>{new Date(w.requestTimestamp).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex gap-2 pt-1">{renderActions(w)}</div>
            </div>
          )
        })}
      </div>

      {/* Desktop: table */}
      <div className="hidden md:block glass rounded-2xl overflow-x-auto border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/5">
            <tr className="text-left text-gray-400">
              <th className="p-4 font-medium">User</th>
              <th className="p-4 font-medium">Amount</th>
              <th className="p-4 font-medium">UPI ID</th>
              <th className="p-4 font-medium">Date</th>
              <th className="p-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {withdrawals.map((w) => (
              <tr key={w.id} className="border-t border-white/5 hover:bg-white/[0.03] transition-colors">
                <td className="p-4">
                  <p className="font-medium">{w.users?.display_name || 'Unknown'}</p>
                  <p className="text-xs text-gray-500">{w.users?.email}</p>
                </td>
                <td className="p-4 font-semibold text-red-400">₹{w.amount}</td>
                <td className="p-4">
                  <span className="inline-flex items-center gap-1 font-mono text-xs">
                    {getUpi(w)}
                    {getUpi(w) !== 'N/A' && (
                      <button onClick={() => copyUpi(getUpi(w) as string)} className="text-gray-500 hover:text-white">
                        <Copy className="h-3 w-3" />
                      </button>
                    )}
                  </span>
                </td>
                <td className="p-4 text-gray-400">{new Date(w.requestTimestamp).toLocaleDateString()}</td>
                <td className="p-4">{renderActions(w)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}