'use client'
import { Users, Trophy, Banknote, ArrowLeftRight, CheckCircle2, XCircle, Gamepad2, Flag } from 'lucide-react'
import { cn } from '@/lib/utils'

const items = (stats: any) => [
  { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'from-blue-500/20 to-blue-600/10 text-blue-400', bar: 'bg-blue-500' },
  { label: 'Active Tournaments', value: stats.activeTournaments, icon: Trophy, color: 'from-emerald-500/20 to-emerald-600/10 text-emerald-400', bar: 'bg-emerald-500' },
  { label: 'Pending Deposits', value: stats.pendingDeposits, icon: Banknote, color: 'from-amber-500/20 to-amber-600/10 text-amber-400', bar: 'bg-amber-500' },
  { label: 'Pending Withdrawals', value: stats.pendingWithdrawals, icon: ArrowLeftRight, color: 'from-yellow-500/20 to-yellow-600/10 text-yellow-400', bar: 'bg-yellow-500' },
  { label: 'Completed Withdrawals', value: stats.completedWithdrawals, icon: CheckCircle2, color: 'from-green-500/20 to-green-600/10 text-green-400', bar: 'bg-green-500' },
  { label: 'Rejected Withdrawals', value: stats.rejectedWithdrawals, icon: XCircle, color: 'from-red-500/20 to-red-600/10 text-red-400', bar: 'bg-red-500' },
  { label: 'Total Games', value: stats.totalGames, icon: Gamepad2, color: 'from-purple-500/20 to-purple-600/10 text-purple-400', bar: 'bg-purple-500' },
  { label: 'Finished Tournaments', value: stats.finishedTournaments, icon: Flag, color: 'from-slate-500/20 to-slate-600/10 text-slate-400', bar: 'bg-slate-500' },
]

export default function StatsCards({ stats }: { stats: any }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
      {items(stats).map((item, i) => (
        <div
          key={i}
          className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-5 hover:border-white/20 transition-colors"
        >
          <div className={cn('absolute inset-0 bg-gradient-to-br opacity-40', item.color)} />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">{item.label}</p>
              <p className="text-2xl font-bold mt-2">{item.value}</p>
            </div>
            <div className={cn('h-10 w-10 rounded-xl bg-gradient-to-br flex items-center justify-center', item.color)}>
              <item.icon className="h-5 w-5" />
            </div>
          </div>
          <div className={cn('absolute bottom-0 left-0 right-0 h-0.5', item.bar)} />
        </div>
      ))}
    </div>
  )
}