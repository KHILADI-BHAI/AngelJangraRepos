'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import toast from 'react-hot-toast'
import { ExternalLink, CheckCircle2, XCircle, Loader2 } from 'lucide-react'

export default function DepositsTable({ initial }: { initial: any[] }) {
  const [deposits, setDeposits] = useState<any[]>(initial)
  const [busy, setBusy] = useState<string | null>(null)

  const handleAction = async (id: string, action: 'complete' | 'reject') => {
    if (!confirm(`Confirm ${action} deposit?`)) return
    setBusy(id)
    try {
      const res = await fetch('/api/admin/verify-deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId: id, action }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to update deposit')
      toast.success(`Deposit ${action === 'complete' ? 'approved' : 'rejected'}`)
      setDeposits((prev) => prev.filter((d) => d.id !== id))
    } catch (error: any) {
      toast.error(error.message)
    } finally {
      setBusy(null)
    }
  }

  const renderActions = (d: any) => (
    <div className="flex gap-2">
      <Button size="sm" disabled={busy === d.id} onClick={() => handleAction(d.id, 'complete')}>
        {busy === d.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1" />}
        Approve
      </Button>
      <Button size="sm" variant="destructive" disabled={busy === d.id} onClick={() => handleAction(d.id, 'reject')}>
        <XCircle className="h-3.5 w-3.5 mr-1" />
        Reject
      </Button>
    </div>
  )

  if (deposits.length === 0) {
    return (
      <div className="glass rounded-2xl p-10 text-center text-gray-400 border border-white/10">
        🎉 No pending deposits right now.
      </div>
    )
  }

  return (
    <>
      {/* Mobile: stacked cards */}
      <div className="md:hidden space-y-3">
        {deposits.map((d) => (
          <div key={d.id} className="glass rounded-2xl border border-white/10 p-4 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-medium truncate">{d.users?.display_name || 'Unknown'}</p>
                <p className="text-xs text-gray-500 truncate">{d.users?.email}</p>
              </div>
              <span className="shrink-0 font-semibold text-green-400">₹{d.amount}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs text-gray-400">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-500">Method</p>
                <p className="text-white">{d.payment_method}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-500">UTR</p>
                <p className="font-mono text-white">{d.utr}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-500">Date</p>
                <p>{new Date(d.timestamp).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-gray-500">Screenshot</p>
                <a href={d.screenshot_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-0.5 text-blue-400">
                  View <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
            <div className="flex gap-2 pt-1">{renderActions(d)}</div>
          </div>
        ))}
      </div>

      {/* Desktop: table */}
      <div className="hidden md:block glass rounded-2xl overflow-x-auto border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-white/5">
            <tr className="text-left text-gray-400">
              <th className="p-4 font-medium">User</th>
              <th className="p-4 font-medium">Amount</th>
              <th className="p-4 font-medium">Method</th>
              <th className="p-4 font-medium">UTR</th>
              <th className="p-4 font-medium">Screenshot</th>
              <th className="p-4 font-medium">Date</th>
              <th className="p-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {deposits.map((d) => (
              <tr key={d.id} className="border-t border-white/5 hover:bg-white/[0.03] transition-colors">
                <td className="p-4">
                  <p className="font-medium">{d.users?.display_name || 'Unknown'}</p>
                  <p className="text-xs text-gray-500">{d.users?.email}</p>
                </td>
                <td className="p-4 font-semibold text-green-400">₹{d.amount}</td>
                <td className="p-4">{d.payment_method}</td>
                <td className="p-4 font-mono text-xs">{d.utr}</td>
                <td className="p-4">
                  <a href={d.screenshot_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300">
                    View <ExternalLink className="h-3 w-3" />
                  </a>
                </td>
                <td className="p-4 text-gray-400">{new Date(d.timestamp).toLocaleDateString()}</td>
                <td className="p-4">{renderActions(d)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}