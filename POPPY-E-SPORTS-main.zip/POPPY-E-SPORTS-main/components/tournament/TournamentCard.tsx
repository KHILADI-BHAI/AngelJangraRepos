import Link from 'next/link'
import Image from 'next/image'

export function TournamentCard({ tournament }: { tournament: any }) {
  const start = new Date(tournament.start_time).toLocaleString()
  return (
    <Link href={`/tournaments/${tournament.id}`}>
      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition">
        <div className="flex items-center gap-4">
          {tournament.games?.image_url && (
            <Image src={tournament.games.image_url} alt={tournament.games.name} width={40} height={40} className="rounded-full" />
          )}
          <div>
            <h3 className="font-semibold">{tournament.name}</h3>
            <p className="text-sm text-gray-400">{start}</p>
          </div>
        </div>
        <span className="text-sm bg-primary/20 text-primary px-3 py-1 rounded-full">
          ₹{tournament.entry_fee}
        </span>
      </div>
    </Link>
  )
}