'use client'

import { useCallback, useSyncExternalStore } from 'react'
import { supabase } from '@/lib/supabase'
import { User } from '@supabase/supabase-js'

/**
 * SINGLETON auth + profile store.
 *
 * Root cause of the "cannot add postgres_changes callbacks after subscribe()"
 * error: useAuth() was a hook used by MANY components (Header, Drawer, Wallet,
 * tournament pages). Each instance opened its OWN auth listener and its OWN
 * realtime channel to the SAME user row. The shared Supabase realtime client
 * then saw the same channel topic subscribed twice → crash.
 *
 * Fix: exactly ONE module-level listener + ONE realtime channel. Every
 * component reads the same state via useSyncExternalStore — no duplicates,
 * no collisions, fully reactive.
 */

type AuthState = {
  user: User | null
  profile: any | null
  ready: boolean
}

let state: AuthState = { user: null, profile: null, ready: false }
const listeners = new Set<() => void>()
let realtime: any = null
let realtimeTopic: string | null = null

function setState(next: Partial<AuthState>) {
  const changed =
    next.user !== state.user ||
    next.profile !== state.profile ||
    (next.ready !== undefined && next.ready !== state.ready)
  if (!changed) return
  state = { ...state, ...next }
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

async function fetchProfile(userId: string): Promise<any | null> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single()
    if (error) throw error
    return data
  } catch (error) {
    console.error('Failed to fetch profile:', error)
    return null
  }
}

function setupRealtime(userId: string) {
  if (realtime) {
    supabase.removeChannel(realtime).catch(() => {})
    realtime = null
    realtimeTopic = null
  }

  // Globally unique topic for THIS user — never collides with other tabs/instances.
  realtimeTopic = `profile-live-${userId}-${Date.now()}`

  realtime = supabase
    .channel(realtimeTopic)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'users',
        filter: 'id=eq.' + userId,
      },
      (payload) => {
        // Merge so we never lose other fields while streaming updates
        setState({ profile: { ...(state.profile || {}), ...(payload.new as any) } })
      }
    )
    .subscribe()
}

// Boot once at module load: single auth listener drives everything.
let initialized = false
function ensureInitialized() {
  if (initialized) return
  initialized = true

  // SINGLE source of truth. Emits INITIAL_SESSION on mount and fires on
  // sign-in/sign-out — no duplicate setup paths possible.
  supabase.auth.onAuthStateChange(async (_event, session) => {
    if (!session) {
      if (realtime) {
        supabase.removeChannel(realtime).catch(() => {})
        realtime = null
        realtimeTopic = null
      }
      setState({ user: null, profile: null, ready: true })
      return
    }

    setState({ user: session.user, ready: false })
    const profile = await fetchProfile(session.user.id)
    if (profile) setupRealtime(session.user.id)
    setState({ profile, ready: true })
  })
}

ensureInitialized()

export function useAuth() {
  // Reactive binding to the singleton state
  const snapshot = useSyncExternalStore(
    subscribe,
    () => state,
    () => state
  )

  // Public API: fetch the latest profile row immediately
  const refetch = useCallback(async () => {
    if (!state.user) return null
    const profile = await fetchProfile(state.user.id)
    setState({ profile })
    return profile
  }, [])

  return {
    user: snapshot.user,
    profile: snapshot.profile,
    loading: !snapshot.ready,
    refetch,
  }
}