import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'

export function useTournaments(status: string = 'upcoming') {
  return useQuery({
    queryKey: ['tournaments', status],
    queryFn: async () => {
      const { data } = await supabase
        .from('tournaments')
        .select('*, games(name, image_url)')
        .eq('status', status)
        .order('start_time', { ascending: true })
      return data
    },
  })
}