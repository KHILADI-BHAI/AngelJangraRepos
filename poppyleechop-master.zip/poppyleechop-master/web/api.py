"""Token protected control API for the WZML-X web app.

Served by the same gunicorn/Flask app as the torrent file selector
(``web.wserver:app``), so it costs no extra process and gives every PaaS router
something to route to (SnapDeploy/Deplexo need an HTTP port, otherwise the
container is treated as dead).

It is deliberately stateless and imports nothing from ``bot``: that would boot
the whole Telegram bot inside a gunicorn worker. Like ``web/wserver.py`` it
talks to the aria2 RPC and the qBittorrent WebUI directly, so the same code
works on one box and in a split deployment (see SPLIT_DEPLOY.md).

Auth: every ``/api/...`` route except ``/api/health`` needs the ``API_TOKEN``
environment variable, sent as the ``X-API-Token`` header.
"""

from hmac import compare_digest
from logging import getLogger
from os import environ, path as ospath
from re import findall
from threading import Thread
from time import sleep, time
import os

from flask import Blueprint, jsonify, request

try:
    from psutil import disk_usage, virtual_memory
except ImportError:  # psutil ships in requirements.txt, stay usable without it
    disk_usage = virtual_memory = None

LOGGER = getLogger(__name__)

API_TOKEN = environ.get('API_TOKEN', '')
STARTED_AT = time()
MAX_TASKS = int(environ.get('API_MAX_TASKS', '100'))


def _tool_version():
    """Read the release tag from bot/version.py without importing the bot package."""
    try:
        root = ospath.dirname(ospath.dirname(ospath.abspath(__file__)))
        with open(ospath.join(root, 'bot', 'version.py'), encoding='utf-8') as f:
            body = f.read()
        parts = {key: findall(rf"{key}\s*=\s*'([^']+)'", body) for key in ('MAJOR', 'MINOR', 'PATCH', 'STATE')}
        if all(parts.values()):
            return f"v{parts['MAJOR'][0]}.{parts['MINOR'][0]}.{parts['PATCH'][0]}-{parts['STATE'][0]}"
    except Exception as e:
        LOGGER.warning(f"Could not read release version: {e}")
    return environ.get('RELEASE_VERSION', 'unknown')


RELEASE = _tool_version()


def _pick(obj, *names, default=None):
    """Tolerant attribute/item getter - aria2p and qbittorrentapi change shapes between releases."""
    for name in names:
        try:
            if isinstance(obj, dict) and name in obj:
                return obj[name]
            if hasattr(obj, name):
                return getattr(obj, name)
        except Exception:
            continue
    return default


def _float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _text(value, default=''):
    """aria2p hands out pathlib.Path for dir/gid-adjacent fields - Flask cannot serialise those."""
    if value is None:
        return default
    return value if isinstance(value, str) else str(value)


def _state(value):
    """Normalise aria2 status enums / qBittorrent state strings into one word."""
    raw = str(getattr(value, 'name', value) or '').lower()
    if raw in ('error', 'missingfiles', 'unknown') or raw.startswith('removed'):
        return 'error'
    if raw.startswith('complete') or raw in ('uploading', 'stalledup', 'forcedup', 'queuedup', 'checkingup'):
        return 'complete'
    if raw.startswith('pause') or raw.startswith('stall') or raw in ('stoppeddl', 'stoppedup'):
        return 'paused'
    if raw.startswith('active') or raw in ('downloading', 'forceddl', 'metadl', 'checkingdl', 'allocating'):
        return 'active'
    if raw.startswith('wait') or raw in ('queueddl', 'queuedforchecking'):
        return 'waiting'
    return raw or 'unknown'


def create_api_blueprint(aria2, get_qb_client, download_dir):
    """Build the blueprint. ``aria2`` and ``get_qb_client`` are owned by web.wserver."""
    api = Blueprint('wzmlx_api', __name__)

    def _authorized():
        if not API_TOKEN:
            return False
        sent = request.headers.get('X-API-Token') or request.args.get('token', '')
        return compare_digest(sent, API_TOKEN)

    def _denied():
        return jsonify({'ok': False, 'error': 'unauthorized', 'hint': 'send the X-API-Token header'}), 401

    def _aria2_tasks():
        tasks, error = [], None
        try:
            for download in aria2.get_downloads():
                total = _float(_pick(download, 'total_length', 'totalLength'))
                done = _float(_pick(download, 'completed_length', 'completedLength'))
                tasks.append({
                    'id': _text(_pick(download, 'gid')),
                    'client': 'aria2',
                    'name': _text(_pick(download, 'name')) or _text(_pick(download, 'gid')),
                    'state': _state(_pick(download, 'status')),
                    'progress': round(_float(_pick(download, 'progress'), (done / total * 100) if total else 0.0), 2),
                    'size': int(total),
                    'completed': int(done),
                    'down_speed': int(_float(_pick(download, 'download_speed', 'downloadSpeed'))),
                    'up_speed': int(_float(_pick(download, 'upload_speed', 'uploadSpeed'))),
                    'path': _text(_pick(download, 'dir')),
                    'torrent': bool(_pick(download, 'is_torrent', default=False)),
                })
        except Exception as e:
            error = str(e)
        return tasks, error

    def _qbit_tasks(client):
        tasks, error = [], None
        try:
            for torrent in client.torrents_info():
                progress = _float(_pick(torrent, 'progress')) * 100
                size = _int(_pick(torrent, 'size', 'total_size'))
                tasks.append({
                    'id': _text(_pick(torrent, 'hash')),
                    'client': 'qbittorrent',
                    'name': _text(_pick(torrent, 'name')) or _text(_pick(torrent, 'hash')),
                    'state': _state(_pick(torrent, 'state')),
                    'progress': round(progress, 2),
                    'size': size,
                    'completed': int(size * progress / 100) if size else 0,
                    'down_speed': _int(_pick(torrent, 'dlspeed', 'download_speed')),
                    'up_speed': _int(_pick(torrent, 'upspeed', 'upload_speed')),
                    'path': _text(_pick(torrent, 'save_path', 'savePath')),
                    'torrent': True,
                })
        except Exception as e:
            error = str(e)
        return tasks, error

    def _daemon_health():
        health = {'aria2': {'up': False}, 'qbittorrent': {'up': False}}
        try:
            stat = aria2.client.get_global_stat()
            version = aria2.client.get_version()
            health['aria2'] = {
                'up': True,
                'version': str(_pick(version, 'version', default='') or ''),
                'down_speed': _int(_pick(stat, 'downloadSpeed', 'download_speed')),
                'up_speed': _int(_pick(stat, 'uploadSpeed', 'upload_speed')),
                'active': _int(_pick(stat, 'numActive', 'num_active')),
                'waiting': _int(_pick(stat, 'numWaiting', 'num_waiting')),
                'stopped': _int(_pick(stat, 'numStopped', 'num_stopped')),
            }
        except Exception as e:
            health['aria2']['error'] = str(e)
        try:
            client = get_qb_client()
            info = client.transfer_info()
            health['qbittorrent'] = {
                'up': True,
                'version': str(client.app.version),
                'down_speed': _int(_pick(info, 'dl_info_speed', 'dlInfoSpeed')),
                'up_speed': _int(_pick(info, 'up_info_speed', 'upInfoSpeed')),
                'status': _pick(info, 'connection_status', 'connectionStatus', default=''),
                'torrents': len(client.torrents_info() or []),
            }
            client.auth_log_out()
        except Exception as e:
            health['qbittorrent']['error'] = str(e)
        return health

    def _host_health():
        host = {'uptime': int(time() - STARTED_AT), 'download_dir': download_dir}
        if disk_usage is not None:
            try:
                usage = disk_usage(download_dir if ospath.isdir(download_dir) else '.')
                host['disk'] = {'total': usage.total, 'used': usage.used, 'free': usage.free, 'percent': usage.percent}
            except Exception as e:
                host['disk'] = {'error': str(e)}
        if virtual_memory is not None:
            try:
                mem = virtual_memory()
                host['memory'] = {'total': mem.total, 'available': mem.available, 'percent': mem.percent}
            except Exception as e:
                host['memory'] = {'error': str(e)}
        return host

    # ---- routes -----------------------------------------------------------

    @api.route('/healthz', methods=['GET'])
    def healthz():
        """Bare 200 for platform health checks and uptime robots."""
        return 'ok', 200

    @api.route('/api/health', methods=['GET'])
    def health():
        """Public on purpose: contains no secrets, used by the dashboard and pingers.

        ``config_version`` is read from the marker that deploy/paas/config_pull.py wrote,
        so the dashboard can show whether this container is running the newest settings.
        """
        version = 0
        for candidate in ('.config_version',):
            try:
                with open(candidate, encoding='utf-8') as handle:
                    version = int(handle.read().strip() or 0)
            except (OSError, ValueError):
                version = 0
        return jsonify({
            'ok': True,
            'service': 'wzmlx-web',
            'release': RELEASE,
            'time': int(time()),
            'config_version': version,
            'external_daemons': environ.get('EXTERNAL_DAEMONS', 'false').lower() == 'true',
            'daemons': _daemon_health(),
            'host': _host_health(),
        })

    @api.route('/api/stats', methods=['GET'])
    def stats():
        if not _authorized():
            return _denied()
        daemons = _daemon_health()
        return jsonify({
            'ok': True,
            'release': RELEASE,
            'down_speed': daemons['aria2'].get('down_speed', 0) + daemons['qbittorrent'].get('down_speed', 0),
            'up_speed': daemons['aria2'].get('up_speed', 0) + daemons['qbittorrent'].get('up_speed', 0),
            'active': daemons['aria2'].get('active', 0),
            'waiting': daemons['aria2'].get('waiting', 0),
            'daemons': daemons,
            'host': _host_health(),
        })

    @api.route('/api/torrents', methods=['GET'])
    def torrents():
        if not _authorized():
            return _denied()
        aria_tasks, aria_error = _aria2_tasks()
        try:
            client = get_qb_client()
            qbit_tasks, qbit_error = _qbit_tasks(client)
            client.auth_log_out()
        except Exception as e:
            qbit_tasks, qbit_error = [], str(e)
        tasks = (aria_tasks + qbit_tasks)[:MAX_TASKS]
        return jsonify({
            'ok': True,
            'count': len(tasks),
            'tasks': tasks,
            'errors': {'aria2': aria_error, 'qbittorrent': qbit_error},
        })

    def _act(id_, action):
        # same heuristic as web/wserver.py: a >20 char id is a SHA1 hash (qBittorrent), else an aria2 gid
        if len(id_) > 20:
            client = get_qb_client()
            try:
                if action == 'pause':
                    client.torrents_pause(torrent_hashes=id_)
                elif action == 'resume':
                    client.torrents_resume(torrent_hashes=id_)
                elif action == 'cancel':
                    client.torrents_delete(delete_files=True, torrent_hashes=id_)
                    return {'ok': True, 'client': 'qbittorrent', 'action': action, 'deleted_files': True}
                else:
                    return {'ok': False, 'error': f'unknown action {action}'}
                return {'ok': True, 'client': 'qbittorrent', 'action': action}
            finally:
                client.auth_log_out()
        if action == 'pause':
            aria2.client.pause(id_)
        elif action == 'resume':
            aria2.client.unpause(id_)
        elif action == 'cancel':
            aria2.client.force_remove(id_)
        else:
            return {'ok': False, 'error': f'unknown action {action}'}
        return {'ok': True, 'client': 'aria2', 'action': action}

    @api.route('/api/torrents/<string:id_>/<string:action>', methods=['POST'])
    def torrent_action(id_, action):
        if not _authorized():
            return _denied()
        if action not in ('pause', 'resume', 'cancel'):
            return jsonify({'ok': False, 'error': 'action must be pause, resume or cancel'}), 400
        try:
            return jsonify(_act(id_, action))
        except Exception as e:
            LOGGER.error(f"{action} failed for {id_}: {e}")
            return jsonify({'ok': False, 'error': str(e)}), 502

    @api.route('/api/restart', methods=['POST'])
    def restart():
        """Ask the platform to restart this container, so new config takes effect.

        The bot loads its configuration once at import, so a settings change cannot apply
        live. The dashboard calls this after a save; the platform restarts the container
        when the process exits. Disabled unless RESTART_API is enabled, because on a
        single-host box this would take the bot down without anything to bring it back.
        """
        if not _authorized():
            return _denied()
        if environ.get('RESTART_API', 'false').lower() != 'true':
            return jsonify({
                'ok': False,
                'error': 'restart is disabled on this runtime',
                'hint': 'set RESTART_API=true to let the dashboard restart this container',
            }), 403
        if environ.get('IS_WINDOWS', '').lower() == 'true':
            return jsonify({'ok': False, 'error': 'restart is not supported on Windows'}), 400

        def _later():
            sleep(float(environ.get('RESTART_DELAY', '2')))
            os._exit(0)  # the platform restarts us; a clean Telegram shutdown is not possible here

        Thread(target=_later, daemon=True).start()
        return jsonify({
            'ok': True,
            'restarting': True,
            'note': 'config is re-pulled on boot; downloads in progress are lost on a PaaS container',
        })

    @api.route('/api/torrents/clear', methods=['POST'])
    def clear_finished():
        """Drop finished/stopped entries from the daemons' lists. Never touches active downloads."""
        if not _authorized():
            return _denied()
        removed, errors = {'aria2': 0, 'qbittorrent': 0}, {}
        try:
            aria2.client.purge_download_result()
            removed['aria2'] = 1
        except Exception as e:
            errors['aria2'] = str(e)
        try:
            client = get_qb_client()
            done = [t.hash for t in client.torrents_info() if _float(_pick(t, 'progress')) >= 1.0]
            if done:
                client.torrents_delete(delete_files=False, torrent_hashes=done)
                removed['qbittorrent'] = len(done)
            client.auth_log_out()
        except Exception as e:
            errors['qbittorrent'] = str(e)
        return jsonify({'ok': True, 'removed': removed, 'errors': errors})

    return api


