# Splitting WZML-X into parts and running them on more than one machine

Short answer: **yes** - the stack can be split into 4 parts, and the support for it is now in
the repo (`docker-compose.split.yml`, `deploy/*`, the `ARIA2_HOST` / `QBIT_HOST` /
`EXTERNAL_DAEMONS` env vars). But there are exactly **two hard limits** you cannot design
around without rewriting the bot:

| Limit | Why | Consequence |
| --- | --- | --- |
| **One shared filesystem** | the daemons receive **absolute paths** from the bot (`a2c_opt['dir'] = path`, qBittorrent `save_path`) and the bot reads the finished files back to unpack/upload them | every part must see the download directory at the **same absolute path** - across hosts that means a network mount, not just an open port |
| **One Telegram consumer per token** | `bot/__main__.py` runs `bot.run()` (long polling) | two containers with the same `BOT_TOKEN` fight over `getUpdates` (HTTP 409). Scaling to N instances needs N tokens (`/clone`) or `BASE_URL` webhooks |

Everything else is already separable, because the bot talks to its daemons over TCP/IP and to
its database over the network.

## 1. The parts

| Part | What it does | Talks to | Footprint (measured on this repo) |
| --- | --- | --- | --- |
| `bot` | Telegram interface, task/queue handling, ffmpeg/7z processing, uploads (Telegram/Drive/rclone), listeners | Telegram API, MongoDB, aria2 RPC, qBittorrent WebUI | **~148 MB RAM** idle, ~315 MB of Python deps, needs real CPU for ffmpeg/7z |
| `aria2` | direct/HTTP/YouTube downloads (JSON-RPC 6800) | writes into the shared download dir | ~13 MB RAM idle, disk = file size |
| `qbittorrent` | torrents (WebUI/API 8090) | writes into the shared download dir | ~64 MB RAM idle + disk cache |
| `mongodb` | users, settings, RSS, task state | only the `bot` part | ~250-500 MB (MongoDB Atlas free tier is fine) |

A 5th optional part: the **website** (`web/wserver.py`, torrent file selection) exists only when
`BASE_URL` is set; today gunicorn serves it inside the bot part, it can be moved to its own host
with `gunicorn web.wserver:app --bind 0.0.0.0:8080`.

## 2. What had to change in the code

| Change | File | Effect |
| --- | --- | --- |
| Daemon endpoints are env-driven | `bot/__init__.py` | `ARIA2_HOST`, `ARIA2_PORT`, `ARIA2_SECRET`, `QBIT_HOST`, `QBIT_PORT`, `QBIT_USERNAME`, `QBIT_PASSWORD`. Defaults are the old `localhost:6800` / `localhost:8090`, so single-host setups behave exactly as before |
| Local daemon startup can be skipped | `bot/__init__.py` (`EXTERNAL_DAEMONS=true`) | the image used to start `qbittorrent-nox` + `aria.sh` **inside** the bot container; with the split that would create a second, unused daemon |
| Web selection server follows the same env | `web/wserver.py` | was hard-coded to `localhost` in 4 places |
| Foreground aria2 with remote RPC | `deploy/aria.remote.sh` | same flags as `aria.sh` plus `--rpc-listen-all`, `--rpc-secret`, `--daemon=false` (containers need a foreground process) |
| WebUI credentials for remote access | `deploy/set_qbittorrent_auth.py` | qBittorrent skips auth for localhost only, a remote WebUI needs username + PBKDF2 hash |
| Turn a Windows PC into the download box | `start_windows.ps1 -DaemonsOnly` | daemons only, no bot |

## 3. Baseline: 3 containers on one host (start here)

```bash
cp .env.split.example .env
docker compose -f docker-compose.split.yml up -d --build
docker compose -f docker-compose.split.yml logs -f bot
```

You now have separate lifecycle, restart policy, memory limit and logs per part, so a crashing
qBittorrent no longer takes the bot down with it, and you can
`docker compose -f docker-compose.split.yml restart qbittorrent` without interrupting a running
mirror. This alone is worth it even if everything stays on one VPS.


## 4. Two hosts: "bot box" + "download box"

Typical reason: the box for the bot is small/cheap, the box that stores the files has a bigger
disk, or you want torrent traffic on a different IP/VPN.

**Step 1 - private network.** Join both machines to one private network (Tailscale/WireGuard is
the easiest) so nothing has to be exposed to the internet. Never publish 6800/8090 publicly:
aria2's RPC can write files anywhere and the qBittorrent WebUI is a full torrent client.
Check the addresses with `tailscale ip -4` - below, bot box = `100.64.0.5`, download box = `100.64.0.7`.

**Step 2 - shared download directory.** The bot will hand over paths like
`/usr/src/app/downloads/MyFile.mkv` (its `DOWNLOAD_DIR`), so the download box must have the same
path pointing at the same bytes:

```bash
# download box: export /mnt/data/wzml
apt install -y nfs-kernel-server
echo '/mnt/data/wzml 100.64.0.5(rw,sync,no_subtree_check,no_root_squash)' >> /etc/exports
exportfs -ra

# bot box: mount it at the exact path the bot uses
apt install -y nfs-common
mkdir -p /mnt/wzml/downloads
echo '100.64.0.7:/mnt/data/wzml /mnt/wzml/downloads nfs defaults,_netdev 0 0' >> /etc/fstab
mount -a
```

SMB (`cifs`), sshfs (`sshfs user@host:/mnt/data/wzml /mnt/wzml/downloads`) or an rclone mount
work too - NFS is simply the fastest. `no_root_squash` is needed because the containers run as
root (keep the export restricted to the single bot IP as above, or run the parts with a matching
`PUID`/`PGID`). Then set in `.env` **on both machines**:

```dotenv
DOWNLOADS_PATH=/mnt/wzml/downloads
```

`DOWNLOADS_PATH` is what makes `docker-compose.split.yml` bind-mount a host folder instead of
using a local docker volume - exactly what a cross-host setup needs. Both containers still see it
as `/usr/src/app/downloads`, the identical absolute path the bot and daemons expect.

**Step 3 - download box** (`100.64.0.7`):

```bash
# .env here: ARIA2_BIND=100.64.0.7  QBIT_BIND=100.64.0.7
#            ARIA2_SECRET=$(openssl rand -hex 16)  QBIT_USERNAME=admin QBIT_PASSWORD=<strong>
docker compose -f docker-compose.split.yml up -d --build aria2 qbittorrent
```

**Step 4 - bot box** (`100.64.0.5`):

```bash
# .env here: ARIA2_HOST=100.64.0.7  ARIA2_SECRET=<same>
#            QBIT_HOST=100.64.0.7   QBIT_USERNAME/QBIT_PASSWORD=<same>
docker compose -f docker-compose.split.yml up -d --build bot
```

The startup log stamps the wiring:
`Make sure aria2c RPC is reachable on http://100.64.0.7:6800 and qBittorrent WebUI on 100.64.0.7:8090`.

**Step 5 - verify before touching Telegram**

```bash
curl -s http://100.64.0.7:6800/jsonrpc                                       # any answer = reachable
curl -s -o /dev/null -w '%{http_code}\n' http://100.64.0.7:8090/api/v2/app/version  # 401 = up, needs creds
docker compose -f docker-compose.split.yml exec bot python3 -c \
  "from qbittorrentapi import Client; print(Client(host='100.64.0.7', port=8090, username='admin', password='<pw>').app_version())"
```

If the last command prints a version, the bot box can reach the torrent daemon and the split works.
Send `/ping/` in Telegram, then a small `/mirror/` while watching
`docker compose -f docker-compose.split.yml logs -f bot`.

## 5. Scaling out: more than one bot

One Telegram token = one polling consumer, so "more deployers" for the bot part itself means
**more tokens**, which the repo already supports (`/clone` creates a clone with its own
`bot_id` in MongoDB). Give every clone its own directory, `config.env`, `DOWNLOADS_PATH` and
daemon pair, then start it as its own compose project:

```bash
cp -r /opt/wzmlx /opt/wzmlx2 && cd /opt/wzmlx2   # own config.env (token 2), own .env
# .env: DOWNLOADS_PATH=/mnt/wzml/downloads2  ARIA2_HOST=wzmlx2-aria2  QBIT_HOST=wzmlx2-qbittorrent
docker compose -f docker-compose.split.yml -p wzmlx2 up -d --build
```

Two things to watch when both live on one host: the `container_name:` values in the compose file
are fixed, so change them (or the project name **and** the container names) per clone, and never
start the same token twice - Telegram answers with `409 Conflict` and the tasks get split
randomly between the two instances.

## 6. Environment reference (new in this repo)

| Variable | Default | Meaning |
| --- | --- | --- |
| `EXTERNAL_DAEMONS` | empty | `true` = do not start `qbittorrent-nox`/`aria.sh` in the bot container |
| `ARIA2_HOST` | `localhost` | host or full URL of the aria2 RPC (`100.64.0.7`, `http://aria2`) |
| `ARIA2_PORT` / `ARIA2_SECRET` | `6800` / empty | RPC port and the shared secret |
| `QBIT_HOST` / `QBIT_PORT` | `localhost` / `8090` | qBittorrent WebUI address |
| `QBIT_USERNAME` / `QBIT_PASSWORD` | empty → `admin`/`adminadmin` | WebUI credentials used by the bot |
| `DOWNLOADS_PATH` | `downloads` (docker volume) | host folder or network mount shared by all parts |
| `ARIA2_BIND` / `QBIT_BIND` | `127.0.0.1` | which interface the ports are published on |
| `ARIA2_LISTEN_ALL` | `true` | aria2 `--rpc-listen-all` |
| `ARIA2_FILE_ALLOCATION` | `prealloc` | set `none` on NFS/SMB |
| `QBIT_WEBUI_ADDRESS` | `*` | qBittorrent `WebUI\Address` inside its container |
| `WEB_BIND` / `BASE_URL_PORT` | `127.0.0.1` / `8080` | publishing of the optional selection website |
| `*_MEM` / `*_CPUS` | see file | per-part limits (`bot` 1g, `aria2` 512m, `qbittorrent` 512m, `mongodb` 512m) |

## 7. Security checklist

- Never publish `6800`/`8090` to the internet. Bind them to `127.0.0.1` (default) or to a
  private VPN address, and firewall the ports to the bot box only.
- Always set `ARIA2_SECRET` when the RPC is reachable by others: an unauthenticated aria2 RPC can
  be told to download to any path on the daemon's filesystem.
- Change `QBIT_USERNAME`/`QBIT_PASSWORD` (`deploy/set_qbittorrent_auth.py` warns while the default
  is still in use); `WebUI\LocalHostAuth=false` only bypasses auth for localhost.
- MongoDB: keep it on Atlas with an IP allowlist, or bound to localhost / the private network.
  Never expose `27017`.
- `BASE_URL`/website part has no login - put HTTPS + auth (reverse proxy or Cloudflare Tunnel) in
  front of it before sharing the URL.
- Back up the `downloads` and `mongodb` volumes; a split deployment multiplies the places where
  state can live.

## 8. Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `No such file or directory` / upload fails although the download "finished" | the daemon wrote into *its* own path, the bot looks at a different one | mount the same directory at the same absolute path on every part (`DOWNLOADS_PATH`), check `DOWNLOAD_DIR` in `config.env` / the DB |
| torrent added, but the bot never reports progress | `QBIT_HOST`/`QBIT_PORT` wrong, or WebUI rejects the credentials (look for `401`/`Forbidden` in the log) | run `deploy/set_qbittorrent_auth.py` on the daemon and use the same `QBIT_USERNAME`/`QBIT_PASSWORD` on the bot box |
| startup hangs at `Initializing Aria2c` or `aria2.getGlobalOption` times out | `ARIA2_SECRET` mismatch, RPC not listening outside localhost, or firewall | compare the secret on both sides, set `ARIA2_LISTEN_ALL=true`, check `ARIA2_BIND`, open only the private/VPN network |
| `EOFError`/`ConnectionResetError` in the WebUI part | `web/wserver.py` still pointing at localhost | it now reads `ARIA2_HOST`/`QBIT_HOST` too - restart the bot container after changing `.env` |
| Telegram replies with `409 Conflict` | the same `BOT_TOKEN` is polling from two places | stop one of them, or give the clone its own token |
| `Permission denied` when the bot reads a file the daemon created | NFS root-squash / mismatched uid | export with `no_root_squash` restricted to the bot IP, or run the parts with a matching `PUID`/`PGID` |
| downloads are slow only in the split setup | network filesystem or slow link between the boxes | `ARIA2_FILE_ALLOCATION=none`, keep the NFS mount on a fast link, or keep `aria2` on the same box as the files it writes |
| qBittorrent container restarts in a loop | `/usr/src/app` not writable or the WebUI port is taken | check `docker compose logs qbittorrent`, and that `QBIT_PORT` is free |

## 9. Sizing, free tiers and what this means for the Deplexo question

| Box | Parts | RAM | Disk |
| --- | --- | --- | --- |
| bot box | `bot` (+ website) | **300-600 MB** realistic (148 MB idle + ffmpeg/7z per task), 1 vCPU minimum | ~2 GB for the image + deps, only needs space for what is being processed |
| download box | `aria2` + `qbittorrent` | 256 MB minimum, 512 MB-1 GB comfortable | file size x concurrent downloads (+ 40 MB aria2 cache) |
| db box | `mongodb` (or Atlas free) | 256-512 MB | 512 MB-1 GB |

Two practical notes:

- The link between the boxes becomes the new bottleneck. A 10 Mbit/s free-tier link caps the
  whole pipeline at ~1.2 MB/s, no matter how fast the download box is.
- You can even use a **remote mount as the storage part** (rclone mount of a Google
  Drive/S3 bucket as `DOWNLOADS_PATH`), which keeps big files off both hosts - but the bot still
  needs local space for ffmpeg output and thumbnails, and uploads from a network mount are slower.

**Deplexo / tiny free tiers:** splitting does **not** make the 128 MB & 250 MB free plan usable,
because the *bot* part alone (148 MB idle, ~315 MB of dependencies, no persistent volume on the
platform) already exceeds it - and the same is true for most free container tiers. Splitting does
help in a different way: it lets you put each part on the cheapest box that fits it (a 512 MB free
tier for the daemons, a small VPS for the bot, Atlas for the DB, Drive/S3 for the storage), which
is usually cheaper than one bigger machine. The smallest realistic self-hosted combination is
roughly: 512 MB + 512 MB + Atlas free ≈ the cost of one 1-2 GB VPS, so a single $3-5/mo VPS with
`docker-compose.yml` stays the simplest answer - split the stack when you want isolation, a
different download IP/VPN, or to reuse hardware you already have.


