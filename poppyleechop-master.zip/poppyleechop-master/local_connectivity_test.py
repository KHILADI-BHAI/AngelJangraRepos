#!/usr/bin/env python3
"""
Local connectivity test for WZML-X credentials.

Tests each service WITHOUT starting the full bot (since system daemons like
aria2c and qbittorrent-nox are not available on Windows).

Credentials are read from config.env (git-ignored). They are deliberately NOT
hardcoded here: this file is committed to the repository, so a literal token or
Mongo URI inside it would be published.
"""
import sys
import json
import socket
import shutil
import os

import requests
from dotenv import dotenv_values

CONFIG = dict(dotenv_values('config.env'))

print("=" * 70)
print("  WZML-X Local Connectivity Test")
print("  (Testing credentials WITHOUT starting the full bot)")
print("=" * 70)
if not CONFIG:
    print("  config.env not found - copy config_sample.env to config.env first.")
    sys.exit(1)

# ============================================================
# 1. Telegram Bot Token
# ============================================================
print("\n[1] Telegram Bot Token")
BOT_TOKEN = CONFIG.get('BOT_TOKEN', '')

try:
    resp = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getMe", timeout=10)
    data = resp.json()
    if data.get("ok"):
        bot = data.get("result", {})
        print(f"  ✅ Connected to Telegram API")
        print(f"  Bot: @{bot.get('username')} (ID: {bot.get('id')})")
        print(f"  Name: {bot.get('first_name')}")
        resp2 = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates", timeout=10, params={"limit": 1})
        data2 = resp2.json()
        if data2.get("ok"):
            print(f"  Recent updates: {len(data2.get('result', []))} (peeked)")
    else:
        print(f"  ❌ Failed: {data.get('description', 'Unknown')}")
except Exception as e:
    print(f"  ❌ Error: {e}")

# MongoDB Atlas
print("\n[2] MongoDB Atlas")
mongo_url = CONFIG.get('DATABASE_URL', '')
hostname = mongo_url.split('@')[-1].split('/')[0] if '@' in mongo_url else ''
try:
    # SRV hostname has no A record - must check SRV record directly
    try:
        import subprocess
        srv = subprocess.run(
            ["powershell", "-c",
             f"(Resolve-DnsName -Type SRV _mongodb._tcp.{hostname})[0].NameTarget"],
            capture_output=True, text=True, timeout=15
        )
        print(f"  ✅ SRV record exists -> {srv.stdout.strip().splitlines()[0] if srv.stdout.strip() else '?'}")
    except Exception:
        print("  ⚠️  SRV check skipped")

    # Actual connection via pymongo (does proper SRV resolution)
    from pymongo import MongoClient
    client = MongoClient(mongo_url, serverSelectionTimeoutMS=15000)
    info = client.server_info()
    print(f"  ✅ CONNECTED! MongoDB version: {info.get('version', '?')}")
    db_names = client.list_database_names()
    print(f"  ✅ Auth works. Databases: {db_names}")
    client.close()
except Exception as e:
    print(f"  ❌ Connection failed: {e}")

# Google Drive
print("\n[3] Google Drive")
GDRIVE_ID = CONFIG.get('GDRIVE_ID', '')
try:
    resp = requests.get(f"https://drive.google.com/file/d/{GDRIVE_ID}/view", timeout=10, allow_redirects=False)
    if resp.url.startswith("https://drive.google.com"):
        print(f"  ✅ Folder ID '{GDRIVE_ID}' EXISTS on Google Drive")
        api_resp = requests.get(
            f"https://www.googleapis.com/drive/v3/files/{GDRIVE_ID}",
            params={"fields": "id,name,mimeType"},
            timeout=10
        )
        print(f"  API check (no auth): HTTP {api_resp.status_code}")
        if api_resp.status_code == 200:
            print(f"  Publicly accessible!")
        elif api_resp.status_code == 401:
            print(f"  Private (auth required) - expected for service account access")
        elif api_resp.status_code == 404:
            print(f"  ❌ Not found (ID may be invalid)")
    else:
        print(f"  ❌ ID not found or removed")
except Exception as e:
    print(f"  ❌ Error: {e}")

# Mega.nz
print("\n[4] Mega.nz")
MEGA_EMAIL = CONFIG.get('MEGA_EMAIL', '')
try:
    socket.getaddrinfo("gianes.com", 443)
    print(f"  Domain 'gianes.com' resolves")
except:
    print(f"  ❌ Domain 'gianes.com' does NOT resolve (dead domain)")
try:
    resp = requests.get("https://g.api.mega.co.nz", timeout=5)
    print(f"  Mega API endpoint reachable (HTTP {resp.status_code})")
except:
    print(f"  ⚠️  Mega API endpoint not reachable")

# System Daemons
print("\n[5] System Daemons")
for daemon in ["aria2c", "qbittorrent-nox", "docker"]:
    path = shutil.which(daemon)
    if path:
        print(f"  ✅ {daemon}: found at {path}")
    else:
        print(f"  ❌ {daemon}: NOT FOUND")

# Summary
print("\n" + "=" * 70)
print("  SUMMARY")
print("=" * 70)
print("  Bot Token (Telegram):     see [1] above")
print("  MongoDB Atlas (NEW):      see [2] above")
print("  Google Drive Folder:      see [3] above")
print("  Mega.nz Account:          see [4] above")
print("  System Daemons:           see [5] above")
print("=" * 70)