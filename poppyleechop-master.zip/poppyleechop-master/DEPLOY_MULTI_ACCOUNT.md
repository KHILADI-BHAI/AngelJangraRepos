# Multi-account deployment: SnapDeploy + Deplexo + Vercel

Answer to "half on SnapDeploy, half on Deplexo, dashboard/static/API on Vercel, one account per
part, one zip per target".

## Configuration: enter it once, on Vercel

`https://poppyleechop.vercel.app/settings` is the single place you type configuration.
Every container pulls its own values from there at boot, so you never paste the bot token,
the Mongo URI or the Drive ID into a hosting platform again.

**Vercel itself needs only three values** (generated for you in `deploy/dist/env/vercel.env`):

| Variable | Why |
| --- | --- |
| `ADMIN_TOKEN` | unlocks `/settings` - write authority over your credentials |
| `CONFIG_MASTER_KEY` | encrypts stored values at rest. **Lose it and the settings are unreadable.** |
| `DATABASE_URL` | MongoDB Atlas, where the settings and the bot's own data live |

**Each container needs exactly one paste:**

```
COMPONENT_ID=acc1
COMPONENT_TOKEN=<the one-time token the settings page shows you>
```

`deploy/paas/config_pull.py` calls `/api/resolve` at boot, receives only that component's
allowlisted keys, and writes `config.env`.

| Component | Receives | Never receives |
| --- | --- | --- |
| `runtime` | 113 bot keys, `API_TOKEN`, `BASE_URL` | the gateway token, other runtimes' tokens |
| `gateway` | `RUNTIMES` (each runtime's URL + token), its own token | `BOT_TOKEN`, Drive credentials |
| `daemons` | aria2/qBittorrent hosts, ports, secrets, paths | everything else |

Isolation is enforced by the endpoint, not by convention - a runtime token asking for
gateway keys gets nothing.

### Two-way sync with Telegram /settings

A value changed in `/settings` is written to Mongo first, then mirrored to the dashboard.
Two rules keep that safe:

1. **`db_load()` never syncs upwards** - it writes the whole in-memory config on every
   boot, so syncing it would let each restart overwrite the dashboard with a stale view.
2. **Config precedence now merges.** Previously a changed `config.env` silently discarded
   every `/settings` value; with central config that would wipe your bot settings on each
   dashboard save. Keys the deployment does not mention keep their `/settings` value.

If the control plane is unreachable the Telegram edit still succeeds; only the mirror is
skipped and the failure is logged.

### Order of operations

1. Deploy `05-vercel-dashboard.zip` to Vercel, set the three variables, redeploy.
2. Open `/settings`, enter the admin token, fill in **Values**, save.
3. On **Components & credentials** create `acc1` (runtime), `gw` (gateway), and a daemons
   box if needed. Copy each token as shown - it is never shown again.
4. Deploy a runtime package to SnapDeploy with its two lines.
5. Register the runtime's public URL on the Components tab, then set `API_TOKEN` and
   `RESTART_API=true` in Values.
6. Deploy the gateway to Deplexo with `COMPONENT_ID=gw` and its token; `RUNTIMES` is
   entered once, in the dashboard.

The status column shows when each component is running the newest config (`config v7 of v7`).

### Limitations

- Credential changes need a **restart**; the bot reads config at import.
- Two-way sync **requires MongoDB**. Without it the bot has no `/settings` persistence,
  so there is nothing to sync.
- Config is pulled at boot, so the **Vercel Hobby cron limit does not affect it**.
- Vercel is a single point of failure for *new* boots; a running container keeps its
  cached `config.env`, and a fresh boot with no cache refuses to start half-configured.
- SnapDeploy Free still sleeps after ~15 min idle - a Telegram bot sends no HTTP traffic.

---

- Generate the packages: `python deploy/build_packages.py --accounts 3`
- Validate them: `python deploy/verify_packages.py`
- Prove no credential leaks: `python deploy/check_no_secrets.py`
- Tests: `deploy/test_config_service.js`, `deploy/test_config_pull.py`,
  `deploy/test_control_api.py`, `deploy/test_gateway.py`

---

## 1. What runs where

| Part | Runs on | Account | Why there |
| --- | --- | --- | --- |
| **Runtime** - bot + aria2c + qbittorrent-nox in ONE container | SnapDeploy (or Deplexo) | **acc1**, acc2, acc3... | The daemons must write the exact absolute paths the bot reads back. One container = one filesystem = no mount needed. Each account gets its own container **and its own Telegram token** (`/clone`). |
| **Control-plane gateway** - stateless aggregating API | Deplexo | **acc1** | ~60 MB RSS, no disk, no DB: the one piece that fits Deplexo's small plans, and it hides every runtime token from the browser. |
| **File selector + API** (optional) | Deplexo | **acc2** | `web/wserver.py` never imports the bot, it only talks to aria2/qBittorrent, so it can live on a different account. |
| **Dashboard, static UI, API facade, cron** | Vercel | one project | Static hosting + short-lived serverless functions. |
| **Database, settings, users, RSS, tokens** | MongoDB Atlas M0 | - | Already external in this repo; both PaaS wipe their disks on redeploy. |
| **Optional daemons-only box** | VPS or your PC | - | The only way to get a persistent disk / a real cross-host split. |

```
browser --> Vercel dashboard + /api/* --> Deplexo gateway --> SnapDeploy acc1 runtime
                                                           --> SnapDeploy acc2 runtime
                                                           --> Deplexo / VPS runtime
                                                              (all share one Atlas DB)
```

## 2. The limits that force this layout

| | SnapDeploy | Deplexo | Vercel |
| --- | --- | --- | --- |
| Free tier | 4 containers, 512 MB each, **100 container-hours/month**, 10 deploys/day, **auto-sleeps after ~15 min without HTTP traffic**, wake ~60 s | 1 app, 0.25 CPU, **128 MB RAM / 250 MB disk**, 10 Mbit/s, 100 GB/mo | Static + Functions (Hobby): 300 s max duration, 2 GB, 250 MB bundle |
| Cheapest always-on | Always-On Small **$12** (512 MB / 0.25 vCPU), Medium **$25** (2 GB / 1 vCPU), Large $45; **Sprint Pack $1 = 24 h** | **Starter $5** (3 apps, 512 MB, 2 GB disk), Pro **$10** (1 GB, 10 GB disk) | free |
| Persistent volumes | **none** - "filesystems are ephemeral, use S3/R2" | **none** on any plan ("coming soon" on Business) | **none** |
| Ports | HTTP routing (AWS Fargate), custom domain on paid | HTTP routing on `PORT` (defaults to 3000) | HTTP/S + rewrites |
| Docker | your Dockerfile | `deplexo.yaml` (`framework: dockerfile`) | container images (beta) |

Consequences to plan for:

1. **Free SnapDeploy cannot keep a Telegram bot awake** - a polling bot sends no HTTP traffic, so
   after ~15 quiet minutes the container sleeps. Point a 5-minute monitor (or the Vercel cron at
   `/api/ping`) at the app to defeat the idle timer, or pay for Always-On. 100 hours/month is
   roughly 4 days of continuous running per account.
2. **Deplexo Free cannot host the runtime** - 128 MB RAM versus ~148 MB for the idle bot, and
   250 MB disk versus a ~315 MB dependency tree. It is ideal for the gateway (Flask + gunicorn +
   requests only) and for the slim file-selector image.
3. **Nothing is persistent anywhere** - which is why `DATABASE_URL` (Atlas) is mandatory in every
   runtime package: it restores settings, users, RSS entries and uploaded thumbnails after a
   redeploy.

## 3. The packages

`python deploy/build_packages.py --accounts 3 --runtime-host snapdeploy --clean` writes into
`deploy/dist/`:

| Zip | Deployer | Account | Contents |
| --- | --- | --- | --- |
| `01-snapdeploy-acc1-runtime.zip` | SnapDeploy | acc1 | repo code + `Dockerfile` + `deplexo.yaml` + `deploy/paas/entrypoint.sh` + `config.keys` + `.env.example` + `DEPLOY.txt` |
| `02-snapdeploy-acc2-runtime.zip` | SnapDeploy | acc2 | same, for the second Telegram token |
| `0N-*-accN-runtime.zip` | SnapDeploy | accN | same pattern, one per extra account |
| `0N-deplexo-acc1-gateway.zip` | Deplexo | acc1 | `app.py`, `Dockerfile`, `deplexo.yaml`, `.env.example` |
| `0N-deplexo-acc2-web-selector.zip` | Deplexo | acc2 | `web/`, `requirements-web.txt`, slim `Dockerfile` |
| `0N-vercel-dashboard.zip` | Vercel | - | `public/`, `api/`, `vercel.json`, `package.json` |
| `0N-daemons-vps.zip` | VPS / PC | - | `docker-compose.split.yml`, `deploy/aria.remote.sh`, `set_qbittorrent_auth.py`, `SPLIT_DEPLOY.md`, `start_windows.ps1` |

`deploy/dist/env/` holds the same variables with **real values filled in**
(`snapdeploy-acc1.env`, ... `vercel.env`) plus freshly generated `API_TOKEN`s. It is gitignored:
keep it private and paste from it into the platform UIs. The zips themselves carry placeholders
only, and `verify_packages.py` fails if a value from your local `config.env` appears inside one.

Runtime zips are ~245 KB: `.venv` (315 MB), `qBittorrent/` (270 MB), `bot.session`, `config.env`
and every cache are excluded on purpose.

## 4. Deploy order

1. **Atlas M0 first** - cluster, DB user, network access `0.0.0.0/0`, copy the connection string.
2. **Runtimes** (`*-runtime.zip`), one repo per account:
   - SnapDeploy: New app -> GitHub -> Docker -> environment variables -> Deploy.
   - Set `PORT` (e.g. 8080) and `BASE_URL` to the app's public URL, keep `EXTERNAL_DAEMONS=false`,
     `BOT_TOKEN` = that account's own token.
   - Sanity: `https://<app>/healthz` -> `ok`; `https://<app>/api/health` -> aria2 + qbittorrent up.
3. **Gateway** (`*-gateway.zip`) on Deplexo acc1 with
   `RUNTIMES=acc1=https://...|API_TOKEN_1,acc2=https://...|API_TOKEN_2`.
   Sanity: `https://<gateway>/api/v1/status` with the `X-API-Token` header.
4. **Vercel dashboard** with `GATEWAY_URL`, `GATEWAY_TOKEN`, `DASHBOARD_TOKEN`, `DATABASE_URL`,
   `BOT_ID` (the numeric part of `BOT_TOKEN`).
5. **Point each bot's `BASE_URL` at the Vercel project** so users get one stable HTTPS "Select
   Files" link; Vercel proxies `/app/files/*` to `RUNTIME_URL`.
6. Optional: `*-web-selector.zip` on Deplexo acc2 when the selector should live away from the bot.
   For a persistent Linux download box, unpack `*-daemons-vps.zip`; it includes the VPS sizing,
   network, and security guidance in `README-DEPLOY.md`. For the exact two-host NFS/Tailscale
   layout, see `SPLIT_DEPLOY.md`.

## 5. Why the bot and its daemons cannot be split across two PaaS accounts

The bot hands aria2/qBittorrent absolute paths (`dir`, `save_path`) and later reads those files
itself to unpack, split and upload. Both platforms are ephemeral-disk, HTTP-routed and offer no
volumes or NFS, so the two halves can never see the same file. Splitting them would produce tasks
that download "successfully" into a sandbox the bot cannot read.

Split by **account per complete runtime** instead: identical stack, separate Telegram token,
separate disk, all behind one gateway and one dashboard. The genuine cross-host split (bot on one
machine, daemons on another) needs a shared NFS/SMB/sshfs mount - see `SPLIT_DEPLOY.md`.

## 6. Three rules that break deployments if ignored

| Rule | What happens otherwise |
| --- | --- |
| `BOT_TOKEN` unique per container | Telegram polling returns `409 Conflict` and only one instance stays alive |
| `UPSTREAM_REPO` empty | `update.py` runs `git reset --hard origin/<branch>`, deleting this split-deployment code on every boot |
| `PORT` == `BASE_URL_PORT` | the platform routes to `PORT`; if the bot binds 80 the health check fails and the container is recycled |

## 7. Validation

```bash
python deploy/build_packages.py --accounts 2 --clean   # build
python deploy/verify_packages.py                        # required files, LF endings, no secret leaks
python deploy/test_control_api.py                       # boots web.wserver, exercises every /api route
python deploy/test_gateway.py                           # boots gateway + runtime, checks aggregation
```

`test_control_api.py` and `test_gateway.py` run the real code against whatever aria2/qBittorrent
are reachable and print PASS/FAIL per route, so they work as a pre/post-deploy check on any host.

## 8. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| Container dies right after boot | `BASE_URL` unset (the web app is never started, so no port to route to) - set it and `PORT`. |
| `/api/health` shows `aria2 up:false` | daemons not started: check `EXTERNAL_DAEMONS` is `false` and look for `Aria2c initializing error` in the logs. |
| Settings changed in Telegram are ignored | The platform env changed, so `settings.deployConfig` no longer matches `config.env` and the DB copy is skipped - keep env values stable or set them once. |
| Dashboard says "control plane unreachable" | Gateway asleep/stopped, or `GATEWAY_TOKEN` mismatch. |
| Both bots answer, then one goes silent | Same token deployed twice - use `/clone`. |
| Build takes forever or fails | `.dockerignore` missing in the uploaded repo: `.venv`/`qBittorrent/` are being uploaded. |

