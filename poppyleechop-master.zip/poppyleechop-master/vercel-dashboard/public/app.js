// WZML-X admin dashboard - plain ES2020, no build step, no dependencies.
const state = { token: localStorage.getItem('wzmlx_token') || '', runtimes: [], timer: null };

const $ = (id) => document.getElementById(id);

function log(message) {
  const el = $('log');
  el.textContent = `[${new Date().toLocaleTimeString()}] ${message}\n${el.textContent}`;
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function bytes(n) {
  const value = Number(n) || 0;
  if (value < 1024) return `${value} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  let v = value;
  do { v /= 1024; i += 1; } while (v >= 1024 && i < units.length - 1);
  return `${v.toFixed(v >= 10 ? 0 : 1)} ${units[i]}`;
}

const speed = (n) => `${bytes(n)}/s`;

function card(key, value) {
  return `<div class="card"><span class="k">${esc(key)}</span><span class="v">${esc(value)}</span></div>`;
}

const BADGE = new Set(['active', 'waiting', 'paused', 'complete', 'error']);
const badge = (s) => `<span class="badge ${BADGE.has(s) ? s : ''}">${esc(s)}</span>`;

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'X-API-Token': state.token, ...(options.headers || {}) },
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 300) }; }
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function renderSummary(totals = {}, checkedAt) {
  const up = totals.runtimes ? `${totals.up}/${totals.runtimes}` : '-';
  $('summary').innerHTML = [
    card('Runtimes up', up),
    card('Active tasks', totals.active_tasks ?? 0),
    card('Download', speed(totals.down_speed)),
    card('Upload', speed(totals.up_speed)),
    card('Free disk', bytes(totals.free_disk)),
    card('Checked', checkedAt || '-'),
  ].join('');
}

function renderRuntimes(rows = []) {
  $('runtime-count').textContent = `${rows.filter((r) => r.up).length} up of ${rows.length}`;
  if (!rows.length) {
    $('runtimes').innerHTML = '<div class="card"><span class="k">runtimes</span><span class="v">none configured</span></div>';
    return;
  }
  $('runtimes').innerHTML = rows.map((r) => {
    const aria = (r.daemons || {}).aria2 || {};
    const qbit = (r.daemons || {}).qbittorrent || {};
    const host = r.host || {};
    return `
      <div class="runtime ${r.up ? 'up' : 'down'}">
        <div class="name">${esc(r.name)} ${r.up ? '' : '· down'}</div>
        <div class="url">${esc(r.url || '')}</div>
        <div class="stats">
          <span>aria2 ${aria.up ? esc(aria.version || 'up') : '✗'}</span>
          <span>qbit ${qbit.up ? esc(qbit.version || 'up') : '✗'}</span>
          <span>↓ ${speed(aria.down_speed)}</span>
          <span>↑ ${speed(aria.up_speed)}</span>
          <span>${esc(aria.active ?? 0)} active</span>
          <span>${bytes((host.disk || {}).free)} free</span>
          <span>${esc(r.latency_ms ?? '-')} ms</span>
        </div>
        ${r.error ? `<div class="muted">${esc(r.error)}</div>` : ''}
      </div>`;
  }).join('');
}

function fillRuntimeSelect() {
  const select = $('runtime');
  const current = select.value;
  const names = state.runtimes.map((r) => r.name);
  select.innerHTML = names.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join('') || '<option value="">-</option>';
  if (names.includes(current)) select.value = current;
}

function renderTasks(data = {}) {
  const tasks = data.tasks || [];
  const body = $('tasks').querySelector('tbody');
  if (!tasks.length) {
    body.innerHTML = '<tr><td colspan="7" class="muted">no tasks</td></tr>';
    return;
  }
  body.innerHTML = tasks.map((t) => `
    <tr>
      <td>${esc(t.client)}</td>
      <td class="name" title="${esc(t.name)}">${esc(t.name)}</td>
      <td>${badge(t.state)}</td>
      <td><div class="bar ${t.state === 'active' ? 'active' : ''}"><i style="width:${Math.max(0, Math.min(100, Number(t.progress) || 0))}%"></i></div><span class="muted">${esc(t.progress)}%</span></td>
      <td>${bytes(t.size)}</td>
      <td>${speed(t.down_speed)}</td>
      <td>
        <button class="tiny" data-act="pause" data-id="${esc(t.id)}">pause</button>
        <button class="tiny" data-act="resume" data-id="${esc(t.id)}">resume</button>
        <button class="tiny" data-act="cancel" data-id="${esc(t.id)}">cancel</button>
      </td>
    </tr>`).join('');
}

function renderMongo(data = {}) {
  const users = data.users || {};
  $('mongo').innerHTML = [
    card('Users', users.total ?? 0),
    card('Sudo', users.sudo ?? 0),
    card('Authorized', users.auth ?? 0),
    card('Incomplete tasks', (data.incomplete_tasks || {}).total ?? 0),
    card('RSS users', (data.rss || []).length),
    card('PM users', (data.pm_users || {}).total ?? 0),
  ].join('');
  const rows = users.rows || [];
  $('users').innerHTML = rows.length
    ? `<table><thead><tr><th>User id</th><th>Sudo</th><th>Authorized</th><th>Split size</th></tr></thead><tbody>${
      rows.map((u) => `<tr><td>${esc(u._id)}</td><td>${u.is_sudo ? 'yes' : ''}</td><td>${u.is_auth ? 'yes' : ''}</td><td>${esc(u.split_size || '')}</td></tr>`).join('')
    }</tbody></table>`
    : '<p class="muted">No user data (set DATABASE_URL and BOT_ID on the Vercel project).</p>';
}

async function loadStatus() {
  try {
    const data = await api('/api/status');
    state.runtimes = data.runtimes || [];
    renderSummary(data.totals || {}, new Date().toLocaleTimeString());
    renderRuntimes(state.runtimes);
    fillRuntimeSelect();
    $('target').textContent = `${(data.totals || {}).up || 0} runtime(s) reachable`;
  } catch (e) {
    $('target').textContent = 'control plane unreachable';
    log(`status: ${e.message}`);
  }
}

async function loadTasks() {
  const runtime = $('runtime').value;
  try {
    const data = await api(`/api/torrents?runtime=${encodeURIComponent(runtime)}`);
    renderTasks(data);
    const errors = data.errors || {};
    if (errors.aria2) log(`aria2: ${errors.aria2}`);
    if (errors.qbittorrent) log(`qbittorrent: ${errors.qbittorrent}`);
  } catch (e) {
    log(`tasks: ${e.message}`);
  }
}

async function loadMongo() {
  try {
    renderMongo(await api('/api/users?what=all'));
    $('mongo-state').textContent = new Date().toLocaleTimeString();
  } catch (e) {
    $('mongo-state').textContent = e.message;
  }
}

async function act(id, action) {
  try {
    const data = await api('/api/action', {
      method: 'POST',
      body: JSON.stringify({ id, action, runtime: $('runtime').value }),
    });
    log(`${action} ${id} -> ${data.client || 'ok'}`);
  } catch (e) {
    log(`${action} failed: ${e.message}`);
  }
  await loadTasks();
}

async function clearFinished() {
  try {
    const data = await api('/api/action', {
      method: 'POST',
      body: JSON.stringify({ clear: true, runtime: $('runtime').value }),
    });
    log(`cleared ${JSON.stringify(data.removed)}`);
  } catch (e) {
    log(`clear failed: ${e.message}`);
  }
  await loadTasks();
}

function tick() {
  if (!state.token) return;
  loadStatus();
  loadTasks();
}

function startAuto() {
  if (state.timer) clearInterval(state.timer);
  if ($('autorefresh').checked && state.token) state.timer = setInterval(tick, 5000);
}

function init() {
  $('token').value = state.token;
  $('save').onclick = () => {
    state.token = $('token').value.trim();
    localStorage.setItem('wzmlx_token', state.token);
    log(state.token ? 'token saved' : 'token cleared');
    if (state.token) { tick(); loadMongo(); startAuto(); }
  };
  $('autorefresh').onchange = startAuto;
  $('runtime').onchange = loadTasks;
  $('clear').onclick = clearFinished;
  $('clearlog').onclick = () => { $('log').textContent = ''; };
  document.querySelectorAll('[data-reload]').forEach((btn) => {
    btn.onclick = () => { tick(); loadMongo(); };
  });
  $('tasks').addEventListener('click', (event) => {
    const btn = event.target.closest('button[data-act]');
    if (btn) act(btn.dataset.id, btn.dataset.act);
  });
  if (state.token) { tick(); loadMongo(); startAuto(); }
}

init();

