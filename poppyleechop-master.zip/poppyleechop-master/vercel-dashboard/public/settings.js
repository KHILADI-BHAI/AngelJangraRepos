// WZML-X control plane settings page. Plain ES2020, no build step, no dependencies.
//
// Two tabs: Values (every config key, secrets write-only) and Components (every
// credential, generated here and shown exactly once). The admin token lives in
// sessionStorage so it does not outlive the tab.
'use strict';

const $ = (id) => document.getElementById(id);
const state = {
  admin: sessionStorage.getItem('wzmlx_admin') || '',
  config: null,
  components: [],
  dirty: new Set(),
};

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function say(message, kind) {
  $('status').textContent = message || '';
  if (kind) {
    $('banner').hidden = false;
    $('banner').className = 'banner ' + kind;
    $('banner').innerHTML = message;
  } else {
    $('banner').hidden = true;
  }
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-Admin-Token': state.admin,
      ...(options.headers || {}),
    },
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 300) }; }
  if (!res.ok || data.ok === false) throw new Error(data.error || 'HTTP ' + res.status);
  return data;
}

// --- Values tab ------------------------------------------------------------
function renderGroups() {
  const select = $('group');
  const keys = (state.config && state.config.keys) || {};
  const groups = [...new Set(Object.values(keys).map((k) => k.group))].sort();
  const keep = select.value;
  select.innerHTML = '<option value="">all groups</option>'
    + groups.map((g) => '<option value="' + esc(g) + '">' + esc(g) + '</option>').join('');
  select.value = keep;
}

function rowHtml(key, info) {
  // Treat "configured"/"mask" as proof of secrecy even if `secret` is missing, so a
  // schema or API change can never render a stored credential as an empty plain field.
  const isSecret = info.secret === true || ('configured' in info) || ('mask' in info);
  const scope = info.scope === 'runtime' ? '' : '<span class="tag">' + esc(info.scope) + '</span>';
  const who = info.changed_by
    ? '<span class="tag changed">' + (info.changed_by === 'telegram' ? 'Telegram' : 'Vercel') + '</span>' : '';
  const drift = isSecret
    ? (info.configured ? '<span class="tag matches">set</span>' : '<span class="tag not-set">not set</span>')
    : '<span class="tag ' + esc(info.drift || 'unknown') + '">' + esc(info.drift || 'unknown') + '</span>';

  let field;
  if (isSecret) {
    field = '<input type="password" data-dirty="' + esc(key) + '" placeholder="'
      + (info.configured ? 'unchanged - type to replace' : 'enter the value') + '" autocomplete="new-password" />';
  } else {
    const big = info.type === 'text' || (info.default || '').length > 80;
    field = big
      ? '<textarea data-dirty="' + esc(key) + '">' + esc(info.value || '') + '</textarea>'
      : '<input type="text" data-dirty="' + esc(key) + '" value="' + esc(info.value || '') + '" />';
  }
  const meta = isSecret ? (info.configured ? esc(info.mask) : 'never set') : esc(info.type);
  return '<div class="keyrow">'
    + '<div class="k">' + esc(key) + scope + '<div class="meta">' + meta + '</div></div>'
    + field
    + '<div>' + drift + who + '</div>'
    + '</div>';
}

function renderValues() {
  const keys = (state.config && state.config.keys) || {};
  const text = $('filter').value.trim().toUpperCase();
  const group = $('group').value;
  const groups = new Map();
  for (const [key, info] of Object.entries(keys)) {
    if (text && key.indexOf(text) === -1) continue;
    if (group && info.group !== group) continue;
    if (!groups.has(info.group)) groups.set(info.group, []);
    groups.get(info.group).push([key, info]);
  }
  const host = $('keys');
  if (!groups.size) {
    host.innerHTML = '<p class="muted">No keys match that filter.</p>';
    return;
  }
  const html = [];
  for (const [name, rows] of groups.entries()) {
    html.push('<div class="group-title">' + esc(name) + '</div>');
    for (const [key, info] of rows) html.push(rowHtml(key, info));
  }
  host.innerHTML = html.join('');
  host.querySelectorAll('[data-dirty]').forEach((el) => {
    el.addEventListener('input', () => {
      el.classList.add('dirty');
      state.dirty.add(el.dataset.dirty);
      $('save').disabled = false;
    });
  });
}

async function loadConfig() {
  state.config = await api('/api/config');
  $('version').textContent = 'config v' + state.config.version;
  renderGroups();
  renderValues();
  if (!state.config.bot_reachable) {
    say('No live bot found in MongoDB. Set <code>BOT_ID</code> (the numeric part of your bot '
      + 'token) on the Vercel project to see per-key drift against the running bot.', 'warn');
  } else {
    say('Connected.', null);
  }
  return state.config;
}

async function save() {
  const patch = {};
  for (const key of state.dirty) {
    const el = document.querySelector('[data-dirty="' + (window.CSS && CSS.escape ? CSS.escape(key) : key) + '"]');
    if (!el) continue;
    const value = el.value.trim();
    if (value === '') continue; // empty means "leave the stored secret alone"
    patch[key] = value;
  }
  if (!Object.keys(patch).length) {
    say('Nothing changed.', 'warn');
    return;
  }
  $('save').disabled = true;
  try {
    const result = await api('/api/config', { method: 'POST', body: JSON.stringify({ values: patch }) });
    state.dirty.clear();
    await loadConfig();
    $('save').disabled = true;
    await loadComponents();
    say('Saved ' + result.count + ' value(s). Config is now v' + result.version
      + '. Components pick it up on their next restart.', 'ok');
  } catch (e) {
    $('save').disabled = false;
    say('Save failed: ' + esc(e.message), 'err');
  }
}

// --- Components tab --------------------------------------------------------
function age(minutes) {
  if (minutes === null || minutes === undefined) return 'never';
  if (minutes < 1) return 'just now';
  if (minutes < 60) return minutes + 'm ago';
  if (minutes < 1440) return Math.round(minutes / 60) + 'h ago';
  return Math.round(minutes / 1440) + 'd ago';
}

function compHtml(c) {
  const cls = ['ok', 'stale', 'error', 'idle'].indexOf(c.state) === -1 ? 'idle' : c.state;
  const current = state.config ? state.config.version : 0;
  const detail = c.last_error
    ? '<span class="state error">' + esc(c.last_error) + '</span>'
    : '<span class="state ' + cls + '">' + esc(c.state) + ' &middot; last seen ' + esc(age(c.age_minutes))
      + ' &middot; config v' + esc(c.config_version || 0) + ' of v' + esc(current) + '</span>';
  const restart = c.role === 'runtime' && c.url ? '<button data-restart="' + esc(c.name) + '">Restart</button>' : '';
  return '<div class="comp">'
    + '<h3>' + esc(c.name) + '<span class="tag">' + esc(c.role) + '</span></h3>'
    + '<div class="url">' + esc(c.url || 'no URL registered') + '</div>'
    + detail
    + '<div class="actions">'
    + '<button data-rotate="' + esc(c.name) + '">Rotate token</button>'
    + '<button data-copyurl="' + esc(c.name) + '">Copy URL</button>'
    + restart
    + '<button data-editurl="' + esc(c.name) + '">Set URL</button>'
    + '</div></div>';
}

function bindComponentActions() {
  document.querySelectorAll('[data-rotate]').forEach((btn) => {
    btn.onclick = async () => {
      const name = btn.dataset.rotate;
      if (!confirm('Rotate the token for "' + name + '"? The current token stops working immediately.')) return;
      const result = await componentAction('rotate', { name });
      if (result) showToken(name, result.token, result.note);
    };
  });
  document.querySelectorAll('[data-copyurl]').forEach((btn) => {
    btn.onclick = async () => {
      const item = state.components.find((c) => c.name === btn.dataset.copyurl);
      if (!item || !item.url) return say('No URL registered for that component yet.', 'warn');
      try {
        await navigator.clipboard.writeText(item.url);
        say('Copied the URL for ' + item.name + '.', 'ok');
      } catch (e) {
        say('Could not use the clipboard.', 'warn');
      }
    };
  });
  document.querySelectorAll('[data-editurl]').forEach((btn) => {
    btn.onclick = async () => {
      const item = state.components.find((c) => c.name === btn.dataset.editurl);
      const url = prompt('Public URL for ' + item.name + ' (how the dashboard reaches it):', item.url || '');
      if (url === null) return;
      const result = await componentAction('set_url', { name: item.name, url });
      if (result) say('URL saved for ' + result.name + '.', 'ok');
    };
  });
  document.querySelectorAll('[data-restart]').forEach((btn) => {
    btn.onclick = async () => {
      const name = btn.dataset.restart;
      const item = state.components.find((c) => c.name === name);
      if (!confirm('Restart ' + name + '? Active downloads on that container are lost.')) return;
      try {
        const res = await fetch(item.url + '/api/restart', {
          method: 'POST', headers: { 'X-API-Token': sessionStorage.getItem('wzmlx_runtime') || '' },
        });
        const data = await res.json().catch(() => ({}));
        if (data.ok) say(name + ' is restarting and will pull the new config on boot.', 'ok');
        else say('Restart refused: ' + esc(data.error || 'HTTP ' + res.status)
          + '. The runtime needs RESTART_API=true.', 'warn');
      } catch (e) {
        say('Restart failed: ' + esc(e.message), 'err');
      }
    };
  });
}

function renderComponents() {
  $('components').innerHTML = state.components.length
    ? '<div class="card-grid">' + state.components.map(compHtml).join('') + '</div>'
    : '<p class="muted">No components yet. Create one below, then paste its token into that container.</p>';
  bindComponentActions();
}

async function loadComponents() {
  const data = await api('/api/report');
  state.components = data.components || [];
  $('version').textContent = 'config v' + data.version;
  renderComponents();
  return data;
}

function showToken(name, token, note) {
  const box = $('token-output');
  box.hidden = false;
  box.innerHTML = '<strong>Token for ' + esc(name) + '</strong>'
    + '<div class="small">' + esc(note || '') + '</div>'
    + '<code>' + esc(token) + '</code>'
    + '<div class="actions"><button id="copy-token">Copy</button>'
    + '<button id="dismiss-token">I have saved it</button></div>';
  $('copy-token').onclick = async () => {
    try {
      await navigator.clipboard.writeText(token);
      say('Token copied to the clipboard.', 'ok');
    } catch (e) {
      say('Could not use the clipboard - select the text and copy it manually.', 'warn');
    }
  };
  $('dismiss-token').onclick = () => { box.hidden = true; };
}

async function componentAction(action, body) {
  try {
    const result = await api('/api/settings', { method: 'POST', body: JSON.stringify({ action: action, ...body }) });
    await loadComponents();
    return result;
  } catch (e) {
    say(action + ' failed: ' + esc(e.message), 'err');
    return null;
  }
}

// --- wiring ----------------------------------------------------------------
function init() {
  $('admin').value = state.admin;
  $('save').disabled = true;

  document.querySelectorAll('.tab').forEach((tab) => {
    tab.onclick = () => {
      if (!tab.dataset.tab) return;
      document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      $('panel-values').hidden = tab.dataset.tab !== 'values';
      $('panel-components').hidden = tab.dataset.tab !== 'components';
      if (tab.dataset.tab === 'components') loadComponents().catch((e) => say(e.message, 'err'));
    };
  });

  $('connect').onclick = async () => {
    state.admin = $('admin').value.trim();
    sessionStorage.setItem('wzmlx_admin', state.admin);
    if (!state.admin) return say('Enter the admin token you set on the Vercel project.', 'warn');
    try {
      await loadConfig();
      await loadComponents();
    } catch (e) {
      say('Cannot connect: ' + esc(e.message), 'err');
    }
  };

  $('reload').onclick = () => $('connect').onclick();
  $('save').onclick = save;
  $('filter').oninput = renderValues;
  $('group').onchange = renderValues;
  $('refresh-components').onclick = () => loadComponents().catch((e) => say(e.message, 'err'));

  $('new-component').onsubmit = async (event) => {
    event.preventDefault();
    const name = $('nc-name').value.trim();
    if (!name) return say('A component needs a name.', 'warn');
    const result = await componentAction('create', {
      name: name, role: $('nc-role').value, url: $('nc-url').value.trim(),
    });
    if (result) {
      $('nc-name').value = '';
      $('nc-url').value = '';
      showToken(name, result.token, result.note);
    }
  };

  if (state.admin) $('connect').onclick();
}

init();
