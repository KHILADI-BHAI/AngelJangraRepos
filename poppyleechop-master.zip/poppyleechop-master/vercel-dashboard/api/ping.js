// GET /api/ping -> keep-alive / uptime probe.
//
// Vercel Hobby only allows low-frequency crons, so this is scheduled once a day in
// vercel.json. For SnapDeploy Free (auto-sleeps after ~15 min without traffic) point a
// free 5-minute monitor at this URL instead: it nudges the gateway AND the runtime, which
// is what resets SnapDeploy's idle timer. Set CRON_SECRET to lock the endpoint down.
const { ok, fail, guard, callUpstream, GATEWAY_URL, RUNTIME_URL } = require('./_lib');

module.exports = async (req, res) => {
  const secret = process.env.CRON_SECRET;
  const isCron = secret ? req.headers.authorization === `Bearer ${secret}` : false;
  if (!isCron && !guard(req, res)) return;

  const probe = async (label, fn) => {
    const started = Date.now();
    try {
      const { status } = await fn();
      return { target: label, status, up: status >= 200 && status < 400, ms: Date.now() - started };
    } catch (e) {
      return { target: label, up: false, ms: Date.now() - started, error: e.message };
    }
  };

  try {
    const results = [];
    if (GATEWAY_URL) results.push(await probe('gateway', () => callUpstream('/healthz')));
    if (RUNTIME_URL) results.push(await probe('runtime', () => callUpstream('/healthz')));
    if (!results.length) {
      fail(res, 500, 'Neither GATEWAY_URL nor RUNTIME_URL is set');
      return;
    }
    ok(res, { time: new Date().toISOString(), probed: results, all_up: results.every((r) => r.up) });
  } catch (e) {
    fail(res, 502, `ping failed: ${e.message}`);
  }
};
