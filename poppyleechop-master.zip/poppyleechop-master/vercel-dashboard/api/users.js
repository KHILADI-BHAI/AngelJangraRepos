// GET /api/users?what=all|users|tasks|rss|config -> read-only views straight from MongoDB Atlas.
// The bot writes these collections itself (bot/helper/ext_utils/db_handler.py), so nothing
// extra is needed on the runtime side. Secrets are stripped by publicConfig().
const { ok, fail, guard, mongo, publicConfig, mongoNames } = require('./_lib');

module.exports = async (req, res) => {
  if (!guard(req, res)) return;

  let client;
  try {
    client = await mongo();
  } catch (e) {
    fail(res, 502, `mongo connection failed: ${e.message}`);
    return;
  }
  if (!client) {
    fail(res, 500, 'DATABASE_URL is not configured on this project');
    return;
  }

  const botId = String(req.query.bot_id || mongoNames.botId || '');
  if (!botId) {
    fail(res, 400, 'BOT_ID is not configured (the numeric part of your BOT_TOKEN)');
    return;
  }

  const db = client.db(mongoNames.db);
  const want = String(req.query.what || 'all');
  const limit = Math.min(Number(req.query.limit || 200), 1000);
  const payload = { bot_id: botId, database: mongoNames.db };

  try {
    if (want === 'all' || want === 'users') {
      const col = db.collection(`users.${botId}`);
      const [rows, total, sudo, auth] = await Promise.all([
        col.find({}, { projection: { _id: 1, is_sudo: 1, is_auth: 1, media_group: 1, equal_splits: 1, split_size: 1 } }).limit(limit).toArray(),
        col.estimatedDocumentCount(),
        col.countDocuments({ is_sudo: true }),
        col.countDocuments({ is_auth: true }),
      ]);
      payload.users = { total, sudo, auth, rows: rows.map((r) => ({ ...r, _id: String(r._id) })) };
    }

    if (want === 'all' || want === 'tasks') {
      const col = db.collection(`tasks.${botId}`);
      const rows = await col.find({}, { projection: { _id: 1, cid: 1, tag: 1, source: 1 } }).limit(limit).toArray();
      payload.incomplete_tasks = { total: await col.estimatedDocumentCount(), rows };
    }

    if (want === 'all' || want === 'rss') {
      const col = db.collection(`rss.${botId}`);
      const rows = await col.find({}).limit(limit).toArray();
      payload.rss = rows.map((row) => ({ user_id: String(row._id), feeds: Object.keys(row).filter((k) => k !== '_id') }));
    }

    if (want === 'all' || want === 'pm_users') {
      payload.pm_users = { total: await db.collection(`pm_users.${botId}`).estimatedDocumentCount() };
    }

    if (want === 'all' || want === 'config') {
      const [live, deployed] = await Promise.all([
        db.collection('settings.config').findOne({ _id: botId }),
        db.collection('settings.deployConfig').findOne({ _id: botId }),
      ]);
      payload.config = { live: publicConfig(live || {}), deploy_config: publicConfig(deployed || {}) };
    }

    ok(res, payload);
  } catch (e) {
    fail(res, 502, `query failed: ${e.message}`);
  }
};
