// POST /api/action  { "id": "<gid|hash>", "action": "pause|resume|cancel", "runtime": "acc1" }
// POST /api/action  { "clear": true, "runtime": "acc1" }   -> purge finished entries
const { ok, fail, guard, callUpstream, GATEWAY_URL, RUNTIME_NAME } = require('./_lib');

const ACTIONS = new Set(['pause', 'resume', 'cancel']);
const ID_RE = /^[0-9a-zA-Z]{16,40}$/;

module.exports = async (req, res) => {
  if (!guard(req, res)) return;
  if (req.method !== 'POST') {
    fail(res, 405, 'POST only');
    return;
  }
  const body = typeof req.body === 'string' ? safeJson(req.body) : req.body || {};
  const runtime = String(body.runtime || req.query.runtime || RUNTIME_NAME || '').replace(/[^A-Za-z0-9_-]/g, '');

  try {
    if (body.clear) {
      const { status, data } = await callUpstream(GATEWAY_URL ? `/${runtime}/torrents/clear` : '/api/torrents/clear', { method: 'POST', body: {} });
      return status >= 400 ? fail(res, status, data.error || `upstream returned ${status}`, { upstream: data }) : ok(res, { runtime, ...data });
    }

    const id = String(body.id || '');
    const action = String(body.action || '');
    if (!ID_RE.test(id)) {
      fail(res, 400, 'id must be a 16-40 character aria2 gid or qBittorrent hash');
      return;
    }
    if (!ACTIONS.has(action)) {
      fail(res, 400, `action must be one of ${[...ACTIONS].join(', ')}`);
      return;
    }
    const path = GATEWAY_URL ? `/${runtime}/torrents/${id}/${action}` : `/api/torrents/${id}/${action}`;
    const { status, data } = await callUpstream(path, { method: 'POST', body: {} });
    return status >= 400 ? fail(res, status, data.error || `upstream returned ${status}`, { upstream: data }) : ok(res, { runtime, id, action, ...data });
  } catch (e) {
    fail(res, 502, `action failed: ${e.message}`);
  }
};

function safeJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}
