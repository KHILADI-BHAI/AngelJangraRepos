// /app/files/<gid|hash>?pin_code=1234 -> proxied to the runtime's Flask file selector.
//
// This is what lets BASE_URL point at a stable Vercel domain (HTTPS, survives redeploys)
// while the selector itself keeps running next to the daemons. The pin code is part of the
// URL, exactly like it is upstream, so no extra auth is added here.
const { fail, send, RUNTIME_URL } = require('./_lib');

function readRaw(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

module.exports = async (req, res) => {
  if (!RUNTIME_URL) {
    fail(res, 500, 'RUNTIME_URL is not configured on this project');
    return;
  }
  const raw = req.query.path;
  const path = Array.isArray(raw) ? raw.join('/') : String(raw || '');
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(req.query)) {
    if (key === 'path') continue;
    if (Array.isArray(value)) value.forEach((v) => query.append(key, v));
    else query.append(key, value);
  }
  const target = `${RUNTIME_URL}/app/files/${path}${query.toString() ? `?${query.toString()}` : ''}`;

  try {
    const init = { method: req.method, headers: {}, redirect: 'follow' };
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      const body = await readRaw(req);
      init.body = body;
      if (req.headers['content-type']) init.headers['Content-Type'] = req.headers['content-type'];
    }
    const upstream = await fetch(target, init);
    const buffer = Buffer.from(await upstream.arrayBuffer());
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.status(upstream.status).send(buffer);
  } catch (e) {
    fail(res, 502, `file selector unreachable: ${e.message}`);
  }
};
