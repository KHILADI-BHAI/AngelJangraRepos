// GET /api/status -> aggregated status of every runtime account.
// Gateway mode (Deplexo) fans out over all accounts; direct mode reports the single runtime.
const { ok, fail, guard, callUpstream, GATEWAY_URL } = require('./_lib');

module.exports = async (req, res) => {
  if (!guard(req, res)) return;
  try {
    const { status, data } = await callUpstream(GATEWAY_URL ? '/status' : '/api/stats');
    if (status >= 400) {
      fail(res, status, data.error || `upstream returned ${status}`, { upstream: data });
      return;
    }
    ok(res, { upstream_status: status, ...data });
  } catch (e) {
    fail(res, 502, `status failed: ${e.message}`);
  }
};
