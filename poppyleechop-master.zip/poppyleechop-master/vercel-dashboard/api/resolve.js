// GET /api/resolve?component=<name>  -> the pull endpoint used by every container.
//
// Auth: X-Component-Token must match the component's own token. The response contains
// ONLY that component's allowlisted keys, so a runtime can never read the gateway's
// token and the daemons box can never learn the bot token. This is the isolation that
// lets one settings page serve four different trust levels.
const { send, fail } = require('./_lib');
const { readConfig, authenticate, recordContact, db } = require('./_store');
const schema = require('./schema.json');

module.exports = async (req, res) => {
  if (req.method !== 'GET') {
    send(res, 405, { ok: false, error: 'use GET' });
    return;
  }
  const name = String((req.query && req.query.component) || process.env.COMPONENT_ID || '');
  if (!name) {
    fail(res, 400, 'component query parameter is required');
    return;
  }
  const token = req.headers['x-component-token'] || (req.query && req.query.token) || '';
  try {
    const component = await authenticate(name, token);
    if (!component) {
      // record the failed attempt so a misconfigured container is visible in the UI
      if (name) await recordContact(name, { error: 'rejected pull: bad component token' }).catch(() => {});
      fail(res, 401, 'unknown component or bad token', { hint: 'set COMPONENT_ID and COMPONENT_TOKEN' });
      return;
    }
    const config = await readConfig();
    const allowed = schema.components[component.role] || [];
    const values = {};
    for (const key of allowed) {
      if (config.values[key] !== undefined && config.values[key] !== '') {
        values[key] = config.values[key];
      }
    }
    // the bot needs these two even though they are not "config keys"
    if (component.role === 'runtime' && process.env.DASH_RUNTIME_TOKEN) {
      values.API_TOKEN = process.env.DASH_RUNTIME_TOKEN;
    }
    if (component.role === 'gateway' && process.env.GATEWAY_BOOTSTRAP_TOKEN) {
      values.GATEWAY_TOKEN = process.env.GATEWAY_BOOTSTRAP_TOKEN;
    }
    await recordContact(name, { version: config.version });
    send(res, 200, {
      ok: true,
      component: name,
      role: component.role,
      url: component.url || '',
      config_version: config.version,
      updated_at: config.updated_at,
      values,
      keys_sent: Object.keys(values).length,
    });
  } catch (e) {
    await recordContact(name, { error: `pull failed: ${e.message}` }).catch(() => {});
    fail(res, 500, `config pull failed: ${e.message}`);
  }
};
