// GET /api/torrents?runtime=acc1 -> live aria2 + qBittorrent tasks of one runtime.
const { ok, fail, guard, callUpstream, GATEWAY_URL, RUNTIME_NAME } = require('./_lib');

module.exports = async (req, res) => {
  if (!guard(req, res)) return;
  const runtime = String(req.query.runtime || RUNTIME_NAME || '').replace(/[^A-Za-z0-9_-]/g, '');
  try {
    const path = GATEWAY_URL ? `/${runtime}/torrents` : '/api/torrents';
    const { status, data } = await callUpstream(path);
    if (status >= 400) {
      fail(res, status, data.error || `upstream returned ${status}`, { upstream: data });
      return;
    }
    ok(res, { runtime, upstream_status: status, ...data });
  } catch (e) {
    fail(res, 502, `torrents failed: ${e.message}`);
  }
};
