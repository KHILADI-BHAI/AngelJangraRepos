const { send, fail, requireAdmin } = require('./_lib');
const { listComponents, createComponent, rotateToken, setUrl, readConfig } = require('./_store');

/**
 * GET  /api/settings           -> serves the admin settings page (the /settings route).
 * GET  /api/settings?raw=1     -> JSON bootstrap: components + non-secret facts.
 * POST /api/settings           -> component lifecycle: create / rotate / set_url.
 *
 * The page is served from a function rather than as a static file so it inherits the
 * same no-store headers and function budget as the rest of the API, and so the page
 * can never drift from the API it talks to.
 */
module.exports = async (req, res) => {
  if (req.method === 'GET' && String((req.query || {}).raw || '') !== '1') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    try {
      const { readFileSync } = require('fs');
      const { join } = require('path');
      return res.status(200).send(readFileSync(join(process.cwd(), 'public', 'settings.html'), 'utf8'));
    } catch (e) {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      return res.status(500).send(JSON.stringify({ ok: false, error: `public/settings.html not found: ${e.message}` }));
    }
  }

  if (req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    try {
      const [config, components] = await Promise.all([readConfig(), listComponents()]);
      send(res, 200, {
        ok: true,
        version: config.version,
        updated_at: config.updated_at,
        components,
        // the page shows a "not configured yet" banner instead of failing opaquely
        ready: {
          database: Boolean(process.env.DATABASE_URL),
          encryption: Boolean(process.env.CONFIG_MASTER_KEY),
          admin_token: Boolean(process.env.ADMIN_TOKEN),
        },
        origin: `https://${String(req.headers.host || 'poppyleechop.vercel.app').split(':')[0]}`,
      });
    } catch (e) {
      fail(res, 500, `cannot bootstrap settings: ${e.message}`);
    }
    return;
  }

  if (req.method === 'POST') {
    if (!requireAdmin(req, res)) return;
    const body = (req.body && typeof req.body === 'object' ? req.body : {}) || {};
    const action = String(body.action || '');
    try {
      if (action === 'create') {
        const made = await createComponent(body.name, body.role, body.url);
        return send(res, 201, { ok: true, ...made, note: 'copy this token now - it is never shown again' });
      }
      if (action === 'rotate') {
        return send(res, 200, {
          ok: true,
          ...(await rotateToken(body.name)),
          note: 'the previous token stopped working immediately - update the container env',
        });
      }
      if (action === 'set_url') {
        await setUrl(body.name, body.url);
        return send(res, 200, { ok: true, name: body.name, url: String(body.url || '').replace(/\/+$/, '') });
      }
      fail(res, 400, `unknown action "${action}"`);
    } catch (e) {
      fail(res, 400, e.message);
    }
    return;
  }

  send(res, 405, { ok: false, error: 'use GET or POST' });
};
