// GET /api/health -> live health of the gateway (Deplexo) and/or the runtime (SnapDeploy).
// Requires the dashboard token: it proxies to endpoints that report internal state.
const { ok, fail, guard, callUpstream, GATEWAY_URL, RUNTIME_URL } = require('./_lib');

module.exports = async (req, res) => {
  if (!guard(req, res)) return;
  if (!GATEWAY_URL && !RUNTIME_URL) {
    fail(res, 500, 'Neither GATEWAY_URL nor RUNTIME_URL is set');
    return;
  }
  try {
    const checks = [];
    if (GATEWAY_URL) checks.push(callUpstream('/healthz').then((r) => ({ name: 'gateway', ...r })));
    if (RUNTIME_URL) checks.push(callUpstream('/api/health').then((r) => ({ name: 'runtime', ...r })));
    const results = await Promise.all(checks);
    const runtime = results.find((r) => r.name === 'runtime');
    ok(res, {
      time: new Date().toISOString(),
      checks: results.map((r) => ({
        name: r.name,
        status: r.status,
        reachable: r.status >= 200 && r.status < 400,
        detail: r.data,
      })),
      runtime: runtime ? runtime.data : null,
    });
  } catch (e) {
    fail(res, 502, `health check failed: ${e.message}`);
  }
};
