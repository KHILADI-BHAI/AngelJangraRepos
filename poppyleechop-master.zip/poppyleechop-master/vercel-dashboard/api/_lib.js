// Shared helpers for every Vercel function: auth, upstream calls and a cached Mongo client.
const { MongoClient } = require('mongodb');

const TOKEN = process.env.DASHBOARD_TOKEN || process.env.GATEWAY_TOKEN || '';
const GATEWAY_URL = (process.env.GATEWAY_URL || '').replace(/\/+$/, '');
const GATEWAY_TOKEN = process.env.GATEWAY_TOKEN || '';
const RUNTIME_URL = (process.env.RUNTIME_URL || '').replace(/\/+$/, '');
const RUNTIME_TOKEN = process.env.RUNTIME_TOKEN || '';
const RUNTIME_NAME = process.env.RUNTIME_NAME || 'acc1';
const TIMEOUT_MS = Number(process.env.UPSTREAM_TIMEOUT_MS || 25000);

function send(res, status, body) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  return res.status(status).send(JSON.stringify(body));
}

function ok(res, body) {
  return send(res, 200, { ok: true, ...body });
}

function fail(res, status, error, extra = {}) {
  return send(res, status, { ok: false, error, ...extra });
}

/** Browser -> Vercel: the dashboard sends X-API-Token (or ?token= for quick curl tests). */
function authorized(req) {
  if (!TOKEN) return false;
  const header = req.headers['x-api-token'] || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const sent = header || (req.query && req.query.token) || '';
  if (!sent || sent.length !== TOKEN.length) return false;
  // constant time compare without pulling in a dependency
  let diff = 0;
  for (let i = 0; i < TOKEN.length; i += 1) diff |= TOKEN.charCodeAt(i) ^ sent.charCodeAt(i);
  return diff === 0;
}

function guard(req, res) {
  if (authorized(req)) return true;
  fail(res, 401, 'unauthorized', { hint: 'send the X-API-Token header' });
  return false;
}

async function callUpstream(path, { method = 'GET', body } = {}) {
  const target = GATEWAY_URL
    ? { url: `${GATEWAY_URL}${path.startsWith('/api/v1') ? '' : '/api/v1'}${path}`, token: GATEWAY_TOKEN }
    : { url: `${RUNTIME_URL}${path}`, token: RUNTIME_TOKEN };
  if (!target.url) throw new Error('Neither GATEWAY_URL nor RUNTIME_URL is configured');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(target.url, {
      method,
      headers: { 'X-API-Token': target.token, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = { raw: text.slice(0, 500) };
    }
    return { status: res.status, data };
  } finally {
    clearTimeout(timer);
  }
}

/** Runtime path builder: gateway mode names the runtime, direct mode does not. */
function runtimePath(runtime, suffix) {
  return GATEWAY_URL ? `/${runtime || RUNTIME_NAME}/${suffix}` : `/api/${suffix}`;
}

/**
 * Admin write authority, separate from the read token on purpose: a leaked dashboard
 * token must not let anyone rewrite BOT_TOKEN or DATABASE_URL. Sent as X-Admin-Token.
 */
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';

function adminAuthorized(req) {
  if (!ADMIN_TOKEN) return false;
  const header = req.headers['x-admin-token'] || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const sent = header || (req.query && req.query.token) || '';
  if (!sent || sent.length !== ADMIN_TOKEN.length) return false;
  let diff = 0;
  for (let i = 0; i < ADMIN_TOKEN.length; i += 1) diff |= ADMIN_TOKEN.charCodeAt(i) ^ sent.charCodeAt(i);
  return diff === 0;
}

function requireAdmin(req, res) {
  if (adminAuthorized(req)) return true;
  fail(res, 401, 'admin token required', { hint: 'send the X-Admin-Token header' });
  return false;
}

let clientPromise;
function mongo() {
  if (!process.env.DATABASE_URL) return null;
  if (!clientPromise) {
    const client = new MongoClient(process.env.DATABASE_URL, { serverSelectionTimeoutMS: 8000, maxPoolSize: 4 });
    clientPromise = client.connect();
  }
  return clientPromise;
}

/** Never leak credentials to the dashboard. */
const SECRET_KEY = /(TOKEN|HASH|PASSWORD|PASSWD|SECRET|SESSION|DATABASE_URL|COOKIES|API_KEY|PRIVATE|TELEGRAM|SA_|_ID$)/i;
function publicConfig(config = {}) {
  const out = {};
  for (const [key, value] of Object.entries(config)) {
    if (key === '_id' || SECRET_KEY.test(key)) continue;
    if (typeof value === 'string' && value.length > 400) continue;
    out[key] = value;
  }
  return out;
}

module.exports = {
  GATEWAY_URL,
  RUNTIME_URL,
  RUNTIME_NAME,
  TIMEOUT_MS,
  ADMIN_TOKEN,
  send,
  ok,
  fail,
  guard,
  adminAuthorized,
  requireAdmin,
  callUpstream,
  runtimePath,
  mongo,
  publicConfig,
  mongoNames: { db: process.env.MONGO_DB || 'wzmlx', botId: process.env.BOT_ID || '' },
};
