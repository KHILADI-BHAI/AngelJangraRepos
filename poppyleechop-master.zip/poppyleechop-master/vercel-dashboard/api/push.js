// POST /api/push -> the bot's two-way write-back, so a Telegram /settings edit shows
// up on the dashboard without anyone copying anything.
//
// Authenticated with the bot's own COMPONENT_TOKEN, not the admin token: the bot must be
// able to sync without holding admin rights, and it may only write keys inside its own
// role allowlist. Keys outside that allowlist are reported back as "rejected" rather
// than silently dropped.
//
// Called from DbManger.update_config() only. It is deliberately NOT called from
// db_load(): that runs on every boot and writes the bot's whole in-memory config, so
// syncing it would let each restart overwrite whatever was just saved on the dashboard.
const { send, fail } = require('./_lib');
const { readConfig, writeConfig, authenticate, recordContact } = require('./_store');
const schema = require('./schema.json');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    send(res, 405, { ok: false, error: 'use POST' });
    return;
  }
  const name = String((req.body && req.body.component) || process.env.COMPONENT_ID || '');
  const token = req.headers['x-component-token'] || '';
  let component;
  try {
    component = await authenticate(name, token);
  } catch (e) {
    fail(res, 500, `authentication failed: ${e.message}`);
    return;
  }
  if (!component) {
    fail(res, 401, 'unknown component or bad token');
    return;
  }

  let values = (req.body && req.body.values) || {};
  if (typeof values === 'string') {
    try {
      values = JSON.parse(values);
    } catch (e) {
      fail(res, 400, 'values must be a JSON object');
      return;
    }
  }
  if (!values || typeof values !== 'object' || Array.isArray(values)) {
    fail(res, 400, 'send {"values": {"KEY": "value"}}');
    return;
  }

  const allowed = new Set(schema.components[component.role] || []);
  const patch = {};
  const rejected = [];
  for (const [key, value] of Object.entries(values)) {
    if (!schema.keys[key] || !allowed.has(key)) {
      rejected.push(key);
      continue;
    }
    // Python str() of a bool is 'True'/'False', which is exactly what the bot writes
    // into settings.config and what bot/__init__.py feeds back through environ, so
    // matching it keeps the dashboard and the bot byte-identical.
    if (value === null || value === undefined) {
      patch[key] = '';
    } else if (typeof value === 'boolean') {
      patch[key] = value ? 'True' : 'False';
    } else {
      patch[key] = String(value);
    }
  }

  try {
    if (!Object.keys(patch).length) {
      await recordContact(name, {});
      send(res, 200, { ok: true, changed: 0, rejected, version: (await readConfig()).version });
      return;
    }
    const result = await writeConfig(patch, 'telegram');
    await recordContact(name, { version: result.version });
    send(res, 200, { ok: true, ...result, rejected, changed: Object.keys(patch).length });
  } catch (e) {
    fail(res, 500, `push failed: ${e.message}`);
  }
};
