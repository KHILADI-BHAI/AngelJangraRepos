// GET /api/report -> component status: last seen, config version, last pull error.
// This is what drives the "Components & credentials" table and the pending-restart badge.
const { send, fail, requireAdmin } = require('./_lib');
const { listComponents, recordContact, readConfig, ROLES } = require('./_store');

module.exports = async (req, res) => {
  if (req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    try {
      const [components, config] = await Promise.all([listComponents(), readConfig()]);
      const now = Date.now();
      send(res, 200, {
        ok: true,
        version: config.version,
        updated_at: config.updated_at,
        roles: ROLES,
        components: components.map((c) => {
          const ageMin = c.last_seen ? Math.round((now - Date.parse(c.last_seen)) / 60000) : null;
          return {
            ...c,
            age_minutes: ageMin,
            // the single number that proves a component is running the newest settings
            up_to_date: c.config_version === config.version && config.version > 0,
            state: !c.last_seen
              ? 'never checked in'
              : c.last_error
                ? 'error'
                : c.config_version !== config.version
                  ? 'stale'
                  : ageMin !== null && ageMin > 30
                    ? 'idle'
                    : 'ok',
          };
        }),
      });
    } catch (e) {
      fail(res, 500, `cannot read component status: ${e.message}`);
    }
    return;
  }

  if (req.method === 'POST') {
    // A container that cannot reach /api/resolve can still report why, so the UI is
    // not blind when a component is misconfigured.
    if (!requireAdmin(req, res)) return;
    const body = (req.body && typeof req.body === 'object' ? req.body : {}) || {};
    if (!body.name) {
      fail(res, 400, 'name is required');
      return;
    }
    try {
      await recordContact(body.name, { error: String(body.error || 'unknown error').slice(0, 300) });
      send(res, 200, { ok: true, recorded: true });
    } catch (e) {
      fail(res, 500, e.message);
    }
    return;
  }

  send(res, 405, { ok: false, error: 'use GET or POST' });
};
