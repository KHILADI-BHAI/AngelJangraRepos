// Central settings store for the WZML-X control plane.
//
// Everything the user types on /settings lands here, so this module is deliberately
// paranoid:
//
//   * values are encrypted at rest with AES-256-GCM, keyed from CONFIG_MASTER_KEY
//   * component tokens are stored as scrypt hashes - a Mongo dump yields nothing usable
//   * nothing in this file ever returns a secret to a browser
//
// The only Vercel-side bootstrap values are DATABASE_URL, ADMIN_TOKEN and
// CONFIG_MASTER_KEY. Everything else is entered once on the settings page.
const { MongoClient } = require('mongodb');
const { createCipheriv, createDecipheriv, randomBytes, scryptSync, timingSafeEqual } = require('crypto');

const DB = process.env.MONGO_DB || 'wzmlx';
const COL = 'controlplane';
const KDF = 'wzmlx-controlplane-v1';

let clientPromise;
function mongo() {
  if (!process.env.DATABASE_URL) return null;
  if (!clientPromise) {
    const client = new MongoClient(process.env.DATABASE_URL, { serverSelectionTimeoutMS: 8000, maxPoolSize: 4 });
    clientPromise = client.connect();
  }
  return clientPromise;
}

async function db() {
  if (collectionOverride) return collectionOverride;
  return mongo().then((c) => c.db(DB).collection(COL));
}

/**
 * Test seam: swap the collection for an in-memory double. Only the test harness calls
 * this, and it keeps the production path identical (same encryption, same hashing,
 * same merge semantics) without needing a live Atlas cluster.
 */
let collectionOverride = null;
function __overrideCollection(fake) {
  collectionOverride = fake;
}

// --- encryption ------------------------------------------------------------
function masterKey() {
  const secret = process.env.CONFIG_MASTER_KEY || '';
  if (secret.length < 16) throw new Error('CONFIG_MASTER_KEY is missing or too short (min 16 chars)');
  return scryptSync(secret, KDF, 32);
}

function encryptValue(plain) {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', masterKey(), iv);
  const data = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return `v1.${iv.toString('base64')}.${cipher.getAuthTag().toString('base64')}.${data.toString('base64')}`;
}

function decryptValue(blob) {
  const [version, ivB64, tagB64, dataB64] = String(blob).split('.');
  if (version !== 'v1') throw new Error('unsupported ciphertext version');
  const decipher = createDecipheriv('aes-256-gcm', masterKey(), Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

// --- token hashing ---------------------------------------------------------
function hashToken(name, token) {
  return scryptSync(String(token), `${KDF}:${name}`, 32).toString('hex');
}

function tokenMatches(name, token, expectedHash) {
  if (!token || !expectedHash) return false;
  const got = Buffer.from(hashToken(name, token), 'hex');
  const want = Buffer.from(expectedHash, 'hex');
  return got.length === want.length && timingSafeEqual(got, want);
}



// --- config document -------------------------------------------------------
// Shape: { _id: 'config', version, values: {KEY: ciphertext}, meta: {KEY: {source, at}} }
async function readConfig() {
  const doc = await (await db()).findOne({ _id: 'config' });
  const values = {};
  for (const [key, blob] of Object.entries((doc && doc.values) || {})) {
    try {
      values[key] = decryptValue(blob);
    } catch (e) {
      values[key] = ''; // one unreadable value must not break the whole page
    }
  }
  return {
    values,
    version: (doc && doc.version) || 0,
    meta: (doc && doc.meta) || {},
    updated_at: (doc && doc.updated_at) || null,
  };
}

/**
 * Merge a patch into the stored config and bump the version.
 * `patch` maps KEY -> plaintext value, or KEY -> null to clear the key.
 * Each key records who changed it - that is what the settings page displays.
 */
async function writeConfig(patch, source = 'vercel') {
  const current = await readConfig();
  const values = { ...current.values };
  const meta = { ...current.meta };
  const at = new Date().toISOString();
  for (const [key, value] of Object.entries(patch || {})) {
    if (value === null) {
      delete values[key];
    } else {
      values[key] = String(value);
    }
    meta[key] = { source, at };
  }
  const version = current.version + 1;
  await (await db()).updateOne(
    { _id: 'config' },
    {
      $set: {
        version,
        values: Object.fromEntries(Object.entries(values).map(([k, v]) => [k, encryptValue(v)])),
        meta,
        updated_at: at,
      },
    },
    { upsert: true },
  );
  return { version, updated_at: at, count: Object.keys(patch || {}).length };
}

// --- component registry ----------------------------------------------------
// Shape: { _id: 'component:<name>', name, role, url, token_hash, created_at,
//          last_seen, last_error, config_version }
const ROLES = ['runtime', 'gateway', 'daemons'];

function newToken() {
  return randomBytes(32).toString('hex');
}

function cleanUrl(url) {
  return String(url || '').replace(/\/+$/, '');
}

async function listComponents() {
  const cursor = await (await db()).find({ _id: /^component:/ });
  const rows = await cursor.toArray();
  return rows
    .map((r) => {
      const { _id, token_hash, ...rest } = r;
      return { ...rest, has_token: Boolean(token_hash) };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
}

async function getComponent(name) {
  return (await db()).findOne({ _id: `component:${name}` });
}

async function createComponent(name, role, url) {
  if (!/^[a-z0-9][a-z0-9_-]{0,30}$/i.test(String(name || ''))) {
    throw new Error('component name must be letters, digits, dash or underscore (max 31)');
  }
  if (!ROLES.includes(role)) throw new Error(`role must be one of ${ROLES.join(', ')}`);
  if (await getComponent(name)) throw new Error(`component ${name} already exists`);
  const token = newToken();
  await (await db()).insertOne({
    _id: `component:${name}`,
    name,
    role,
    url: String(url || '').replace(/\/+$/, ''),
    token_hash: hashToken(name, token),
    created_at: new Date().toISOString(),
    last_seen: null,
    last_error: null,
    config_version: 0,
  });
  return { name, role, url: cleanUrl(url), token }; // the only time the token is ever visible
}

async function rotateToken(name) {
  const existing = await getComponent(name);
  if (!existing) throw new Error(`unknown component ${name}`);
  const token = newToken();
  await (await db()).updateOne(
    { _id: `component:${name}` },
    { $set: { token_hash: hashToken(name, token), rotated_at: new Date().toISOString() } },
  );
  return { name, token };
}

async function setUrl(name, url) {
  await (await db()).updateOne(
    { _id: `component:${name}` },
    { $set: { url: String(url || '').replace(/\/+$/, '') } },
  );
}

async function authenticate(name, token) {
  const component = await getComponent(name);
  if (!component || !tokenMatches(name, token, component.token_hash)) return null;
  return component;
}

/** Called on every pull or failed pull - this is what the status column reads. */
async function recordContact(name, { version, error } = {}) {
  const update = { last_seen: new Date().toISOString(), last_error: error || null };
  if (typeof version === 'number') update.config_version = version;
  await (await db()).updateOne({ _id: `component:${name}` }, { $set: update });
}

module.exports = {
  mongo,
  db,
  __overrideCollection,
  encryptValue,
  decryptValue,
  hashToken,
  tokenMatches,
  readConfig,
  writeConfig,
  listComponents,
  getComponent,
  createComponent,
  rotateToken,
  setUrl,
  authenticate,
  recordContact,
  ROLES,
};
