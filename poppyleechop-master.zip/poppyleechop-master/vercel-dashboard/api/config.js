// GET  /api/config  -> the settings page view: keys, masks, provenance, version.
// POST /api/config  -> save values. Authenticated with ADMIN_TOKEN (write authority).
//
// GET deliberately never returns a secret. A secret key comes back as {configured, mask}
// so the page can render "set / not set" without ever holding the plaintext.
//
// POST accepts the literal "__KEEP__" to leave a secret untouched, so saving one
// ordinary field can never blank the credentials next to it.
const { send, fail, requireAdmin, publicConfig } = require('./_lib');
const { readConfig, writeConfig, mongo } = require('./_store');
const schema = require('./schema.json');

const KEEP = '__KEEP__';

function mask(value) {
  if (!value) return null;
  return `${'•'.repeat(8)}${value.slice(-4)}`;
}



/** Best-effort live values from the bot, so the page can show drift per key. */
async function botValues() {
  const botId = process.env.BOT_ID || '';
  if (!botId) return {};
  try {
    const client = await mongo();
    if (!client) return {};
    const db = client.db(process.env.MONGO_DB || 'wzmlx');
    const live = await db.collection('settings.config').findOne({ _id: botId });
    return live || {};
  } catch (e) {
    return {};
  }
}

module.exports = async (req, res) => {
  if (req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    let config;
    try {
      config = await readConfig();
    } catch (e) {
      fail(res, 500, `cannot read config: ${e.message}`);
      return;
    }
    const bot = await botValues();
    const botKnown = Object.keys(bot).length > 0;
    const keys = {};
    for (const [key, info] of Object.entries(schema.keys)) {
      const value = config.values[key];
      const botValue = bot[key];
      const base = {
        type: info.type,
        scope: info.scope,
        group: info.group,
        // The page branches on this to render a password box + mask instead of a
        // plain value. It has to be sent explicitly: without it the browser treats
        // every key as plain, so a saved secret renders as "not set / unknown".
        secret: info.secret,
        changed_by: (config.meta[key] || {}).source || null,
        changed_at: (config.meta[key] || {}).at || null,
      };
      if (info.secret) {
        // never the plaintext - the page can only see that it is set
        keys[key] = { ...base, configured: Boolean(value), mask: mask(value) };
      } else {
        keys[key] = {
          ...base,
          value: value === undefined ? '' : value,
          default: (schema.defaults || {})[key] || '',
          // With no live bot there is nothing to compare against, so say "unknown"
          // rather than inventing a difference.
          drift: !botKnown
            ? 'unknown'
            : value === undefined || value === ''
              ? botValue === undefined
                ? 'not set'
                : 'differs'
              : String(botValue === undefined || botValue === null ? '' : botValue) === String(value)
                ? 'matches'
                : 'differs',
        };
      }
    }
    send(res, 200, {
      ok: true,
      version: config.version,
      updated_at: config.updated_at,
      keys,
      bot_config: publicConfig(bot),
      bot_reachable: botKnown,
    });
    return;
  }

  if (req.method === 'POST') {
    if (!requireAdmin(req, res)) return;
    let patch = req.body && req.body.values;
    if (typeof patch === 'string') {
      try {
        patch = JSON.parse(patch);
      } catch (e) {
        fail(res, 400, 'values must be a JSON object');
        return;
      }
    }
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
      fail(res, 400, 'send {"values": {"KEY": "value", "OTHER": "__KEEP__", "OLD": null}}');
      return;
    }
    const unknown = Object.keys(patch).filter((k) => !schema.keys[k]);
    if (unknown.length) {
      fail(res, 400, `unknown config key(s): ${unknown.slice(0, 8).join(', ')}`, { unknown });
      return;
    }
    const cleaned = {};
    for (const [key, value] of Object.entries(patch)) {
      if (value === KEEP) continue; // leave the stored secret exactly as it is
      if (value === null) {
        cleaned[key] = null; // explicit clear
        continue;
      }
      if (schema.keys[key].secret && String(value).length < 6) {
        fail(res, 400, `${key} looks too short to be a real credential`);
        return;
      }
      cleaned[key] = value;
    }
    try {
      if (!Object.keys(cleaned).length) {
        send(res, 200, { ok: true, version: (await readConfig()).version, changed: 0 });
        return;
      }
      send(res, 200, { ok: true, ...(await writeConfig(cleaned, 'vercel')) });
    } catch (e) {
      fail(res, 500, `save failed: ${e.message}`);
    }
    return;
  }

  send(res, 405, { ok: false, error: 'use GET or POST' });
};
