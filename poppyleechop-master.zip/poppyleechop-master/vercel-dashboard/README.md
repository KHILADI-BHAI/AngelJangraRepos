# Deploy this package: WZML-X admin dashboard + API facade (Vercel)

Static dashboard in `public/`, serverless API in `api/`, routing in `vercel.json`.
No build step, no framework - imports to Vercel as-is.

## Deploy

```bash
npm i -g vercel      # once
cd <this folder>
vercel               # preview
vercel --prod        # production
```

Or push the folder to GitHub and "Import Project" in Vercel. `vercel.json` sets the
region (`bom1`), disables caching for `/api/*`, maps `/app/files/*` to the proxy function
and schedules the daily keep-alive cron.

## Environment variables (Project Settings -> Environment Variables)

| Variable | Purpose |
| --- | --- |
| `GATEWAY_URL` | control-plane gateway URL (Deplexo/SnapDeploy acc2) - preferred |
| `GATEWAY_TOKEN` | matches `GATEWAY_TOKEN` on the gateway |
| `RUNTIME_URL` | fallback: talk to one runtime directly (SnapDeploy) |
| `RUNTIME_TOKEN` | that runtime's `API_TOKEN` |
| `RUNTIME_NAME` | label used while a runtime is selected |
| `DASHBOARD_TOKEN` | what the browser sends as `X-API-Token` (defaults to `GATEWAY_TOKEN`) |
| `DATABASE_URL` | Atlas read-only views: users, incomplete tasks, rss, config |
| `BOT_ID` | numeric part of your `BOT_TOKEN`, selects `users.<id>` etc. |
| `CRON_SECRET` | optional; locks `/api/ping` to Vercel's cron requests |

## Routes

| Path | What it does |
| --- | --- |
| `/` | dashboard (health, runtimes, live tasks with pause/resume/cancel, Atlas views) |
| `/api/status` | aggregated status of every runtime |
| `/api/torrents?runtime=acc1` | live aria2 + qBittorrent task list |
| `/api/action` | `{id, action, runtime}` or `{clear: true, runtime}` (POST) |
| `/api/users?what=users\|tasks\|rss\|config` | read-only Mongo views, secrets stripped |
| `/api/health` | gateway + runtime health in one response |
| `/api/ping` | keep-alive for free containers (see below) |
| `/app/files/<id>` | proxies the torrent file selector to `RUNTIME_URL` |

Everything except `/api/ping` with `CRON_SECRET` needs `X-API-Token`.

## Keeping free containers awake

Vercel Hobby only allows low-frequency crons, so `vercel.json` schedules `/api/ping` once a
day. A Telegram bot receives no HTTP traffic, so a SnapDeploy Free container idles out after
~15 minutes. Point a free 5-minute monitor (cron-job.org, UptimeRobot) at:

```
https://<your-project>.vercel.app/api/ping?token=<DASHBOARD_TOKEN>
```

...which probes both the gateway and the runtime and resets their idle timers. Do not do
this on the free tier of a platform whose terms forbid it - otherwise pay for Always-On.

## Security notes

- The browser only ever holds `DASHBOARD_TOKEN`; runtime API tokens stay in the gateway.
- `publicConfig()` strips `TOKEN|HASH|PASSWORD|SECRET|SESSION|DATABASE_URL|TELEGRAM|API_KEY`
  keys before any config is returned.
- Add Vercel's password protection (or keep `DASHBOARD_TOKEN` strong) before sharing the URL.
