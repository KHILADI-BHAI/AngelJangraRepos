#!/usr/bin/env python3
"""Fail if a variable the code reads is missing from deploy/paas/config.schema.json.

The settings page only offers keys present in the schema, and the schema is
generated from config.env. A key read via os.environ but never written in
config.env (RESTART_API was one) is therefore invisible on the page and the user
is told to set something that has no field.

This walks the real source and reports any such gap, so it is caught at build
time rather than by a user staring at a missing input.

    python deploy/check_schema_complete.py
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = ROOT / 'deploy' / 'paas' / 'config.schema.json'
SKIP_DIRS = {'.venv', '.tools', 'node_modules', '.git', 'qBittorrent', 'dist',
             'downloads', '__pycache__', 'ready-to-deploy', 'build', 'out'}

PY = re.compile(r"""(?:environ\.get|os\.environ\.get|getenv)\(\s*['"]([A-Z][A-Z0-9_]{2,})['"]""")
JS = re.compile(r"""process\.env\.([A-Z][A-Z0-9_]{2,})""")

# Read by the app, but intentionally not container configuration. These are either
# set on the Vercel project, injected by the platform, or test scaffolding.
ALLOWED = {
    # Vercel project bootstrap
    'ADMIN_TOKEN', 'CONFIG_MASTER_KEY', 'CRON_SECRET', 'DASHBOARD_TOKEN',
    'GATEWAY_URL', 'GATEWAY_TOKEN', 'RUNTIME_URL', 'RUNTIME_TOKEN', 'RUNTIME_NAME',
    'BOT_ID', 'MONGO_DB', 'UPSTREAM_TIMEOUT_MS', 'DASH_RUNTIME_TOKEN',
    'GATEWAY_BOOTSTRAP_TOKEN', 'GITHUB_TOKEN', 'VERCEL', 'VERCEL_ENV', 'VERCEL_GIT',
    'NODE_ENV',
    # platform-injected
    'PORT', 'HOSTNAME', 'HOME', 'PATH', 'USER', 'TMP', 'TEMP', 'LANG', 'SHELL',
    'PYTHONPATH', 'PYTHONHOME', 'PYTHONUNBUFFERED', 'SYSTEMROOT', 'WINDIR',
    'APPDATA', 'LOCALAPPDATA', 'PROGRAMFILES', 'COMSPEC', 'NUMBER_OF_PROCESSORS',
    'PROCESSOR_ARCHITECTURE', 'DISPLAY', 'XDG_CACHE_HOME', 'HOME_DIR',
    # our own control knobs, not user configuration
    'COMPONENT_ID', 'COMPONENT_TOKEN', 'CONFIG_ORIGIN', 'CONFIG_SOURCE',
    'CONFIG_PULL_TIMEOUT', 'CONFIG_KEYS_FILE', 'CONFIG_OUTPUT', 'CONFIG_PUSH_TIMEOUT',
    'SYNC_CONFIG_ENV', 'RELEASE_VERSION', 'IS_WINDOWS',
    # test scaffolding
    'TEST_PORT', 'TEST_GATEWAY_PORT', 'TEST_RUNTIME_PORT', 'TEST_TIMEOUT',
    'QBIT_WEBUI_ADDRESS', 'WEB_HOST',
}


def scan():
    found = {}
    for pattern in ('*.py', '*.js'):
        for path in ROOT.rglob(pattern):
            if any(part in SKIP_DIRS for part in path.parts):
                continue
            try:
                body = path.read_text(encoding='utf-8', errors='ignore')
            except OSError:
                continue
            regex = PY if path.suffix == '.py' else JS
            for name in regex.findall(body):
                found.setdefault(name, path.relative_to(ROOT).as_posix())
    return found


def main():
    if not SCHEMA.exists():
        print(f'{SCHEMA} is missing - run deploy/build_config_schema.py first')
        return 1
    schema = json.loads(SCHEMA.read_text(encoding='utf-8'))
    known = set(schema['keys'])
    found = scan()
    missing = {k: v for k, v in found.items() if k not in known and k not in ALLOWED}

    print(f'scanned the tree; {len(found)} variable(s) read by the code, '
          f'{len(known)} key(s) in the schema')
    if not missing:
        print('OK: every configuration variable the code reads is settable on the page.')
        return 0
    print('\nMISSING FROM THE SCHEMA (read by the code, no field on the settings page):')
    for name, where in sorted(missing.items()):
        print(f'  {name:<24} read in {where}')
    print('\nEither add it to EXTRA_KEYS in deploy/build_config_schema.py, or list it in')
    print('ALLOWED in deploy/check_schema_complete.py if it is not user configuration.')
    return 1


if __name__ == '__main__':
    sys.exit(main())
