#!/usr/bin/env python3
"""
Set the qBittorrent WebUI credentials used by a split deployment.

The bot talks to the WebUI of a *remote* qBittorrent part over the network, and
qBittorrent only skips authentication for requests coming from localhost
(WebUI\\LocalHostAuth=false). Remote requests therefore need a username and a
PBKDF2 password hash, which is what this script writes into the [Preferences]
section of a qBittorrent.conf / qBittorrent.ini file.

Usage:
  python3 set_qbittorrent_auth.py [--conf FILE] [--username U] [--password P]
                                 [--address 0.0.0.0] [--port 8090]
Defaults: qBittorrent/config/qBittorrent.conf, admin / adminadmin, address * port 8090.
"""
import argparse
import base64
import hashlib
import os
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--conf', default='qBittorrent/config/qBittorrent.conf')
parser.add_argument('--username', default=os.environ.get('QBIT_USERNAME', 'admin'))
parser.add_argument('--password', default=os.environ.get('QBIT_PASSWORD', 'adminadmin'))
parser.add_argument('--address', default=os.environ.get('QBIT_WEBUI_ADDRESS', '*'))
parser.add_argument('--port', default=os.environ.get('QBIT_PORT', '8090'))
args = parser.parse_args()

salt = os.urandom(16)
derived_key = hashlib.pbkdf2_hmac('sha512', args.password.encode(), salt, 100000, 64)
password_hash = '"@ByteArray({}:{}:{})"'.format(
    base64.b64encode(salt).decode(), 100000, base64.b64encode(derived_key).decode())

settings = {
    'WebUI\\Enabled': 'true',
    'WebUI\\Address': args.address,
    'WebUI\\Port': args.port,
    'WebUI\\LocalHostAuth': 'false',
    'WebUI\\UseUPnP': 'false',
    'WebUI\\CSRFProtection': 'false',
    'WebUI\\HostHeaderValidation': 'false',
    'WebUI\\HTTPS\\Enabled': 'false',
    'WebUI\\Username': args.username,
    'WebUI\\Password_PBKDF2': password_hash,
}

conf = args.conf
if not os.path.exists(conf):
    print(f'[i] {conf} does not exist yet, creating it')
    dirname = os.path.dirname(conf)
    if dirname:
        os.makedirs(dirname, exist_ok=True)
    with open(conf, 'w', encoding='utf-8') as f:
        f.write('[LegalNotice]\nAccepted=true\n\n[Preferences]\n')

with open(conf, encoding='utf-8') as f:
    lines = f.read().splitlines()

# drop WebUI keys of an earlier run, they may have landed in the wrong section
lines = [line for line in lines if not line.startswith('WebUI\\')]

if '[Preferences]' in lines:
    insert_at = lines.index('[Preferences]') + 1
else:
    lines.append('[Preferences]')
    insert_at = len(lines)

for key, value in reversed(list(settings.items())):
    lines.insert(insert_at, f'{key}={value}')

with open(conf, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines) + '\n')

if args.password == 'adminadmin':
    print('[!] still using the default password, change it with --password / QBIT_PASSWORD')

print(f'WebUI settings written into [Preferences] of {conf}')
print(f'WebUI login: {args.username} / {args.password}  ->  http://<host>:{args.port}')
print(f'Set the same values for the bot: QBIT_USERNAME={args.username} QBIT_PASSWORD=... (see .env.split.example)')
sys.exit(0)
