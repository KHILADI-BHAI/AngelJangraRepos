#!/usr/bin/env python3
"""End-to-end test of deploy/paas/config_pull.py against a real local HTTP server.

The server answers /api/resolve exactly like the Vercel function does, so this
exercises the genuine HTTP path, the real token rejection and the real config.env
writer - not a stub of any of them.

    python deploy/test_config_pull.py
"""

import json
import os
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PULL = ROOT / 'deploy' / 'paas' / 'config_pull.py'
KEYS = ROOT / 'deploy' / 'paas' / 'config.keys'

PASSED = 0
FAILED = 0


def check(name, condition, detail=''):
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f'  PASS  {name}')


def main():
    workdir = Path(tempfile.mkdtemp(prefix='wzmlx-pull-'))
    print(f'\nworkdir: {workdir}\n')
    state = {
        'token': 'a' * 64,
        'version': 7,
        'fail': False,
        'values': {
            'BOT_TOKEN': '123456:AAF-test',
            'STATUS_LIMIT': '10',
            'SAVE_MSG': 'False',
            'ARIA2_HOST': 'daemons.internal',
            'NOT_IN_ALLOWLIST': 'must be dropped',
        },
    }

    class Resolve(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, status, payload):
            body = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if not self.path.startswith('/api/resolve'):
                return self.reply(404, {'ok': False, 'error': 'not found'})
            if state['fail']:
                return self.reply(500, {'ok': False, 'error': 'control plane is down'})
            if self.headers.get('X-Component-Token', '') != state['token']:
                return self.reply(401, {'ok': False, 'error': 'unknown component or bad token'})
            self.reply(200, {
                'ok': True, 'component': 'acc1', 'role': 'runtime',
                'config_version': state['version'], 'values': state['values'],
            })

    server = HTTPServer(('127.0.0.1', 0), Resolve)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    origin = f'http://127.0.0.1:{server.server_address[1]}'
    target = workdir / 'config.env'

    def run_pull(env_extra, args=()):
        env = dict(os.environ)
        env.update({
            'CONFIG_ORIGIN': origin,
            'CONFIG_KEYS_FILE': str(KEYS),
            'CONFIG_OUTPUT': str(target),
        })
        env.pop('COMPONENT_ID', None)
        env.pop('COMPONENT_TOKEN', None)
        env.update(env_extra)
        return subprocess.run([sys.executable, str(PULL), *args], capture_output=True,
                              text=True, env=env, cwd=str(workdir))

    good = {'COMPONENT_ID': 'acc1', 'COMPONENT_TOKEN': state['token']}

    print('missing identity')
    result = run_pull({})
    check('exits 2 without COMPONENT_ID/COMPONENT_TOKEN', result.returncode == 2, result.returncode)
    check('points the user at the settings page', 'settings' in result.stdout, result.stdout[:160])
    check('writes nothing', not target.exists())

    print('\nrejected token')
    result = run_pull({'COMPONENT_ID': 'acc1', 'COMPONENT_TOKEN': 'wrong'})
    check('a bad token exits 1 and writes nothing', result.returncode == 1, result.returncode)
    check('mentions rotating the token', 'rotate' in result.stdout.lower(), result.stdout[:200])
    check('still nothing on disk', not target.exists())

    print('\ncontrol plane broken, no cache yet')
    state['fail'] = True
    result = run_pull(good)
    check('server error exits 1', result.returncode == 1, result.returncode)
    check('refuses to start half-configured', 'half-configured' in result.stdout, result.stdout[:200])
    check('still nothing on disk', not target.exists())
    state['fail'] = False

    print('\nsuccessful pull')
    result = run_pull(good)
    check('exits 0', result.returncode == 0, result.stdout + result.stderr)
    check('config.env created', target.exists())
    body = target.read_text(encoding='utf-8') if target.exists() else ''
    check('bot token written', 'BOT_TOKEN = "123456:AAF-test"' in body, body[:200])
    check('numeric value written', 'STATUS_LIMIT = "10"' in body)
    check('bool round-trips as False', 'SAVE_MSG = "False"' in body)
    check('key outside config.keys is dropped', 'NOT_IN_ALLOWLIST' not in body)
    check('no temp file left behind', not list(workdir.glob('.config.env.*')))
    check('config version marker written', (workdir / '.config_version').read_text() == '7')

    print('\nquotes and backslashes survive the round-trip')
    state['values'] = {'AUTHOR_NAME': 'Leech "King" \\ Ops', 'RCLONE_PATH': 'C:\\rclone\\remote:path'}
    run_pull(good)
    body = target.read_text(encoding='utf-8')
    check('double quotes are escaped', '\\"King\\"' in body, body[:300])
    check('backslashes are escaped', 'C:\\\\rclone' in body, body[:300])
    from dotenv import dotenv_values
    parsed = dict(dotenv_values(target))
    check('python-dotenv reads back the exact quoted value',
          parsed.get('AUTHOR_NAME') == 'Leech "King" \\ Ops', repr(parsed.get('AUTHOR_NAME')))
    check('a windows-style path round-trips',
          parsed.get('RCLONE_PATH') == 'C:\\rclone\\remote:path', repr(parsed.get('RCLONE_PATH')))
    state['values'] = {
        'BOT_TOKEN': '123456:AAF-test', 'STATUS_LIMIT': '10', 'SAVE_MSG': 'False',
        'ARIA2_HOST': 'daemons.internal', 'NOT_IN_ALLOWLIST': 'must be dropped',
    }
    run_pull(good)

    print('\ncontrol plane down but a cache exists')
    state['fail'] = True
    result = run_pull(good)
    check('exits 0 using the cached file', result.returncode == 0, result.returncode)
    check('says it kept the last known config', 'last known config' in result.stdout, result.stdout[:200])
    check('previous values untouched', 'STATUS_LIMIT = "10"' in target.read_text(encoding='utf-8'))
    state['fail'] = False

    print('\n--check mode')
    check('exits 0 when reachable', run_pull(good, ('--check',)).returncode == 0)
    state['fail'] = True
    check('exits 1 when not reachable', run_pull(good, ('--check',)).returncode == 1)
    state['fail'] = False

    print('\n--print mode')
    result = run_pull(good, ('--print',))
    check('exits 0', result.returncode == 0)
    check('prints KEY=value pairs', 'STATUS_LIMIT=10' in result.stdout, result.stdout[:200])
    check('does not overwrite config.env', 'STATUS_LIMIT = "10"' in target.read_text(encoding='utf-8'))

    print('\nno secret ever reaches the logs')
    result = run_pull(good)
    combined = result.stdout + result.stderr
    check('the bot token is never printed', 'AAF-test' not in combined)
    check('the component token is never printed', state['token'] not in combined)

    server.shutdown()
    print(f'\n{PASSED} passed, {FAILED} failed\n')
    return 1 if FAILED else 0


if __name__ == '__main__':
    sys.exit(main())

    check('config version marker written', (workdir / '.config_version').read_text() == '7')
