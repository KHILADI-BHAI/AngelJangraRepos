#!/usr/bin/env python3
"""Generate deploy/paas/config.schema.json - the single description of every config key.

Run:  python deploy/build_config_schema.py

The Vercel settings page, the container-side puller and the packaging tests all read
this file, so a key is never described (or classified) in two places. Keys are taken
from config.env + config_sample.env, exactly like deploy/paas/config.keys, and each
one is classified as secret/plain, given a type and an owning component.
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'deploy' / 'paas' / 'config.schema.json'

# A key whose name hints at a credential. Mirrors publicConfig() in vercel-dashboard/api/_lib.js.
SECRET = re.compile(
    r'TOKEN|HASH|PASSWORD|PASSWD|SECRET|SESSION|DATABASE_URL|API_KEY|PRIVATE|TELEGRAM|'
    r'LOGIN_PASS|CREDENTIAL|_PWD', re.I)

# Identifiers rather than secrets: harmless, but still not shown in full.
IDENTIFIER = re.compile(r'(_ID$|^OWNER_ID$|^SUDO_USERS$|^AUTHORIZED_CHATS$|^FSUB_IDS$|'
                        r'^EXCEP_CHATS$|^RSS_CHAT$|^LEECH_LOG_ID$|^MIRROR_LOG_ID$|'
                        r'^LINKS_LOG_ID$|^GDRIVE_ID$)', re.I)

BOOLEAN = re.compile(r'^(BOT_PM|SAVE_MSG|SAFE_MODE|SET_COMMANDS|CLEAN_LOG_MSG|'
                     r'SHOW_EXTRA_CMDS|SCREENSHOTS_MODE|MEDIA_GROUP|QUEUE_ALL|'
                     r'QUEUE_DOWNLOAD|QUEUE_UPLOAD|IS_TEAM_DRIVE|USE_SERVICE_ACCOUNTS|'
                     r'AS_DOCUMENT|DELETE_LINKS|DISABLE_DRIVE_LINK|'
                     r'INCOMPLETE_TASK_NOTIFIER|STOP_DUPLICATE|USER_TD_MODE|'
                     r'EQUAL_SPLIT|EXTERNAL_DAEMONS|SYNC_CONFIG_ENV)$', re.I)
INTEGER = re.compile(r'(LIMIT|_PORT|_DURATION|_INTERVAL|_SIZE|_THRESHOLD|_TIMEOUT|'
                     r'OWNER_ID|TELEGRAM_API|STATUS_LIMIT)$', re.I)
LIST = re.compile(r'^(IMAGES|IMG_SEARCH|EXTENSION_FILTER|AUTHORIZED_CHATS|EXCEP_CHATS|'
                  r'FSUB_IDS|SUDO_USERS|BLACKLIST_USERS|SEARCH_PLUGINS)$', re.I)
TEXT = re.compile(r'(TEMPLATE|_MESSAGE|YT_DLP_OPTIONS)$', re.I)

# The daemon wiring a download box needs - nothing else, so it cannot learn bot credentials.
DAEMON_KEYS = {
    'ARIA2_HOST', 'ARIA2_PORT', 'ARIA2_SECRET', 'QBIT_HOST', 'QBIT_PORT',
    'QBIT_USERNAME', 'QBIT_PASSWORD', 'DOWNLOAD_DIR', 'BASE_URL', 'BASE_URL_PORT',
}
GATEWAY_KEYS = {'GATEWAY_TOKEN', 'RUNTIMES', 'UPSTREAM_TIMEOUT'}
RUNTIME_ONLY = {'API_TOKEN', 'API_MAX_TASKS', 'EXTERNAL_DAEMONS', 'SYNC_CONFIG_ENV',
                'COMPONENT_ID', 'COMPONENT_TOKEN', 'RESTART_API', 'RESTART_DELAY'}

# Keys the code reads via os.environ but that never appear in config.env, so the
# generator would otherwise miss them and the settings page would not offer them.
# Keep this in sync with deploy/check_schema_complete.py, which fails the build if
# a variable read by the code is missing from the generated schema.
EXTRA_KEYS = {
    'RESTART_API': 'allow POST /api/restart so the dashboard can restart this runtime',
    'RESTART_DELAY': 'seconds to wait before exiting on a restart request',
    'API_MAX_TASKS': 'how many tasks /api/torrents reports at once',
}


GROUPS = [
    (('BOT_', 'OWNER_ID', 'SUDO_USERS', 'AUTHORIZED_CHATS', 'EXCEP_CHATS', 'FSUB_IDS',
      'LEECH_LOG_ID', 'MIRROR_LOG_ID', 'LINKS_LOG_ID', 'RSS_CHAT', 'BLACKLIST_USERS',
      'AUTHOR_NAME', 'AUTHOR_URL', 'TITLE_NAME', 'COVER_IMAGE', 'TIMEZONE', 'CMD_SUFFIX',
      'WEB_PINCODE'), 'Bot / access'),
    (('TELEGRAM_API', 'TELEGRAM_HASH', 'USER_SESSION_STRING', 'USER_TD_MODE',
      'USER_TD_SA'), 'Telegram credentials'),
    (('DATABASE_URL',), 'Database'),
    (('GDRIVE_', 'GDTOT', 'DEFAULT_UPLOAD', 'USE_SERVICE_ACCOUNTS', 'IS_TEAM_DRIVE',
      'DISABLE_DRIVE_LINK', 'INDEX_URL'), 'Google Drive'),
    (('RCLONE', 'MEGA_', 'JIODRIVE', 'REAL_DEBRID', 'DEBRID', 'FILELION'),
     'Other uploaders'),
    (('ARIA2', 'QBIT', 'EXTERNAL_DAEMONS', 'DOWNLOAD_DIR'), 'Download daemons'),
    (('API_TOKEN', 'API_MAX_TASKS'), 'Control API'),
    (('GATEWAY_', 'RUNTIMES', 'UPSTREAM_TIMEOUT'), 'Control plane'),
    (('LIMIT', 'MAX_', 'QUEUE_', 'STATUS_', 'AUTO_DELETE', 'TOKEN_TIMEOUT',
      'STORAGE_THRESHOLD', 'STOP_DUPLICATE', 'MEDIA_GROUP', 'SAFE_MODE',
      'INCOMPLETE_TASK_NOTIFIER', 'EQUAL_SPLITS', 'AS_DOCUMENT', 'DELETE_LINKS',
      'RSS_DELAY', 'IMG_', 'SEARCH_', 'LEECH_FILENAME', 'MIRROR_FILENAME'),
     'Limits & behaviour'),
    (('IMAGES', 'IMDB_TEMPLATE', 'ANIME_TEMPLATE', 'MDL_TEMPLATE', 'CAP_FONT',
      'SET_COMMANDS', 'SHOW_EXTRA_CMDS', 'SCREENSHOTS_MODE', 'SOURCE_LINK'),
     'Appearance'),
    (('UPSTREAM_', 'UPGRADE_PACKAGES', 'SYNC_CONFIG_ENV', 'COMPONENT_'), 'Deployment'),
]


def parse_env(path):
    values = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        match = re.match(r'^\s*([A-Z][A-Z0-9_]*)\s*=\s*(.*)$', line)
        if not match:
            continue
        raw = re.sub(r'\s+#.*$', '', match.group(2)).strip()
        if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in '"\'':
            raw = raw[1:-1]
        values[match.group(1)] = raw
    return values


def group_for(key):
    for prefixes, name in GROUPS:
        if key in prefixes or any(key.startswith(p) for p in prefixes):
            return name
    return 'Other'


def kind_for(key):
    for pattern, kind in ((BOOLEAN, 'boolean'), (LIST, 'list'), (TEXT, 'text'),
                          (INTEGER, 'integer')):
        if pattern.match(key):
            return kind
    return 'string'


def main():
    merged = {}
    for name in ('config_sample.env', 'config.env'):
        for key, value in parse_env(ROOT / name).items():
            merged.setdefault(key, value)
    for key in ('BASE_URL_PORT', 'EXTERNAL_DAEMONS', 'API_TOKEN', 'API_MAX_TASKS',
                'COMPONENT_ID', 'COMPONENT_TOKEN', 'ARIA2_HOST', 'ARIA2_PORT',
                'ARIA2_SECRET', 'QBIT_HOST', 'QBIT_PORT', 'QBIT_USERNAME',
                'QBIT_PASSWORD', 'GATEWAY_TOKEN', 'RUNTIMES', 'UPSTREAM_TIMEOUT',
                'RESTART_API', 'RESTART_DELAY'):
        merged.setdefault(key, EXTRA_KEYS.get(key, ''))

    keys = {}
    for key in sorted(merged):
        info_secret = bool(SECRET.search(key)) and key != 'TELEGRAM_API'
        scope = 'daemons' if key in DAEMON_KEYS else 'runtime'
        if key in GATEWAY_KEYS:
            scope = 'gateway'
        keys[key] = {
            'secret': info_secret,
            'identifier': bool(IDENTIFIER.search(key)),
            'type': kind_for(key),
            'scope': scope,
            'group': group_for(key),
        }

    # Never let a real credential into a file that gets packaged: schema.json ships
    # inside the Vercel zip, so a secret default here would be a secret in git.
    defaults = {k: ('' if keys[k]['secret'] else merged[k]) for k in sorted(merged)}
    defaults['OWNER_ID'] = ''
    defaults['LEECH_LOG_ID'] = defaults['MIRROR_LOG_ID'] = defaults['LINKS_LOG_ID'] = ''
    defaults['GDRIVE_ID'] = defaults['MEGA_EMAIL'] = defaults['MEGA_PASSWORD'] = ''

    schema = {
        'version': 1,
        'defaults': defaults,
        'keys': keys,
        'components': {
            scope: sorted(k for k, v in keys.items() if v['scope'] == scope)
            for scope in ('runtime', 'gateway', 'daemons')
        },
    }
    OUT.write_text(json.dumps(schema, indent=2) + '\n', encoding='utf-8')
    print(f'{OUT} : {len(keys)} keys')
    for scope in ('runtime', 'gateway', 'daemons'):
        print(f'  {scope:<8} {len(schema["components"][scope]):>3} keys')


if __name__ == '__main__':
    main()

