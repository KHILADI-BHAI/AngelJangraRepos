#!/usr/bin/env bash
# aria2c for a *remote* download part (see SPLIT_DEPLOY.md).
#
# Same flags as aria.sh, with three differences that only make sense when the
# daemon is reached over the network instead of through localhost:
#   * --rpc-listen-all  (default true, restrict with ARIA2_LISTEN_ALL=false)
#   * --rpc-secret      (ALWAYS set this when the RPC is reachable by others)
#   * --daemon=false    so this script stays in the foreground (containers)
#
# Environment:
#   ARIA2_SECRET       shared secret for the JSON-RPC API (empty = no auth!)
#   ARIA2_RPC_PORT     RPC port, default 6800
#   ARIA2_LISTEN_ALL   true|false, default true
#   ARIA2_DIR          download directory, default /usr/src/app/downloads
#   ARIA2_FILE_ALLOCATION  prealloc (default) or none on network filesystems
#   ARIA2_EXTRA_FLAGS  extra flags, e.g. "--max-overall-download-limit=10M"
set -euo pipefail

RPC_PORT="${ARIA2_RPC_PORT:-6800}"
RPC_SECRET="${ARIA2_SECRET:-}"
LISTEN_ALL="${ARIA2_LISTEN_ALL:-true}"
DL_DIR="${ARIA2_DIR:-/usr/src/app/downloads}"
FILE_ALLOCATION="${ARIA2_FILE_ALLOCATION:-prealloc}"

if [ -z "$RPC_SECRET" ] && [ "$LISTEN_ALL" = "true" ]; then
    echo "[!] ARIA2_SECRET is empty while ARIA2_LISTEN_ALL=true - anyone who can reach port $RPC_PORT may write files. Do not expose this port to the internet."
fi

# the tracker list is optional, keep the daemon starting when there is no network yet
tracker_list=$(curl -Ns --max-time 20 https://ngosang.github.io/trackerslist/trackers_all_http.txt 2>/dev/null | awk '$0' | tr '\n\n' ',') || tracker_list=""

mkdir -p "$DL_DIR"

exec aria2c --allow-overwrite=true --auto-file-renaming=true --bt-enable-lpd=true --bt-detach-seed-only=true \
       --bt-remove-unselected-file=true --bt-tracker="[$tracker_list]" --bt-max-peers=0 --enable-rpc=true \
       --rpc-listen-all="$LISTEN_ALL" --rpc-listen-port="$RPC_PORT" --rpc-secret="$RPC_SECRET" \
       --rpc-max-request-size=1024M --max-connection-per-server=10 --max-concurrent-downloads=10 --split=10 \
       --seed-ratio=0 --check-integrity=true --continue=true --daemon=false --disk-cache=40M --force-save=true \
       --min-split-size=10M --follow-torrent=mem --check-certificate=false --optimize-concurrent-downloads=true \
       --http-accept-gzip=true --max-file-not-found=0 --max-tries=20 --peer-id-prefix=-qB4520- --reuse-uri=true \
       --content-disposition-default-utf8=true --user-agent=Wget/1.12 --peer-agent=qBittorrent/4.5.2 --quiet=true \
       --summary-interval=0 --max-upload-limit=1K --file-allocation="$FILE_ALLOCATION" --dir="$DL_DIR" \
       ${ARIA2_EXTRA_FLAGS:-}
