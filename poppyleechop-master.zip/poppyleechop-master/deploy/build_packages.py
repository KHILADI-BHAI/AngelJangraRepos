#!/usr/bin/env python3
"""Build one ready-to-deploy zip per deploy target and per account slot.

    python deploy/build_packages.py                    # 2 runtime accounts + gateway + selector + vercel + daemons
    python deploy/build_packages.py --accounts 3
    python deploy/build_packages.py --runtime-host deplexo
    python deploy/build_packages.py --out deploy/dist --clean

Stdlib only, so it runs on the Windows dev box and on CI unchanged. Each zip is a complete
package: push/upload it, fill in the env vars from `.env.example`, deploy.

Packages produced (the account slot is in the file name):
    01-<host>-acc1-runtime.zip         bot + aria2 + qBittorrent in one container, own disk
    02-<host>-acc2-runtime.zip         second Telegram token = second account, no 409 Conflict
    ..-<host>-accN-runtime.zip
    <n>-deplexo-acc1-gateway.zip       stateless control plane in front of all runtimes
    <n>-deplexo-acc2-web-selector.zip  file selector + control API on a separate account
    <n>-vercel-dashboard.zip           dashboard, static UI, API facade, cron
    <n>-daemons-vps.zip                daemons-only box for a machine with a real disk
"""

from argparse import ArgumentParser
from pathlib import Path
from re import MULTILINE, findall
from secrets import token_hex
from shutil import rmtree
from zipfile import ZIP_DEFLATED, ZipFile
import sys

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / 'deploy' / 'dist'
PAAS = ROOT / 'deploy' / 'paas'

# Explicit include list on purpose: `.venv` (315 MB) and `qBittorrent/` (270 MB) stay out,
# which is the difference between a ~2 MB zip and a 600 MB one.
RUNTIME_ENTRIES = [
    'bot', 'web', 'aria.sh', 'start.sh', 'update.py', 'requirements.txt',
    'requirements-cli.txt', 'add_to_team_drive.py', 'driveid.py',
    'gen_sa_accounts.py', 'generate_drive_token.py', 'captain-definition', '.dockerignore',
]
SKIP_NAMES = {'__pycache__', 'bot.session', 'user.session', 'log.txt', 'rlog.txt',
              'pip_install.log', 'unknown_errors.txt'}
SKIP_SUFFIXES = ('.pyc', '.pyo', '.session-journal')

HOST_LABEL = {'snapdeploy': 'SnapDeploy', 'deplexo': 'Deplexo',
              'render': 'Render', 'railway': 'Railway'}

SECRET_KEYS = ('BOT_TOKEN', 'OWNER_ID', 'TELEGRAM_API', 'TELEGRAM_HASH', 'DATABASE_URL',
               'USER_SESSION_STRING', 'GDRIVE_ID', 'DEFAULT_UPLOAD')


def iter_files(path):
    """Yield (absolute path, archive name) for one include entry."""
    if path.is_file():
        yield path, path.name
        return
    for child in sorted(path.rglob('*')):
        if not child.is_file():
            continue
        rel = child.relative_to(path)
        if any(part in SKIP_NAMES for part in rel.parts) or child.name.endswith(SKIP_SUFFIXES):
            continue
        yield child, f"{path.name}/{rel.as_posix()}"


def config_keys():
    """Every config key this repo knows about - the allowlist the entrypoint uses."""
    keys = set()
    for name in ('config.env', 'config_sample.env'):
        source = ROOT / name
        if source.exists():
            keys.update(findall(r'^\s*([A-Z][A-Z0-9_]*)\s*=', source.read_text(encoding='utf-8', errors='ignore'), MULTILINE))
    keys.update({'BASE_URL', 'BASE_URL_PORT', 'EXTERNAL_DAEMONS'})
    return sorted(keys)


def write_config_keys():
    keys = config_keys()
    PAAS.mkdir(parents=True, exist_ok=True)
    (PAAS / 'config.keys').write_text('\n'.join(keys) + '\n', encoding='utf-8')
    return keys


def parse_dotenv(path):
    """Read config.env without python-dotenv (values may be quoted or bare)."""
    values = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = line.split('#', 1)[0].strip()
        if '=' not in line:
            continue
        key, _, value = line.partition('=')
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def write_text_entry(zip_file, arcname, text):
    zip_file.writestr(arcname, text.replace('\r\n', '\n'))


def write_normalized(zip_file, source, arcname=None):
    """Copy a file into the zip with LF endings: CRLF in a shebang or Dockerfile breaks Linux."""
    data = Path(source).read_bytes().replace(b'\r\n', b'\n')
    zip_file.writestr(arcname or Path(source).name, data)


def add_path(zip_file, source, arcname=None):
    for path, name in iter_files(source):
        write_normalized(zip_file, path, arcname or name)


def runtime_env_example(account, host):
    label = HOST_LABEL.get(host, host)
    return f"""# {label} runtime - account slot {account}
# Copy these into the platform's "Environment Variables" UI. Never commit real values.

# --- required -------------------------------------------------------------
BOT_TOKEN=            # UNIQUE per container. Same token twice = Telegram 409 Conflict.
OWNER_ID=
TELEGRAM_API=
TELEGRAM_HASH=
DATABASE_URL=         # MongoDB Atlas M0 - keeps settings, users, rss and tokens alive

# --- this deploy ----------------------------------------------------------
API_TOKEN=            # openssl rand -hex 32 - protects /api/stats and /api/torrents
BASE_URL=             # https://your-app-{account}.{host}.app - public URL of THIS app
BASE_URL_PORT=8080    # must equal PORT
PORT=8080             # routed port (Deplexo routes to 3000 when PORT is unset)
DOWNLOAD_DIR=/usr/src/app/downloads/
EXTERNAL_DAEMONS=false  # keep false: this container runs its own aria2 + qBittorrent
SYNC_CONFIG_ENV=true

# --- upload target (pick one) --------------------------------------------
GDRIVE_ID=
RCLONE_PATH=
DEFAULT_UPLOAD=gd
CMD_SUFFIX=
UPSTREAM_REPO=        # MUST stay empty, otherwise update.py git-resets this code away
"""


def runtime_deploy_notes(account, host):
    label = HOST_LABEL.get(host, host)
    return f"""WZML-X runtime - {label} - account slot {account}
========================================================

1. Push this folder to its own Git repository (or upload the zip, if the platform accepts zips).
2. {label}: New app -> Docker / Dockerfile build -> pick that repository.
3. Paste the variables from `.env.example`. BOT_TOKEN must be account {account}'s own token:
   get extra tokens with /clone in Telegram so two containers never poll one token.
4. Deploy, then check:
     https://<app>/healthz      -> ok
     https://<app>/api/health   -> JSON, aria2 + qbittorrent up:true
5. Full guidance in README-DEPLOY.md.

Why everything is in ONE container: aria2c and qbittorrent-nox must write the exact
absolute paths the bot reads back to unpack and upload. Managed platforms give each
container an ephemeral disk and no NFS/SMB, so the two halves cannot share a filesystem.
Scale out with more accounts (each with its own Telegram token), not by splitting one bot.
"""


def filled_env(account, host, secrets, api_token, runtime_urls):
    """The ONLY values you paste into a platform UI. Everything else comes from Vercel.

    Kept out of the zips (they carry placeholders only) and written to
    deploy/dist/env/ for you to copy from.
    """
    label = HOST_LABEL.get(host, host)
    return f"""# {label} acc{account}: paste these TWO lines into the platform env UI, nothing else.
# Everything else - bot token, Mongo, Drive, all 126 settings - is fetched at boot
# from https://poppyleechop.vercel.app by deploy/paas/config_pull.py.
COMPONENT_ID=acc{account}
COMPONENT_TOKEN=PASTE_THE_TOKEN_THE_SETTINGS_PAGE_SHOWED_YOU

# --- optional, set on the Vercel project instead, not here ---
# API_TOKEN={api_token}
# RESTART_API=true
# runtime URL to register on the settings page: https://REPLACE-WITH-THE-APP-URL
# gateway RUNTIMES entry: acc{account}=https://REPLACE-WITH-THE-APP-URL|{api_token}
"""


def build_runtime(account, host, index, keys, secrets):
    archive = DIST / f"{index:02d}-{host}-acc{account}-runtime.zip"
    api_token = token_hex(32)
    with ZipFile(archive, 'w', ZIP_DEFLATED) as zip_file:
        for entry in RUNTIME_ENTRIES:
            source = ROOT / entry
            if source.exists():
                add_path(zip_file, source)
        add_path(zip_file, PAAS / 'entrypoint.sh', 'deploy/paas/entrypoint.sh')
        add_path(zip_file, PAAS / 'config_pull.py', 'deploy/paas/config_pull.py')
        write_text_entry(zip_file, 'deploy/paas/config.keys', '\n'.join(keys) + '\n')
        write_normalized(zip_file, PAAS / 'Dockerfile.paas', 'Dockerfile')
        write_normalized(zip_file, PAAS / 'deplexo.yaml', 'deplexo.yaml')
        write_normalized(zip_file, PAAS / 'README-runtime.md', 'README-DEPLOY.md')
        write_text_entry(zip_file, '.env.example', runtime_env_example(account, host))
        write_text_entry(zip_file, 'DEPLOY.txt', runtime_deploy_notes(account, host))
    env_dir = DIST / 'env'
    env_dir.mkdir(parents=True, exist_ok=True)
    (env_dir / f"{host}-acc{account}.env").write_text(
        filled_env(account, host, secrets, api_token, ''), encoding='utf-8')
    return archive, api_token


def build_gateway(index, gateway_token):
    archive = DIST / f"{index:02d}-deplexo-acc1-gateway.zip"
    example = f"""# Control-plane gateway (Deplexo acc1). CONTAINS SECRETS: do not commit.
GATEWAY_TOKEN={gateway_token}
RUNTIMES=acc1=https://app-1.snapdeploy.app|PASTE_RUNTIME_1_API_TOKEN,acc2=https://app-2.snapdeploy.app|PASTE_RUNTIME_2_API_TOKEN
UPSTREAM_TIMEOUT=10
PORT=8080
"""
    with ZipFile(archive, 'w', ZIP_DEFLATED) as zip_file:
        for name in ('app.py', 'Dockerfile', 'requirements.txt', 'gateway.keys'):
            write_normalized(zip_file, PAAS / 'api-gateway' / name, name)
        write_normalized(zip_file, PAAS / 'config_pull.py', 'config_pull.py')
        write_normalized(zip_file, PAAS / 'deplexo.yaml', 'deplexo.yaml')
        write_normalized(zip_file, PAAS / 'README-gateway.md', 'README-DEPLOY.md')
        write_text_entry(zip_file, '.env.example', example)
    return archive


def build_selector(index, host='deplexo'):
    archive = DIST / f"{index:02d}-{host}-acc2-web-selector.zip"
    example = """# Standalone file selector + control API. Point it at the daemons it should serve.
ARIA2_HOST=https://your-daemon-host          # aria2 RPC (http/https), or an internal host name
ARIA2_PORT=6800
ARIA2_SECRET=
QBIT_HOST=https://your-daemon-host           # qBittorrent WebUI
QBIT_PORT=8090
QBIT_USERNAME=
QBIT_PASSWORD=
DOWNLOAD_DIR=/usr/src/app/downloads/         # same absolute path the daemons write to
API_TOKEN=                                   # enables /api/stats, /api/torrents and actions
BASE_URL=
BASE_URL_PORT=8080
PORT=8080
"""
    with ZipFile(archive, 'w', ZIP_DEFLATED) as zip_file:
        add_path(zip_file, ROOT / 'web')
        write_normalized(zip_file, PAAS / 'web-selector' / 'requirements-web.txt', 'requirements-web.txt')
        write_normalized(zip_file, PAAS / 'web-selector' / 'Dockerfile', 'Dockerfile')
        write_normalized(zip_file, PAAS / 'web-selector' / 'README.md', 'README-DEPLOY.md')
        write_normalized(zip_file, PAAS / 'deplexo.yaml', 'deplexo.yaml')
        write_text_entry(zip_file, '.env.example', example)
    return archive

def build_vercel(index, gateway_token, dashboard_token, secrets):
    archive = DIST / f"{index:02d}-vercel-dashboard.zip"
    source = ROOT / 'vercel-dashboard'
    with ZipFile(archive, 'w', ZIP_DEFLATED) as zip_file:
        for child in sorted(source.rglob('*')):
            if not child.is_file():
                continue
            rel = child.relative_to(source)
            # node_modules is a local artifact; Vercel installs from package.json
            if 'node_modules' in rel.parts or any(part in SKIP_NAMES for part in rel.parts) \
                    or child.name.endswith(SKIP_SUFFIXES):
                continue
            write_normalized(zip_file, child, rel.as_posix())
    bot_id = str(secrets.get('BOT_TOKEN', '')).split(':', 1)[0]
    (DIST / 'env' / 'vercel.env').write_text(f"""# Vercel project env - CONTAINS SECRETS: do not commit.
# These are the ONLY values you set outside the dashboard. Everything else is entered
# once at https://poppyleechop.vercel.app/settings and pulled by each container.
ADMIN_TOKEN={token_hex(32)}          # unlocks /settings (write authority)
CONFIG_MASTER_KEY={token_hex(32)}    # encrypts stored values at rest - KEEP IT SAFE
DATABASE_URL={secrets.get('DATABASE_URL', '')}
BOT_ID={bot_id}
MONGO_DB=wzmlx
GATEWAY_URL=https://REPLACE-WITH-YOUR-GATEWAY.deplexo.com
GATEWAY_TOKEN={gateway_token}
DASHBOARD_TOKEN={dashboard_token}
RUNTIME_NAME=acc1
# RUNTIME_URL=https://your-app.snapdeploy.app   # only for the direct (no-gateway) mode
# RUNTIME_TOKEN=
CRON_SECRET={token_hex(24)}
""", encoding='utf-8')
    return archive


def build_daemons(index):
    archive = DIST / f"{index:02d}-daemons-vps.zip"
    entries = [
        (ROOT / 'docker-compose.split.yml', 'docker-compose.split.yml'),
        (ROOT / '.env.split.example', '.env.split.example'),
        (ROOT / 'deploy' / 'aria.remote.sh', 'deploy/aria.remote.sh'),
        (ROOT / 'deploy' / 'set_qbittorrent_auth.py', 'deploy/set_qbittorrent_auth.py'),
        (ROOT / 'deploy' / 'paas' / 'config_pull.py', 'deploy/paas/config_pull.py'),
        (ROOT / 'deploy' / 'paas' / 'config.keys', 'deploy/paas/config.keys'),
        (ROOT / 'aria.sh', 'aria.sh'),
        (ROOT / 'start_windows.ps1', 'start_windows.ps1'),
        (ROOT / 'SPLIT_DEPLOY.md', 'SPLIT_DEPLOY.md'),
    ]
    with ZipFile(archive, 'w', ZIP_DEFLATED) as zip_file:
        for source, name in entries:
            if source.exists():
                write_normalized(zip_file, source, name)
        write_normalized(zip_file, PAAS / 'README-daemons.md', 'README-DEPLOY.md')
    return archive


def write_manifest(rows, keys, host, accounts):
    lines = [
        '# Split-deployment packages',
        '',
        f"Generated by `deploy/build_packages.py` (runtime host: **{HOST_LABEL.get(host, host)}**, "
        f"{accounts} runtime account slot(s), {len(keys)} config keys in the entrypoint allowlist).",
        '',
        '| Zip | Deployer | Account slot | What it is |',
        '| --- | --- | --- | --- |',
    ]
    for name, deployer, account, note in rows:
        lines.append(f'| `{name}` | {deployer} | {account} | {note} |')
    lines += [
        '',
        '## Order of operations',
        '',
        '1. MongoDB Atlas M0 first - everything else depends on `DATABASE_URL`.',
        '2. Deploy the runtime packages (`*-runtime.zip`), note each app URL.',
        '3. Deploy the gateway (`*-gateway.zip`) and put every runtime URL + its `API_TOKEN`',
        '   into `RUNTIMES`.',
        '4. Deploy the Vercel dashboard, then set `GATEWAY_URL`, `GATEWAY_TOKEN`,',
        '   `DASHBOARD_TOKEN`, `DATABASE_URL`, `BOT_ID`.',
        '5. Point each bot\'s `BASE_URL` at the Vercel project so the file selector has one stable',
        '   HTTPS URL.',
        '',
        '## Secrets',
        '',
        'The zips only carry `.env.example` placeholders. Real values live in `deploy/dist/env/`',
        '(`<host>-accN.env`, `vercel.env`) - that folder is gitignored, never commit or share it.',
        '',
        '## Remember',
        '',
        '- One Telegram token per container, otherwise 409 Conflict. Use `/clone` for extras.',
        '- `EXTERNAL_DAEMONS=false` on every runtime package; `true` only for a daemons-only box.',
        '- `UPSTREAM_REPO` must stay empty or `update.py` will `git reset --hard` this code away.',
        '- Managed platforms have ephemeral disks: downloads and sessions are lost on redeploy, so',
        '  keep at least one box with a real disk.',
    ]
    (DIST / 'MANIFEST.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def verify(packages, secrets):
    """Fail loudly if a real credential or a broken line ending would ship in a package.

    Only genuinely secret keys are checked. Ordinary values such as TIMEZONE or
    DOWNLOAD_DIR appear in the source code by design, so scanning for those would
    produce nothing but false positives.
    """
    problems = []
    secret_names = ('BOT_TOKEN', 'TELEGRAM_HASH', 'TELEGRAM_API', 'DATABASE_URL',
                    'USER_SESSION_STRING', 'MEGA_PASSWORD', 'MEGA_EMAIL', 'GDRIVE_ID',
                    'OWNER_ID', 'LOGIN_PASS', 'JIODRIVE_TOKEN', 'GDTOT_CRYPT',
                    'REAL_DEBRID_API', 'DEBRID_LINK_API', 'FILELION_API')
    needles = {k: secrets[k] for k in secret_names
               if secrets.get(k) and len(str(secrets[k])) >= 8}
    vercel_required = ('api/config.js', 'api/resolve.js', 'api/push.js', 'api/settings.js',
                       'api/_store.js', 'api/schema.json', 'public/settings.html',
                       'public/settings.js', 'vercel.json')
    for archive in packages:
        with ZipFile(archive) as zf:
            names = zf.namelist()
            if 'vercel-dashboard' in archive.name:
                for required in vercel_required:
                    if required not in names:
                        problems.append(f'{archive.name}: missing {required}')
                if any(n.startswith('node_modules/') for n in names):
                    problems.append(f'{archive.name}: node_modules was packaged')
            elif archive.name.endswith('runtime.zip'):
                for required in ('deploy/paas/config_pull.py', 'deploy/paas/config.keys'):
                    if required not in names:
                        problems.append(f'{archive.name}: missing {required}')
            elif archive.name.endswith('gateway.zip'):
                for required in ('config_pull.py', 'gateway.keys'):
                    if required not in names:
                        problems.append(f'{archive.name}: missing {required}')
            for name in names:
                if name.endswith(('.env', 'config.env')) and '.example' not in name:
                    problems.append(f'{archive.name}: ships a real env file ({name})')
                try:
                    blob = zf.read(name).decode('utf-8')
                except (UnicodeDecodeError, KeyError):
                    continue
                if name.endswith(('.sh', 'Dockerfile', 'deplexo.yaml', '.py', '.yaml')) and '\r\n' in blob:
                    problems.append(f'{archive.name}: {name} has CRLF line endings')
                for key, value in needles.items():
                    if str(value) in blob:
                        problems.append(f'{archive.name}: {name} leaks the value of {key}')
    return problems


def main():
    global DIST

    parser = ArgumentParser(description='Build one deployable zip per target and account slot.')
    parser.add_argument('--accounts', type=int, default=2,
                        help='runtime containers/accounts to package (default 2)')
    parser.add_argument('--runtime-host', default='snapdeploy', choices=sorted(HOST_LABEL),
                        help='provider for the runtime packages')
    parser.add_argument('--out', default=str(DIST), help='output directory (default deploy/dist)')
    parser.add_argument('--clean', action='store_true', help='wipe the output directory first')
    parser.add_argument('--skip-daemons', action='store_true', help='skip the daemons-only package')
    args = parser.parse_args()

    DIST = Path(args.out).resolve()
    if args.clean and DIST.exists():
        rmtree(DIST)
    (DIST / 'env').mkdir(parents=True, exist_ok=True)

    keys = write_config_keys()
    secrets = parse_dotenv(ROOT / 'config.env')
    gateway_token = token_hex(32)
    dashboard_token = token_hex(32)
    rows, index, tokens = [], 1, []

    for account in range(1, args.accounts + 1):
        archive, api_token = build_runtime(account, args.runtime_host, index, keys, secrets)
        tokens.append((f'acc{account}', api_token))
        rows.append((archive.name, HOST_LABEL.get(args.runtime_host, args.runtime_host), f'acc{account}',
                     'bot + aria2 + qBittorrent runtime container (own disk, own Telegram token)'))
        index += 1

    archive = build_gateway(index, gateway_token)
    rows.append((archive.name, 'Deplexo', 'acc1',
                 'stateless control-plane gateway in front of all runtimes'))
    index += 1

    archive = build_selector(index)
    rows.append((archive.name, 'Deplexo', 'acc2', 'standalone file selector + control API'))
    index += 1

    archive = build_vercel(index, gateway_token, dashboard_token, secrets)
    rows.append((archive.name, 'Vercel', '-', 'dashboard, static UI, API facade, cron pinger'))
    index += 1

    if not args.skip_daemons:
        archive = build_daemons(index)
        rows.append((archive.name, 'VPS / PC', '-', 'daemons-only box with a real disk (cross-host split)'))

    write_manifest(rows, keys, args.runtime_host, args.accounts)

    problems = verify([DIST / row[0] for row in rows], secrets)
    if problems:
        print('\nPACKAGE VERIFICATION FAILED:')
        for problem in problems:
            print(f'  - {problem}')
        return 1

    print(f'Packages written to {DIST}')
    for name, deployer, account, note in rows:
        size = (DIST / name).stat().st_size / 1024
        print(f'  {name:<42} {deployer:<11} {account:<6} {size:8.1f} KB  {note}')
    print('\nPer-runtime API tokens (they also belong in the gateway RUNTIMES value):')
    for account, api_token in tokens:
        print(f'  {account}: {api_token}')
    print(f'\nGateway token:   {gateway_token}')
    print(f'Dashboard token: {dashboard_token}')
    print(f'Env files with real values: {DIST / "env"}')
    print(f'Manifest: {DIST / "MANIFEST.md"}')


if __name__ == '__main__':
    sys.exit(main() or 0)



