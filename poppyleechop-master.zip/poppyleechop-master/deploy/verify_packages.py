#!/usr/bin/env python3
"""Validate every package in deploy/dist before you upload it anywhere.

    python deploy/verify_packages.py
    python deploy/verify_packages.py --dist deploy/dist

Per package type it checks that the files a deploy target needs are present, that nothing
which must not ship is inside (config.env, sessions, .venv, qBittorrent profile, values from
your local config.env), that shell/Dockerfile entries use LF endings, and that
vercel.json/JS entries parse. Non-zero exit code means "do not upload".
"""

from argparse import ArgumentParser
from json import loads
from pathlib import Path
from re import IGNORECASE, compile as re_compile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent.parent
SECRET_KEY_RE = re_compile(r'(TOKEN|HASH|SESSION|SECRET|PASSWORD|PASSWD|DATABASE_URL|API_KEY|COOKIES|PRIVATE_KEY)', IGNORECASE)
SAFE_VALUES = {'/usr/src/app/downloads/', 'Asia/Kolkata', 'master'}
TEXT_SUFFIXES = ('.sh', '.txt', '.md', '.py', '.js', '.json', '.yaml', '.yml', '.env', '.keys')
LF_REQUIRED = ('Dockerfile', 'entrypoint.sh', 'aria.sh', 'start.sh', 'aria.remote.sh', '.env.example')

REQUIRED = {
    'runtime': [
        'Dockerfile', 'deplexo.yaml', 'start.sh', 'aria.sh', 'update.py', 'requirements.txt',
        'bot/__init__.py', 'bot/__main__.py', 'web/api.py', 'web/wserver.py', 'web/nodes.py',
        'deploy/paas/entrypoint.sh', 'deploy/paas/config.keys', '.env.example',
        'README-DEPLOY.md', 'DEPLOY.txt', '.dockerignore',
    ],
    'gateway': ['app.py', 'Dockerfile', 'requirements.txt', 'deplexo.yaml', '.env.example', 'README-DEPLOY.md'],
    'web-selector': ['web/wserver.py', 'web/api.py', 'web/nodes.py', 'requirements-web.txt',
                     'Dockerfile', 'deplexo.yaml', '.env.example', 'README-DEPLOY.md'],
    'vercel-dashboard': ['package.json', 'vercel.json', 'README.md', '.env.example',
                         'public/index.html', 'public/app.js', 'public/styles.css',
                         'api/_lib.js', 'api/health.js', 'api/status.js', 'api/torrents.js',
                         'api/action.js', 'api/users.js', 'api/files.js', 'api/ping.js'],
    'daemons': ['docker-compose.split.yml', 'SPLIT_DEPLOY.md', 'aria.sh',
                'deploy/aria.remote.sh', 'deploy/set_qbittorrent_auth.py', 'README-DEPLOY.md'],
}

FORBIDDEN_ANYWHERE = ('config.env', '.venv', 'qBittorrent/', '__pycache__', 'bot.session',
                      'user.session', '.session-journal', 'node_modules/', '.git/')


def package_kind(name):
    for kind in ('gateway', 'web-selector', 'vercel-dashboard', 'daemons', 'runtime'):
        if kind in name:
            return kind
    return None


def local_secrets():
    """Values from the dev box that must never end up inside a zip.

    Only real credentials are watched (token/hash/session/db-url style keys) so harmless
    defaults like DOWNLOAD_DIR=/usr/src/app/downloads/ do not raise false alarms.
    """
    values = set()
    source = ROOT / 'config.env'
    if not source.exists():
        return values
    for line in source.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = line.split('#', 1)[0].strip()
        if '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if len(value) < 20 or value in SAFE_VALUES:
            continue
        if SECRET_KEY_RE.search(key):
            values.add(value)
    return values


def verify(archive, secrets):
    problems, notes = [], []
    kind = package_kind(archive.name)
    with ZipFile(archive) as zip_file:
        names = zip_file.namelist()
        lowered = [name.lower() for name in names]

        for wanted in REQUIRED.get(kind, []):
            if wanted not in names:
                problems.append(f'missing {wanted}')

        for bad in FORBIDDEN_ANYWHERE:
            hit = [name for name in lowered if bad.lower() in name]
            if hit:
                problems.append(f'contains {bad} ({hit[:3]})')

        for name in names:
            if Path(name).suffix not in TEXT_SUFFIXES and not name.endswith('Dockerfile'):
                continue
            try:
                body = zip_file.read(name)
            except KeyError:
                continue
            if body.count(b'\r\n') and any(name.endswith(target) for target in LF_REQUIRED):
                problems.append(f'{name} has CRLF endings (bash/Docker break in Linux containers)')
            text = body.decode('utf-8', errors='ignore')
            for secret in secrets:
                if secret in text:
                    problems.append(f'{name} leaks a value from your local config.env')
                    break

        if kind == 'vercel-dashboard':
            try:
                config = loads(zip_file.read('vercel.json'))
                notes.append(f"vercel.json parses (crons: {len(config.get('crons', []))}, "
                             f"rewrites: {len(config.get('rewrites', []))})")
            except Exception as e:
                problems.append(f'vercel.json invalid: {e}')

        if kind in ('runtime', 'web-selector'):
            api = zip_file.read('web/api.py').decode('utf-8', errors='ignore')
            for token in ('create_api_blueprint', '/api/health', '/api/torrents'):
                if token not in api:
                    problems.append(f'web/api.py is missing {token}')

        if kind == 'runtime':
            entrypoint = zip_file.read('deploy/paas/entrypoint.sh').decode('utf-8', errors='ignore')
            for token in ('config.env', 'BASE_URL_PORT', 'exec bash start.sh'):
                if token not in entrypoint:
                    problems.append(f'entrypoint.sh is missing {token}')
            keys = zip_file.read('deploy/paas/config.keys').decode('utf-8').split()
            notes.append(f'{len(keys)} config keys in the entrypoint allowlist')
            for needed in ('BOT_TOKEN', 'DATABASE_URL', 'BASE_URL'):
                if needed not in keys:
                    problems.append(f'config.keys lacks {needed}')
            notes.append(f'{len(names)} files, bot + web + daemons in one image')

    return kind, problems, notes


def main():
    parser = ArgumentParser(description='Validate the packages generated by build_packages.py.')
    parser.add_argument('--dist', default=str(ROOT / 'deploy' / 'dist'))
    args = parser.parse_args()

    dist = Path(args.dist).resolve()
    archives = sorted(dist.glob('*.zip'))
    if not archives:
        print(f'No packages found in {dist} - run: python deploy/build_packages.py')
        return 1

    secrets = local_secrets()
    print(f'Verifying {len(archives)} package(s) in {dist}')
    print(f'Guard values taken from local config.env: {len(secrets)}\n')

    failures = 0
    for archive in archives:
        kind, problems, notes = verify(archive, secrets)
        size = archive.stat().st_size / 1024
        print(f'[{"FAIL" if problems else " ok "}] {archive.name}  ({size:.1f} KB, {kind or "unknown"})')
        for note in notes:
            print(f'        - {note}')
        for problem in problems:
            print(f'        ! {problem}')
        failures += bool(problems)

    print()
    if failures:
        print(f'{failures} package(s) need attention before deploying.')
        return 1
    print('All packages look deployable.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

