#!/usr/bin/env node
// Integration tests for the Vercel control plane: admin config, per-component pull and
// the bot's write-back. No Atlas needed - the store's collection is swapped for an
// in-memory double, so the real encryption, hashing and merge logic all still run.
//
//   node deploy/test_config_service.js
//
// The two CLOBBER tests matter most: they cover the two places where a naive two-way
// sync would silently destroy settings.
'use strict';
process.env.CONFIG_MASTER_KEY = process.env.CONFIG_MASTER_KEY || 'unit-test-master-key-0001';
process.env.ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'admin-test-token-0001';

const path = require('path');
const API = path.join(__dirname, '..', 'vercel-dashboard', 'api');
const store = require(path.join(API, '_store.js'));
const schema = require(path.join(API, 'schema.json'));

let passed = 0;
let failed = 0;
function check(name, condition, detail) {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${name}`);
  } else {
    failed += 1;
    console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ''}`);
  }
}

// --- minimal in-memory Mongo collection double -----------------------------
function fakeCollection() {
  const docs = new Map();
  const matches = (doc, filter) =>
    Object.entries(filter || {}).every(([k, v]) =>
      v instanceof RegExp ? v.test(doc[k]) : doc[k] === v);
  return {
    docs,
    async findOne(filter) {
      for (const doc of docs.values()) if (matches(doc, filter)) return { ...doc };
      return null;
    },
    async find(filter) {
      const rows = [...docs.values()].filter((d) => matches(d, filter)).map((d) => ({ ...d }));
      return { toArray: async () => rows };
    },
    async updateOne(filter, update, options = {}) {
      let doc = [...docs.values()].find((d) => matches(d, filter));
      if (!doc) {
        if (!options.upsert) return { matchedCount: 0 };
        doc = { ...filter };
        docs.set(doc._id, doc);
      }
      Object.assign(doc, update.$set || {});
      return { matchedCount: 1 };
    },
    async insertOne(doc) {
      docs.set(doc._id, { ...doc });
      return { insertedId: doc._id };
    },
  };
}

// --- fake Vercel req/res ----------------------------------------------------
function fakeRes() {
  return {
    statusCode: 0,
    body: null,
    headers: {},
    setHeader(k, v) { this.headers[k] = v; },
    status(code) { this.statusCode = code; return this; },
    send(payload) { this.body = payload; return this; },
  };
}

async function call(handler, opts) {
  const options = opts || {};
  const res = fakeRes();
  await handler(
    { method: options.method || 'GET', query: options.query || {}, headers: options.headers || {}, body: options.body || null },
    res,
  );
  // Vercel's res.send() hands the handler a JSON *string*; parse it the way fetch would.
  if (typeof res.body === 'string') {
    try {
      res.body = JSON.parse(res.body);
    } catch (e) {
      res.body = { raw: res.body };
    }
  }
  return res;
}

async function main() {
  const col = fakeCollection();
  store.__overrideCollection(col);
  const adminHeaders = { 'x-admin-token': process.env.ADMIN_TOKEN };
  delete process.env.BOT_ID; // no live bot in this harness, so drift reads as "not set"
  const URI = 'mongodb+srv://u:p@cluster.mongodb.net/';
  const BOT_TOKEN = '123456:AAF-real-looking-token';
  const GW_TOKEN = 'gateway-secret-token';

  console.log('\nencryption + token storage');
  const blob = store.encryptValue(URI);
  check('ciphertext does not contain the plaintext', !blob.includes('mongodb'));
  check('decrypt round-trips', store.decryptValue(blob) === URI);
  check('ciphertext carries a version prefix', blob.startsWith('v1.'));
  const tamper = (() => {
    const saved = process.env.CONFIG_MASTER_KEY;
    process.env.CONFIG_MASTER_KEY = 'a-completely-different-key';
    try {
      store.decryptValue(blob);
      return 'decrypted';
    } catch (e) {
      return 'rejected';
    } finally {
      process.env.CONFIG_MASTER_KEY = saved;
    }
  })();
  check('a different CONFIG_MASTER_KEY cannot decrypt', tamper === 'rejected', tamper);
  const hash = store.hashToken('acc1', 'secret-token');
  check('token hash is not the token', hash !== 'secret-token');
  check('correct token verifies', store.tokenMatches('acc1', 'secret-token', hash));
  check('wrong token rejected', !store.tokenMatches('acc1', 'nope', hash));
  check('empty token rejected', !store.tokenMatches('acc1', '', hash));

  console.log('\ncomponents: create, rotate, authenticate');
  const acc1 = await store.createComponent('acc1', 'runtime', 'https://a.example.app/');
  check('create returns a 64-char token once', typeof acc1.token === 'string' && acc1.token.length === 64);
  check('url normalised without trailing slash', acc1.url === 'https://a.example.app');
  check('stored document holds a hash, not the token',
    !JSON.stringify(col.docs.get('component:acc1')).includes(acc1.token));
  const gateway = await store.createComponent('gw', 'gateway', 'https://gw.example.app');
  await store.createComponent('box', 'daemons', 'http://10.0.0.5:8090');
  check('authenticate accepts the right token', Boolean(await store.authenticate('acc1', acc1.token)));
  check('authenticate rejects a bad token', !(await store.authenticate('acc1', 'wrong')));
  check('authenticate rejects an unknown component', !(await store.authenticate('ghost', 'x')));
  const rotated = await store.rotateToken('acc1');
  check('rotation issues a different token', rotated.token !== acc1.token);
  check('old token stops working', !(await store.authenticate('acc1', acc1.token)));
  check('new token works', Boolean(await store.authenticate('acc1', rotated.token)));
  const acc1Token = rotated.token;
  const listed = await store.listComponents();
  check('list never exposes a token', listed.every((c) => c.token === undefined));
  check('list reports has_token', listed.every((c) => c.has_token === true));
  check('duplicate component name is refused',
    await store.createComponent('acc1', 'runtime', 'https://dup.app').then(() => false, () => true));
  check('an invalid component name is refused',
    await store.createComponent('bad name!', 'runtime', 'https://x.app').then(() => false, () => true));
  check('an invalid role is refused',
    await store.createComponent('okname', 'superuser', 'https://x.app').then(() => false, () => true));

  console.log('\nconfig write + per-component pull isolation');
  await store.writeConfig({
    BOT_TOKEN, DATABASE_URL: URI, STATUS_LIMIT: '10',
    GATEWAY_TOKEN: GW_TOKEN, ARIA2_SECRET: 'aria-secret-token',
  }, 'vercel');
  const cfg = await store.readConfig();
  check('version advanced to 1', cfg.version === 1);
  check('values decrypt on read', cfg.values.BOT_TOKEN === BOT_TOKEN);
  check('source recorded per key', cfg.meta.BOT_TOKEN.source === 'vercel');
  const raw = JSON.stringify([...col.docs.values()]);
  check('bot token unreadable in the raw document', !raw.includes('AAF-real-looking-token'));
  check('gateway token unreadable in the raw document', !raw.includes(GW_TOKEN));

  const resolve = require(path.join(API, 'resolve.js'));
  const asRuntime = await call(resolve, { query: { component: 'acc1' }, headers: { 'x-component-token': acc1Token } });
  check('runtime pull succeeds', asRuntime.statusCode === 200, JSON.stringify(asRuntime.body).slice(0, 160));
  const rv = (asRuntime.body && asRuntime.body.values) || {};
  check('runtime gets its own bot token', rv.BOT_TOKEN === BOT_TOKEN);
  check('runtime does NOT get the gateway token', rv.GATEWAY_TOKEN === undefined);
  check('runtime does NOT get the aria2 secret', rv.ARIA2_SECRET === undefined);
  check('pull reports the config version', asRuntime.body.config_version === 1);
  check('pull echoes its role', asRuntime.body.role === 'runtime');

  const asGateway = await call(resolve, { query: { component: 'gw' }, headers: { 'x-component-token': gateway.token } });
  const gv = (asGateway.body && asGateway.body.values) || {};
  check('gateway gets its own token', gv.GATEWAY_TOKEN === GW_TOKEN);
  check('gateway does NOT get the bot token', gv.BOT_TOKEN === undefined);
  check('gateway does NOT get the mongo uri', gv.DATABASE_URL === undefined);

  const noToken = await call(resolve, { query: { component: 'acc1' } });
  check('pull without a token is 401', noToken.statusCode === 401);
  check('401 response leaks nothing', !JSON.stringify(noToken.body).includes('BOT_TOKEN'));

  const configApi = require(path.join(API, 'config.js'));
  console.log('\nsecret keys must be announced to the browser (regression: secret not sent)');
  const tgHash = '0123456789abcdef0123456789abcdef';
  const hashSave = await call(configApi, {
    method: 'POST', headers: adminHeaders, body: { values: { TELEGRAM_HASH: tgHash } },
  });
  check('a secret saves', hashSave.statusCode === 200, JSON.stringify(hashSave.body).slice(0, 120));
  const afterHash = await call(configApi, { headers: adminHeaders });
  const hashKey = afterHash.body.keys.TELEGRAM_HASH;
  // The page branches on `secret` to render a password box + mask. If the API omits
  // it the browser shows an empty plain field labelled "unknown", which is exactly
  // the bug this guards against.
  check('API tells the browser the key is secret', hashKey.secret === true, JSON.stringify(hashKey));
  check('API reports it as configured', hashKey.configured === true);
  check('API returns a mask, never the value', typeof hashKey.mask === 'string' && !JSON.stringify(hashKey).includes(tgHash));
  check('the stored secret is readable server-side', (await store.readConfig()).values.TELEGRAM_HASH === tgHash);
  check('a secret never carries a plaintext value', !('value' in hashKey));
  check('a secret never carries a drift verdict', !('drift' in hashKey));
  const plainKey = afterHash.body.keys.STATUS_LIMIT;
  check('plain keys are announced as NOT secret', plainKey.secret === false);
  check('plain keys still carry drift', typeof plainKey.drift === 'string');

  console.log('\nadmin API: masked reads, __KEEP__, bad input');
  const view = await call(configApi, { headers: adminHeaders });
  check('admin GET works', view.statusCode === 200);
  check('secret reported as configured', view.body.keys.BOT_TOKEN.configured === true);
  check('secret returned as a mask, never the value', !JSON.stringify(view.body).includes('AAF-real-looking-token'));
  check('mask reveals only the last 4 characters', view.body.keys.BOT_TOKEN.mask.endsWith('oken'));
  check('plain key returns its value', view.body.keys.STATUS_LIMIT.value === '10');
  check('drift is honestly "unknown" when no bot is attached',
    view.body.keys.STATUS_LIMIT.drift === 'unknown', view.body.keys.STATUS_LIMIT.drift);
  check('the page is told the bot is not reachable', view.body.bot_reachable === false);
  check('admin GET without the admin token is 401',
    (await call(configApi, { headers: { 'x-admin-token': 'wrong' } })).statusCode === 401);

  const keep = await call(configApi, {
    method: 'POST', headers: adminHeaders, body: { values: { BOT_TOKEN: '__KEEP__', STATUS_LIMIT: '25' } },
  });
  check('save with __KEEP__ succeeds', keep.statusCode === 200, JSON.stringify(keep.body).slice(0, 160));
  const afterKeep = await store.readConfig();
  check('__KEEP__ left the bot token intact', afterKeep.values.BOT_TOKEN === BOT_TOKEN);
  check('the other key really changed', afterKeep.values.STATUS_LIMIT === '25');
  check('version advanced past the previous one', afterKeep.version > cfg.version, `${afterKeep.version} vs ${cfg.version}`);
  check('untouched key keeps its original timestamp', afterKeep.meta.BOT_TOKEN.at === cfg.meta.BOT_TOKEN.at);
  check('unknown key rejected',
    (await call(configApi, { method: 'POST', headers: adminHeaders, body: { values: { NOT_A_KEY: 'x' } } })).statusCode === 400);
  check('absurdly short secret rejected',
    (await call(configApi, { method: 'POST', headers: adminHeaders, body: { values: { BOT_TOKEN: 'abc' } } })).statusCode === 400);
  check('null clears a key',
    (await call(configApi, { method: 'POST', headers: adminHeaders, body: { values: { ARIA2_SECRET: null } } })).statusCode === 200);
  check('cleared key is gone', (await store.readConfig()).values.ARIA2_SECRET === undefined);

  console.log('\nCLOBBER TEST 1: a dashboard save survives a bot restart');
  await store.writeConfig({ STATUS_LIMIT: '40' }, 'vercel');
  const saved = await store.readConfig();
  check('dashboard value stored', saved.values.STATUS_LIMIT === '40');
  // exactly what a container restart does: pull again, then load it
  const restartPull = await call(resolve, { query: { component: 'acc1' }, headers: { 'x-component-token': acc1Token } });
  check('restart pull returns the saved value', restartPull.body.values.STATUS_LIMIT === '40');
  check('restart pull sees the new version', restartPull.body.config_version === saved.version);
  check('component is now up to date', (await store.getComponent('acc1')).config_version === saved.version);
  check('a second pull does not change the stored value', (await store.readConfig()).values.STATUS_LIMIT === '40');

  console.log('\nCLOBBER TEST 2: a bot boot does NOT push its config back');
  // db_load() writes every in-memory key on every boot. Syncing that would let each
  // restart overwrite the dashboard with the bot's stale view - the exact bug this guards.
  const bootSnapshot = { STATUS_LIMIT: '99', AUTHOR_NAME: 'stale bot' };
  const pullAfterBoot = await call(resolve, { query: { component: 'acc1' }, headers: { 'x-component-token': acc1Token } });
  check('bot still sees the dashboard value after boot', pullAfterBoot.body.values.STATUS_LIMIT === '40',
    String(pullAfterBoot.body.values.STATUS_LIMIT));
  const storeAfterBoot = await store.readConfig();
  check('dashboard value not overwritten by a boot', storeAfterBoot.values.STATUS_LIMIT === '40');

  console.log('\ntwo-way push: a Telegram /settings edit reaches the dashboard');
  const push = require(path.join(API, 'push.js'));
  const pushed = await call(push, {
    method: 'POST', headers: { 'x-component-token': acc1Token },
    body: { component: 'acc1', values: { LEECH_SPLIT_SIZE: '4194304000', IMAGES: "['a.jpg', 'b.jpg']" } },
  });
  check('push succeeds', pushed.statusCode === 200, JSON.stringify(pushed.body).slice(0, 160));
  check('push reports how many keys changed', pushed.body.changed === 2);
  check('push is attributed to telegram', (await store.readConfig()).meta.LEECH_SPLIT_SIZE.source === 'telegram');
  check('a list value survives as the same string form',
    (await store.readConfig()).values.IMAGES === "['a.jpg', 'b.jpg']");
  const boolPush = await call(push, {
    method: 'POST', headers: { 'x-component-token': acc1Token }, body: { component: 'acc1', values: { SAVE_MSG: false } },
  });
  check('a bool round-trips as False, the form the bot already stores',
    boolPush.statusCode === 200 && (await store.readConfig()).values.SAVE_MSG === 'False',
    String((await store.readConfig()).values.SAVE_MSG));
  check('a pushed value reaches the next pull',
    (await call(resolve, { query: { component: 'acc1' }, headers: { 'x-component-token': acc1Token } }))
      .body.values.SAVE_MSG === 'False');

  console.log('\ntwo-way push: a bot may not write outside its own role');
  const crossRole = await call(push, {
    method: 'POST', headers: { 'x-component-token': acc1Token },
    body: { component: 'acc1', values: { GATEWAY_TOKEN: 'stolen', ARIA2_SECRET: 'stolen' } },
  });
  check('cross-role push changes nothing', crossRole.body.changed === 0);
  check('gateway token untouched by the bot', (await store.readConfig()).values.GATEWAY_TOKEN === GW_TOKEN);
  check('rejected keys are reported back to the caller', crossRole.body.rejected.includes('GATEWAY_TOKEN'));
  check('push without a token is 401',
    (await call(push, { method: 'POST', body: { component: 'acc1', values: { A: '1' } } })).statusCode === 401);
  check('a token belonging to another component is rejected',
    (await call(push, { method: 'POST', headers: { 'x-component-token': gateway.token },
      body: { component: 'acc1', values: { BOT_TOKEN: 'hijack' } } })).statusCode === 401);
  check('bot token still original after the hijack attempt',
    (await store.readConfig()).values.BOT_TOKEN === BOT_TOKEN);
  check('GET to the push endpoint is refused',
    (await call(push, { query: { component: 'acc1' } })).statusCode === 405);

  console.log('\ncomponent status');
  const report = require(path.join(API, 'report.js'));
  const status = await call(report, { headers: adminHeaders });
  check('report lists every component', status.body.components.length === 3);
  const acc1Row = status.body.components.find((c) => c.name === 'acc1');
  check('acc1 up to date after pulling', acc1Row.up_to_date === true, JSON.stringify(acc1Row).slice(0, 160));
  check('acc1 reports no error', ['ok', 'idle'].includes(acc1Row.state), acc1Row.state);
  check('gateway is stale because it never pulled',
    status.body.components.find((c) => c.name === 'gw').up_to_date === false);
  check('report never includes a token', !JSON.stringify(status.body).includes(acc1Token));
  check('report requires the admin token', (await call(report)).statusCode === 401);

  console.log('\nschema sanity');
  check('all three roles have keys', ['runtime', 'gateway', 'daemons'].every((r) => schema.components[r].length));
  check('bot token marked secret', schema.keys.BOT_TOKEN.secret === true);
  const creds = ['BOT_TOKEN', 'DATABASE_URL', 'TELEGRAM_HASH'];
  check('daemons scope has no bot credentials', !schema.components.daemons.some((k) => creds.includes(k)));
  check('gateway scope has no bot credentials', !schema.components.gateway.some((k) => creds.includes(k)));

  console.log(`\n${passed} passed, ${failed} failed\n`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('harness error:', e);
  process.exit(1);
});
