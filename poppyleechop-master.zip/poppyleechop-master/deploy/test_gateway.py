#!/usr/bin/env python3
"""Live smoke test for the Deplexo/SnapDeploy control-plane gateway (deploy/paas/api-gateway).

    python deploy/test_gateway.py

Starts the repo's web app (as the "runtime") and the gateway in front of it, then checks the
aggregated status and the whitelisted pass-through. Writes both logs to deploy/.
"""

from json import loads
from os import environ
from pathlib import Path
from subprocess import Popen
from sys import executable
from time import sleep, time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
GATEWAY = ROOT / 'deploy' / 'paas' / 'api-gateway'
RUNTIME_PORT = environ.get('TEST_RUNTIME_PORT', '5097')
GATEWAY_PORT = environ.get('TEST_GATEWAY_PORT', '5096')
RUNTIME_TOKEN = 'runtime-smoke-token'
GATEWAY_TOKEN = 'gateway-smoke-token'


def call(port, path, token=None, method='GET'):
    request = Request(f'http://127.0.0.1:{port}{path}', method=method)
    if token:
        request.add_header('X-API-Token', token)
    try:
        with urlopen(request, timeout=15) as response:
            return response.status, response.read().decode('utf-8', 'ignore')
    except HTTPError as e:
        return e.code, e.read().decode('utf-8', 'ignore')
    except URLError as e:
        return 0, str(e)


def wait_for(port, path, timeout=45):
    deadline = time() + timeout
    while time() < deadline:
        if call(port, path)[0] == 200:
            return True
        sleep(1)
    return False


def main():
    open(ROOT / 'deploy' / 'gateway-runtime.log', 'wb').close()
    runtime_log = open(ROOT / 'deploy' / 'gateway-runtime.log', 'wb')
    gateway_log = open(ROOT / 'deploy' / 'gateway.log', 'wb')

    runtime = Popen([executable, '-m', 'web.wserver'],
                    cwd=ROOT,
                    env=dict(environ, API_TOKEN=RUNTIME_TOKEN, PORT=RUNTIME_PORT, SYNC_CONFIG_ENV='false'),
                    stdout=runtime_log, stderr=runtime_log)

    gateway_env = dict(environ,
                       GATEWAY_TOKEN=GATEWAY_TOKEN,
                       PORT=GATEWAY_PORT,
                       RUNTIMES=f'acc1=http://127.0.0.1:{RUNTIME_PORT}|{RUNTIME_TOKEN},'
                                f'acc2=http://127.0.0.1:1|{RUNTIME_TOKEN}')
    gateway = Popen([executable, 'app.py'], cwd=GATEWAY, env=gateway_env,
                    stdout=gateway_log, stderr=gateway_log)

    try:
        if not wait_for(RUNTIME_PORT, '/healthz'):
            print('runtime never started (deploy/gateway-runtime.log)')
            return 1
        if not wait_for(GATEWAY_PORT, '/healthz'):
            print('gateway never started (deploy/gateway.log)')
            return 1

        results = []
        for label, path, token, allowed in (
            ('gateway healthz', '/healthz', None, {200}),
            ('gateway index lists runtimes', '/', None, {200}),
            ('runtimes needs the token', '/api/v1/runtimes', None, {401}),
            ('runtimes lists acc1 + acc2', '/api/v1/runtimes', GATEWAY_TOKEN, {200}),
            ('status aggregates both', '/api/v1/status', GATEWAY_TOKEN, {200}),
            ('pass-through health', '/api/v1/acc1/health', GATEWAY_TOKEN, {200}),
            ('pass-through torrents', '/api/v1/acc1/torrents', GATEWAY_TOKEN, {200}),
            ('pass-through stats', '/api/v1/acc1/stats', GATEWAY_TOKEN, {200}),
            ('unknown runtime is 404', '/api/v1/nope/health', GATEWAY_TOKEN, {404}),
            ('unlisted path is 404', '/api/v1/acc1/secrets', GATEWAY_TOKEN, {404}),
            ('bad action is rejected', '/api/v1/acc1/torrents/deadbeefdeadbeef/wipe', GATEWAY_TOKEN, {404}),
        ):
            status, body = call(GATEWAY_PORT, path, token)
            results.append((label, status in allowed, status, body[:150]))

        print('Control-plane gateway smoke test')
        for label, passed, status, body in results:
            print(f'  [{"PASS" if passed else "FAIL"}] {label}  -> HTTP {status}  {body}')

        status_body = loads(call(GATEWAY_PORT, '/api/v1/status', GATEWAY_TOKEN)[1])
        totals = status_body.get('totals', {})
        print(f"  info: totals={totals}")
        down = [r['name'] for r in status_body.get('runtimes', []) if not r.get('up')]
        print(f'  info: unreachable runtimes (expected: acc2) = {down}')
        if 'acc2' not in down:
            results.append(('dead runtime reported as down', False, '-', 'acc2 was up?'))

        failures = [label for label, passed, _, _ in results if not passed]
        print()
        if failures:
            print(f'{len(failures)} check(s) failed: {failures}')
            return 1
        print('All gateway checks passed (dashboard -> gateway -> runtime works).')
        return 0
    finally:
        for process in (gateway, runtime):
            process.terminate()
            try:
                process.wait(timeout=10)
            except Exception:
                process.kill()
        runtime_log.close()
        gateway_log.close()


if __name__ == '__main__':
    raise SystemExit(main())
