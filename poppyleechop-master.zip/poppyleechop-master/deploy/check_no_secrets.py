#!/usr/bin/env python3
"""Scan every built package for any real credential from config.env.

Independent of build_packages.py's own check: this reads the zips fresh from disk so a
packaging bug cannot hide a leak from itself.

    python deploy/check_no_secrets.py [deploy/dist]
"""

import re
import sys
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent.parent

# Only genuine credentials. Ordinary values like TIMEZONE or DOWNLOAD_DIR are part of
# the source code by design, so searching for those would only produce false positives.
SECRET_KEYS = ('BOT_TOKEN', 'TELEGRAM_HASH', 'TELEGRAM_API', 'DATABASE_URL',
               'USER_SESSION_STRING', 'MEGA_PASSWORD', 'MEGA_EMAIL', 'GDRIVE_ID',
               'OWNER_ID', 'LOGIN_PASS', 'JIODRIVE_TOKEN', 'GDTOT_CRYPT',
               'REAL_DEBRID_API', 'DEBRID_LINK_API', 'FILELION_API')


def secrets_from_config():
    text = (ROOT / 'config.env').read_text(encoding='utf-8', errors='ignore')
    found = {}
    for key, value in re.findall(r'([A-Z][A-Z0-9_]*)\s*=\s*"([^"]*)"', text):
        if key in SECRET_KEYS and len(value) >= 8:
            found[key] = value
    return found


def main():
    dist = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT / 'deploy' / 'dist').resolve()
    needles = secrets_from_config()
    if not needles:
        print('no real credentials found in config.env - nothing to check')
        return 0
    print(f'checking {len(needles)} credential(s) from config.env against every file in {dist.name}/')
    leaks = []
    archives = sorted(dist.glob('*.zip'))
    if not archives:
        print('no packages found - run deploy/build_packages.py first')
        return 1
    for archive in archives:
        with ZipFile(archive) as zf:
            for name in zf.namelist():
                try:
                    blob = zf.read(name).decode('utf-8')
                except (UnicodeDecodeError, KeyError, IsADirectoryError):
                    continue
                for key, value in needles.items():
                    if value in blob:
                        leaks.append(f'{archive.name} -> {name} contains {key}')
        print(f'  scanned {archive.name} ({len(ZipFile(archive).namelist())} entries)')
    if leaks:
        print('\nLEAKS FOUND:')
        for leak in leaks:
            print(f'  - {leak}')
        return 1
    print('\nOK: no real credential from config.env appears in any package.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
