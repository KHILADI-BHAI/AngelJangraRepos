#!/usr/bin/env python3
"""Live smoke test for the control API in web/api.py.

    python deploy/test_control_api.py

Starts `python -m web.wserver` in a subprocess with a known API_TOKEN and PORT, waits for
/healthz, then checks every route including the auth boundary. Works on Windows (no gunicorn
needed) and writes the server output to deploy/api-smoke.log.
"""

from json import loads
from os import environ
from pathlib import Path
from subprocess import Popen
from sys import executable
from time import sleep, time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT = environ.get('TEST_PORT', '5098')
TOKEN = 'local-smoke-test-token'
BOGUS_ARIA_ID = 'deadbeefdeadbeef'


def call(path, token=None, method='GET'):
    request = Request(f'http://127.0.0.1:{PORT}{path}', method=method)
    if token:
        request.add_header('X-API-Token', token)
    try:
        with urlopen(request, timeout=15) as response:
            return response.status, response.read().decode('utf-8', 'ignore')
    except HTTPError as e:
        return e.code, e.read().decode('utf-8', 'ignore')
    except URLError as e:
        return 0, str(e)


def main():
    env = dict(environ, API_TOKEN=TOKEN, PORT=PORT, PYTHONUNBUFFERED='1', SYNC_CONFIG_ENV='false')
    log_path = ROOT / 'deploy' / 'api-smoke.log'
    log = open(log_path, 'wb')
    proc = Popen([executable, '-m', 'web.wserver'], cwd=ROOT, env=env, stdout=log, stderr=log)

    results = []
    try:
        deadline = time() + 45
        while time() < deadline:
            if call('/healthz')[0] == 200:
                break
            sleep(1)
        else:
            print(f'Server never answered on port {PORT}. See {log_path}')
            return 1

        for label, path, token, method, allowed in (
            ('healthz returns plain ok', '/healthz', None, 'GET', {200}),
            ('api/health is public JSON', '/api/health', None, 'GET', {200}),
            ('api/stats rejects missing token', '/api/stats', None, 'GET', {401}),
            ('api/stats rejects wrong token', '/api/stats', 'nope', 'GET', {401}),
            ('api/stats accepts the token', '/api/stats', TOKEN, 'GET', {200}),
            ('api/torrents needs the token', '/api/torrents', None, 'GET', {401}),
            ('api/torrents lists tasks', '/api/torrents', TOKEN, 'GET', {200}),
            ('api/torrents rejects unknown action', f'/api/torrents/{BOGUS_ARIA_ID}/bogus', TOKEN, 'POST', {400}),
            ('api/torrents handles a dead gid', f'/api/torrents/{BOGUS_ARIA_ID}/cancel', TOKEN, 'POST', {200, 502}),
        ):
            status, body = call(path, token, method)
            results.append((label, status in allowed, status, body[:160]))

        print('Control API smoke test')
        print(f'  server: {executable} -m web.wserver  (port {PORT})')
        for label, passed, status, body in results:
            print(f'  [{"PASS" if passed else "FAIL"}] {label}  -> HTTP {status}  {body}')

        health = loads(call('/api/health')[1])
        daemons = health.get('daemons', {})
        print(f"  info: aria2 up={daemons.get('aria2', {}).get('up')} "
              f"qbittorrent up={daemons.get('qbittorrent', {}).get('up')} "
              f"disk free={health.get('host', {}).get('disk', {}).get('free', 'n/a')}")

        failures = [label for label, passed, _, _ in results if not passed]
        print()
        if failures:
            print(f'{len(failures)} check(s) failed: {failures}')
            return 1
        print('All control API checks passed.')
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:
            proc.kill()
        log.close()


if __name__ == '__main__':
    raise SystemExit(main())
