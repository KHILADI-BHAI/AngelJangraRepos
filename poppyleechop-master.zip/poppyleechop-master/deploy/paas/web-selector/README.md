# WZML-X web selector (separate-account package)

This is the repo's `web/` package packaged on its own, for when you want the torrent
file-selection page (and the `/api/*` control API) to live on a **different account or
platform** than the bot itself.

It is safe to separate because `web/wserver.py` never imports the bot: it talks to the
aria2 RPC and the qBittorrent WebUI directly. Point it at any reachable daemons:

| Environment | Meaning |
| --- | --- |
| `ARIA2_HOST` / `ARIA2_PORT` / `ARIA2_SECRET` | aria2 RPC endpoint (`https://host` or `host`) |
| `QBIT_HOST` / `QBIT_PORT` / `QBIT_USERNAME` / `QBIT_PASSWORD` | qBittorrent WebUI endpoint |
| `DOWNLOAD_DIR` | same absolute path the daemons write to (file tree parsing) |
| `API_TOKEN` | enables `/api/stats`, `/api/torrents`, actions (`/api/health` stays public) |
| `BASE_URL` / `BASE_URL_PORT` / `PORT` | this container's own address and routed port |

Build with `Dockerfile` in this folder (`framework: dockerfile` for Deplexo), set `PORT`
to the platform's routed port, and point the bot's `BASE_URL` at this app instead of at
its own host if you prefer a single public entry point.

Endpoints: `GET /`, `GET /healthz`, `GET /api/health`, `GET|POST /app/files/<id>`,
and the token-protected `/api/stats`, `/api/torrents`, `/api/torrents/clear`,
`POST /api/torrents/<id>/{pause,resume,cancel}`.
