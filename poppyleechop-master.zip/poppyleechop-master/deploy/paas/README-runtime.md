# Deploy this package: WZML-X runtime (bot + aria2 + qBittorrent in ONE container)

Package contents are ready to push to a Git repo or upload as-is. `Dockerfile`,
`deplexo.yaml` and `deploy/paas/entrypoint.sh` are already wired.

## Why everything is in one container

`aria2c` and `qbittorrent-nox` must write to the **same absolute path** the bot later
reads, unpacks, splits and uploads. Managed platforms give each container an ephemeral

reads, unpacks, splits and uploads. Managed platforms give each container an ephemeral
disk and no NFS/SMB, so splitting the bot away from its daemons across hosts only works if
you own a shared network mount. On PaaS: keep them together (this package), and scale out
by deploying **one bot per account** with its own Telegram token (`/clone`), not by
splitting one bot.

## Steps

1. Push this package to its own GitHub repository (or a folder of one).
2. On the platform: **New app -> Docker / Dockerfile build**.
3. Set the environment variables from `.env.example`.
4. `PORT` is what the platform routes to; the entrypoint copies it into `BASE_URL_PORT`
   so the web file selector + control API listen on the right port.
5. `BASE_URL` must be the public HTTPS URL of **this** app, e.g.
   `https://your-app.snapdeploy.app` - the bot uses it for the "Select Files" button.
6. Deploy, then open `https://<app>/healthz` (expect `ok`) and `https://<app>/api/health`.

## Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `BOT_TOKEN` | yes | unique per container; a second copy of the same token = 409 Conflict |
| `OWNER_ID`, `TELEGRAM_API`, `TELEGRAM_HASH` | yes | as usual |
| `DATABASE_URL` | strongly advised | MongoDB Atlas M0; restores settings, users, rss and tokens |
| `API_TOKEN` | yes | protects `/api/stats`, `/api/torrents`, actions |
| `BASE_URL` | yes | public URL of this app; without it the web app is not started |
| `PORT` | set by platform | routed port, e.g. `8080` / `3000` |
| `DOWNLOAD_DIR` | default ok | `/usr/src/app/downloads/` - must match the daemons |
| `EXTERNAL_DAEMONS` | **must stay `false`** | `true` means "daemons live elsewhere" and the bot will not start aria2/qBittorrent |
| `SYNC_CONFIG_ENV` | default `true` | rebuilds `config.env` from these env vars at boot |

Strongly recommended: `GDRIVE_ID` or `RCLONE_PATH`, `DEFAULT_UPLOAD`, `CMD_SUFFIX`.

## Gotchas this package already handles

- `config.env` is in `.gitignore`, so a Git deploy has none; `bot/__init__.py` does
  `load_dotenv('config.env', override=True)` and compares that file against Mongo
  `settings.deployConfig`. The entrypoint regenerates it from your env vars, so settings
  stored by `/settings` keep working. The key list is `deploy/paas/config.keys`.
- Managed platforms only route HTTP to `$PORT`; the bot would otherwise bind port 80.
- **Keep `UPSTREAM_REPO` empty.** `update.py` runs `git reset --hard` against it on every
  start, which would throw away this split-deployment code.
- The `.dockerignore` here excludes `.venv` (315 MB), `qBittorrent/` (270 MB), sessions and
  logs, so builds are fast instead of uploading gigabytes.

## Limits to plan around

- SnapDeploy Free: 512 MB, **auto-sleeps after ~15 min without HTTP traffic** (a Telegram
  bot makes none), 100 container-hours/month → use a 5-minute uptime monitor on
  `/api/health`, or Always-On ($12/mo Small, $25/mo Medium).
- Deplexo: Free is 128 MB/250 MB (too small); Starter $5 (512 MB/2 GB) or Pro $10 (1 GB/10 GB).
- Neither offers persistent volumes: downloads, thumbnails and sessions are lost on
  redeploy. `DATABASE_URL` (Atlas) is what keeps settings and tokens alive; large mirrors
  should be consumed and uploaded inside one task.
