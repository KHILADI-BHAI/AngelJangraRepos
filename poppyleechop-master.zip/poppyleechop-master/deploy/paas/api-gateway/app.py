"""WZML-X control-plane gateway.

Stateless, ~60 MB RSS: it holds no downloads, no database and no files, so it fits
even a Deplexo Free container (128 MB / 250 MB disk). Its job is to give the
dashboard ONE stable API in front of many runtime containers that live on several
accounts (SnapDeploy acc1/acc2/..., Deplexo, a VPS...):

    dashboard (Vercel)  ->  this gateway  ->  runtime N  ->  /api/* (web/api.py)

It never exposes the per-runtime API tokens to the browser: the dashboard
authenticates with GATEWAY_TOKEN and the gateway adds each runtime's own token.

Config (environment):
    GATEWAY_TOKEN   shared secret the dashboard sends as X-API-Token / Bearer
    RUNTIMES        "name=url|token,name2=url|token2" (the |token part is optional)
    UPSTREAM_TIMEOUT seconds, default 10
    PORT            set by the platform, default 8080

The gateway is a "gateway" component on the Vercel control plane, so it can be created
and rotated from the settings page like every other part. To let it fetch its own
config at start, set only:

    COMPONENT_ID=gw
    COMPONENT_TOKEN=<one-time token from the settings page>

With those present it calls /api/resolve on boot and takes RUNTIMES / GATEWAY_TOKEN
from there, so you never paste the per-runtime tokens into this container.
"""

import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from hmac import compare_digest
from os import environ
from re import fullmatch
from time import time

from flask import Flask, jsonify, request, Response
from requests import RequestException, get as rget, post as rpost

CONFIG_PULL = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config_pull.py')
DEFAULT_ORIGIN = 'https://poppyleechop.vercel.app'


def load_from_control_plane():
    """Fetch this container's config from Vercel before the app reads any env var.

    Returns True on success, False when sync is off. Never raises: a gateway that cannot
    reach the control plane should still start if its env already has the values.
    """
    if not (environ.get('COMPONENT_ID', '').strip() and environ.get('COMPONENT_TOKEN', '').strip()):
        return False
    if not os.path.isfile(CONFIG_PULL):
        print('[gateway] config_pull.py not found, using the platform environment', flush=True)
        return False
    print('[gateway] fetching configuration from the control plane...', flush=True)
    result = subprocess.run(
        [sys.executable, CONFIG_PULL, '--print'],
        capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        print(f'[gateway] config pull failed: {result.stdout.strip() or result.stderr.strip()}', flush=True)
        return False
    count = 0
    for line in result.stdout.splitlines():
        if '=' not in line:
            continue
        key, _, value = line.partition('=')
        key = key.strip()
        if not key:
            continue
        environ[key] = value
        count += 1
    print(f'[gateway] loaded {count} value(s) from the control plane', flush=True)
    return True


load_from_control_plane()

app = Flask(__name__)

GATEWAY_TOKEN = environ.get('GATEWAY_TOKEN', '')
TIMEOUT = float(environ.get('UPSTREAM_TIMEOUT', '10'))
STARTED_AT = time()

GET_WHITELIST = ('health', 'stats', 'torrents')
POST_WHITELIST = ('torrents/clear',)
POST_PATTERN = r'torrents/[0-9a-fA-F]{16,40}/(pause|resume|cancel)'


def parse_runtimes():
    """RUNTIMES='acc1=https://a.snapdeploy.app|token,acc2=https://b.snapdeploy.app|token'"""
    runtimes = {}
    for chunk in environ.get('RUNTIMES', '').split(','):
        chunk = chunk.strip()
        if not chunk or '=' not in chunk:
            continue
        name, rest = chunk.split('=', 1)
        url, _, token = rest.partition('|')
        url = url.strip().rstrip('/')
        if not url:
            continue
        if not url.startswith('http'):
            url = f'https://{url}'
        runtimes[name.strip()] = {'url': url, 'token': token.strip()}
    return runtimes


RUNTIMES = parse_runtimes()


def _authorized():
    if not GATEWAY_TOKEN:
        return False
    sent = request.headers.get('X-API-Token', '') or request.args.get('token', '')
    if not sent:
        header = request.headers.get('Authorization', '')
        sent = header[7:] if header.lower().startswith('bearer ') else ''
    return compare_digest(sent, GATEWAY_TOKEN)


def _denied():
    return jsonify({'ok': False, 'error': 'unauthorized', 'hint': 'send the X-API-Token header'}), 401


def _runtime(name):
    runtime = RUNTIMES.get(name)
    if runtime is None:
        return None, (jsonify({'ok': False, 'error': f'unknown runtime {name}', 'known': list(RUNTIMES)}), 404)
    return runtime, None


def _probe(name, runtime):
    """One runtime's /api/health, never raising so a dead account cannot break the dashboard."""
    started = time()
    result = {'name': name, 'url': runtime['url'], 'up': False}
    try:
        res = rget(f"{runtime['url']}/api/health", timeout=TIMEOUT)
        result['status_code'] = res.status_code
        if res.headers.get('content-type', '').startswith('application/json'):
            result.update(res.json())
            result['up'] = bool(result.get('ok'))
        else:
            result['up'] = res.status_code == 200
    except RequestException as e:
        result['error'] = str(e)
    except ValueError as e:
        result['error'] = f'bad json: {e}'
    result['latency_ms'] = int((time() - started) * 1000)
    return result

@app.route('/healthz', methods=['GET'])
def healthz():
    """Bare 200 for platform health checks, uptime robots and the Vercel cron pinger."""
    return 'ok', 200


@app.route('/', methods=['GET'])
def index():
    return jsonify({
        'ok': True,
        'service': 'wzmlx-control-gateway',
        'uptime': int(time() - STARTED_AT),
        'runtimes': list(RUNTIMES),
        'endpoints': {
            'GET  /api/v1/runtimes': 'configured runtime names and urls',
            'GET  /api/v1/status': 'aggregated health of every runtime',
            'GET  /api/v1/<runtime>/health|stats|torrents': 'proxied to that runtime',
            'POST /api/v1/<runtime>/torrents/clear': 'purge finished entries',
            'POST /api/v1/<runtime>/torrents/<id>/pause|resume|cancel': 'act on one task',
        },
    })


@app.route('/api/v1/runtimes', methods=['GET'])
def runtimes():
    if not _authorized():
        return _denied()
    return jsonify({
        'ok': True,
        'runtimes': [{'name': name, 'url': cfg['url'], 'token': bool(cfg['token'])} for name, cfg in RUNTIMES.items()],
    })


@app.route('/api/v1/status', methods=['GET'])
def status():
    if not _authorized():
        return _denied()
    if RUNTIMES:
        with ThreadPoolExecutor(max_workers=min(8, len(RUNTIMES))) as pool:
            probed = list(pool.map(lambda item: _probe(*item), RUNTIMES.items()))
    else:
        probed = []
    up = [r for r in probed if r.get('up')]

    def _speed(entry, client, key):
        return entry.get('daemons', {}).get(client, {}).get(key, 0) or 0

    totals = {
        'runtimes': len(probed),
        'up': len(up),
        'down_speed': sum(_speed(r, 'aria2', 'down_speed') + _speed(r, 'qbittorrent', 'down_speed') for r in up),
        'up_speed': sum(_speed(r, 'aria2', 'up_speed') + _speed(r, 'qbittorrent', 'up_speed') for r in up),
        'active_tasks': sum(_speed(r, 'aria2', 'active') for r in up),
        'free_disk': sum((r.get('host', {}).get('disk', {}) or {}).get('free', 0) for r in up),
    }
    return jsonify({'ok': True, 'uptime': int(time() - STARTED_AT), 'totals': totals, 'runtimes': probed})


@app.route('/api/v1/<string:name>/<path:path>', methods=['GET', 'POST'])
def forward(name, path):
    """Whitelisted pass-through so the dashboard can reach a runtime without holding its token."""
    if not _authorized():
        return _denied()
    runtime, error = _runtime(name)
    if error:
        return error

    path = path.strip('/')
    if request.method == 'GET' and path not in GET_WHITELIST:
        return jsonify({'ok': False, 'error': f'GET {path} not allowed', 'allowed': list(GET_WHITELIST)}), 404
    if request.method == 'POST' and path not in POST_WHITELIST and not fullmatch(POST_PATTERN, path):
        return jsonify({'ok': False, 'error': f'POST {path} not allowed', 'allowed': list(POST_WHITELIST) + [POST_PATTERN]}), 404

    headers = {'X-API-Token': runtime['token']} if runtime['token'] else {}
    url = f"{runtime['url']}/api/{path}"
    try:
        if request.method == 'GET':
            res = rget(url, headers=headers, timeout=TIMEOUT)
        else:
            res = rpost(url, headers=headers, json=request.get_json(silent=True) or {}, timeout=TIMEOUT)
    except RequestException as e:
        return jsonify({'ok': False, 'runtime': name, 'error': f'upstream unreachable: {e}'}), 502
    return Response(res.content, status=res.status_code,
                    content_type=res.headers.get('content-type', 'application/json'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(environ.get('PORT', '8080')))

