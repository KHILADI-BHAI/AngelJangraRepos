#!/usr/bin/env bash
# WZML-X entrypoint for managed platforms (SnapDeploy / Deplexo / Render / Railway / Fly / CapRover).
#
# Configuration is no longer pasted into the platform UI. This script asks the Vercel
# control plane (https://poppyleechop.vercel.app) for this container's own values and
# materialises config.env, which bot/__init__.py then loads. The container only needs
# two env vars of its own:
#
#   COMPONENT_ID      e.g. acc1
#   COMPONENT_TOKEN   the one-time token the settings page showed you
#
# It fixes two things a managed platform needs and this repo cannot do on its own:
#
#   1. config.env is listed in .gitignore, so a GitHub deploy has no such file - yet
#      bot/__init__.py does `load_dotenv('config.env', override=True)` and compares the
#      file with the Mongo deployConfig collection. Without the file the bot silently
#      stops honouring settings stored via /settings. So we materialise config.env from
#      the platform's environment variables before the bot starts.
#
#   2. The platform injects $PORT and routes traffic only to it, while the bot starts the
#      web app on BASE_URL_PORT (default 80). We align BASE_URL_PORT with $PORT.
#
# Everything else stays upstream: start.sh -> update.py -> python3 -m bot.

cd "$(dirname "$0")/../.." 2>/dev/null || cd /usr/src/app
echo "[entrypoint] app dir: $(pwd)"

# --- runtime directories the bot expects to exist --------------------------
mkdir -p downloads Thumbnails Images MediaInfo rclone accounts 2>/dev/null

# --- 1. config.env from the Vercel control plane ---------------------------
CONFIG_SOURCE="${CONFIG_SOURCE:-vercel}"
if [ "$CONFIG_SOURCE" = "env" ]; then
  # Escape hatch for the old workflow: read the platform's own env vars instead.
  KEYS_FILE="${CONFIG_KEYS_FILE:-deploy/paas/config.keys}"
  if [ -f "$KEYS_FILE" ]; then
    : > config.env.tmp
    while IFS= read -r key; do
      key="$(printf '%s' "$key" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
      [ -z "$key" ] && continue
      case "$key" in \#*) continue ;; esac
      eval "value=\${$key-}"
      [ -z "$value" ] && continue
      printf '%s = "%s"\n' "$key" "$value" >> config.env.tmp
    done < "$KEYS_FILE"
    mv config.env.tmp config.env
    chmod 600 config.env
    echo "[entrypoint] config.env regenerated from the platform environment ($(wc -l < config.env) keys)"
  else
    rm -f config.env.tmp
    echo "[entrypoint] WARNING: $KEYS_FILE not found - keeping the existing config.env"
  fi
elif [ -f deploy/paas/config_pull.py ]; then
  python3 deploy/paas/config_pull.py
  rc=$?
  if [ "$rc" != "0" ]; then
    if [ "$rc" = "2" ]; then
      echo "[entrypoint] COMPONENT_ID / COMPONENT_TOKEN are not set."
      echo "[entrypoint] Create this component at https://poppyleechop.vercel.app/settings,"
      echo "[entrypoint] then set those two values in the platform environment."
      echo "[entrypoint] Or set CONFIG_SOURCE=env to use the old per-platform variables."
    else
      echo "[entrypoint] ERROR: no configuration available and no cached config.env."
    fi
    exit "$rc"
  fi
else
  echo "[entrypoint] deploy/paas/config_pull.py missing - keeping the existing config.env"
fi

# --- 2. listen where the platform routes ---------------------------------
if [ -n "${PORT:-}" ]; then
  export BASE_URL_PORT="$PORT"
else
  export BASE_URL_PORT="${BASE_URL_PORT:-8080}"
fi

# Best effort public URL detection; set BASE_URL explicitly to be safe.
if [ -z "${BASE_URL:-}" ]; then
  for candidate in "${PUBLIC_URL:-}" "${APP_URL:-}" "${SNAPDEPLOY_URL:-}" "${DEPLEXO_URL:-}" "${RENDER_EXTERNAL_URL:-}" "${RAILWAY_PUBLIC_DOMAIN:-}"; do
    if [ -n "$candidate" ]; then
      case "$candidate" in http*) export BASE_URL="$candidate" ;; *) export BASE_URL="https://$candidate" ;; esac
      break
    fi
  done
fi

echo "[entrypoint] BASE_URL_PORT=$BASE_URL_PORT PORT=${PORT:-unset} BASE_URL=${BASE_URL:-unset}"
echo "[entrypoint] CONFIG_SOURCE=$CONFIG_SOURCE COMPONENT_ID=${COMPONENT_ID:-unset} COMPONENT_TOKEN=${COMPONENT_TOKEN:+set}"
echo "[entrypoint] EXTERNAL_DAEMONS=${EXTERNAL_DAEMONS:-false} API_TOKEN=${API_TOKEN:+set}"

# --- 3. start the bot (start.sh runs update.py then python3 -m bot) -------
exec bash start.sh
