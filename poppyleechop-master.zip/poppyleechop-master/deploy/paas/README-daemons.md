# Deploy this package: download box (daemons only, real disk required)

Use this when the daemons must run on a machine **you own** (VPS, home server, or Windows PC)
because managed platforms do not offer persistent volumes. The bot, gateway, and dashboard can stay
on PaaS only when the bot can read this box's download directory over a shared filesystem.

## Where to run this box

**Recommendation:** a mainstream **x86-64 Linux VPS** with Docker, at least **1 GB RAM**, and
enough disk for your largest download plus working space. This is not a container-only PaaS app:
aria2/qBittorrent need durable storage and the bot must be able to read the same files.

| Option | When it fits | Important limitation |
| --- | --- | --- |
| **Dedicated VPS (recommended)** | Persistent downloads, predictable performance, and straightforward Linux Docker setup | Check storage, bandwidth, and the provider's acceptable-use and torrent policies. Availability and pricing change; confirm them when you sign up. |
| **Oracle Cloud Always Free (ARM)** | A low-cost experiment if you can create a free instance | Free capacity can run out, and Oracle may reclaim idle Always Free compute instances. It is not a reliable permanent download host or a drop-in x86-64 image host. |
| **Home server / NAS / always-on PC** | Large local disk and no hosting bill | Give the bot a private network route, protect the host, and monitor power/reboots. |
| **Fly.io or another container PaaS** | Ephemeral experiments only | No suitable persistent filesystem for this package and no shared download directory for the bot. |

**Minimum sizing:** 512 MB RAM can work for lightly used daemons, but **1 GB is the practical
starting point** (aria2 + qBittorrent), with 2 GB preferable for concurrent torrents. Leave room
for the Docker image, caches, incomplete files, and files the bot is processing. Free tiers often
have small disks, strict quotas, or limited network throughput.

**For a two-host setup:** do **not** expose aria2 RPC `6800` or qBittorrent `8090` to the public
internet. Connect both boxes with Tailscale/WireGuard, bind those ports to the VPN address, and
mount NFS/SMB/sshfs at the same absolute path on both hosts. See `SPLIT_DEPLOY.md` for the exact
layout. On one host no network mount is needed: keep bot and daemons together and share a host bind
mount or Docker volume.

Set a strong `ARIA2_SECRET` and a different, strong `QBIT_PASSWORD`; set `QBIT_USERNAME`; and
restrict the cloud firewall/security group to the bot's private IP. Never treat an API token as a
substitute for a firewall. See the security checklist in `SPLIT_DEPLOY.md`.

## Files

| File | Use |
| --- | --- |
| `docker-compose.split.yml` | runs bot / daemons as separate services, all mounting the same download dir |
| `.env.split.example` | copy to `.env.split` and fill in |
| `deploy/aria.remote.sh` | aria2c with `--rpc-listen-all`, for the remote-daemon case |
| `deploy/set_qbittorrent_auth.py` | adds username + PBKDF2 hash + `Address=*` so the WebUI is reachable remotely |
| `start_windows.ps1` | Windows launcher with `-DaemonsOnly`, `-ExternalDaemons` |
| `SPLIT_DEPLOY.md` | the full split guide, including the shared-path rule |

## The one rule that cannot be broken

Both sides must see the downloads at the **same absolute path** on the same filesystem. The bot
passes absolute paths to aria2/qBittorrent and then reads those files back to unpack and upload.
Across two machines that means NFS / SMB / sshfs mounted at an identical mount point (for example,
`/mnt/downloads`); an open port alone is not enough.

## Typical layouts

1. **One box, bot and daemons together:** works as-is with a shared Docker volume or host bind mount.
2. **Two VPS with NFS:** supported and documented in `SPLIT_DEPLOY.md`.
3. **PC as the download box + PaaS bot:** not possible because managed PaaS cannot mount the PC's
   shared download directory. Keep the bot with the daemons, or use a bot host that can mount it.

## Daemon environment for this box

| Variable | Value |
| --- | --- |
| `EXTERNAL_DAEMONS` | `true` when this container runs only the daemons |
| `ARIA2_HOST` / `ARIA2_PORT` / `ARIA2_SECRET` | how the bot reaches aria2 RPC |
| `QBIT_HOST` / `QBIT_PORT` / `QBIT_USERNAME` / `QBIT_PASSWORD` | how the bot reaches the WebUI |

qBittorrent skips authentication only for localhost, so a remote WebUI needs both the username and
password above and `WebUI\Address=*` (see `deploy/set_qbittorrent_auth.py`). Keep the RPC port and
the WebUI protected: the API token is not a network ACL.

# Deploy this package: download box (daemons only, real disk required)

Use this when the daemons must run on a machine **you own** (VPS, home server, the Windows
PC) because managed platforms do not offer persistent volumes. Everything else - the bot,
the gateway, the dashboard - can stay on PaaS.

## Where to run this box

**Recommendation:** a mainstream x86-64 Linux VPS with Docker, at least **1 GB RAM**, and enough
disk for your largest download plus working space. This is not a container-only PaaS app:
aria2/qBittorrent need durable storage and the bot must be able to read the same files.

| Option | When it fits | Important limitation |
| --- | --- | --- |
| **Dedicated VPS (recommended)** | Persistent downloads, predictable performance, straightforward Linux Docker setup | Plan for storage, bandwidth, and the provider's acceptable-use and torrent policies separately. Check availability and pricing when you sign up. |
| **Oracle Cloud Always Free (ARM)** | A low-cost experiment, if you can create a free instance | Free capacity can run out, and Oracle may reclaim idle Always Free compute instances. It is not a reliable permanent download host. |
| **Home server / NAS / always-on PC** | Large local disk and no hosting bill | Give the bot a private network route; protect the host and monitor power/reboots. |
| **Fly.io or another container PaaS** | Ephemeral experiments only | No suitable persistent filesystem for this package and no shared download directory for the bot. |

**Minimum sizing:** 512 MB RAM can work for lightly used daemons, but **1 GB is the practical
starting point**, with 2 GB preferable for concurrent torrents. Allow room for the Docker image,
caches, incomplete files, and files the bot is processing. Free-tier instances often have small
disks, strict quotas, or limited network throughput.

**For a two-host setup:** do **not** expose aria2 RPC `6800` or qBittorrent `8090` to the public
internet. Connect the bot and daemon boxes with Tailscale/WireGuard, bind those ports to the VPN
address, and use an NFS/SMB/sshfs mount at the same absolute path on both hosts. See
`SPLIT_DEPLOY.md` for the exact layout. On one host, no network mount is needed: keep the bot and
daemons together and share a host bind mount or Docker volume.

Set strong, different `ARIA2_SECRET` and `QBIT_PASSWORD` values in `.env`, set `QBIT_USERNAME`,
and restrict the cloud firewall/security group to the bot's private IP. Never treat an API token as
a substitute for a firewall. See the security checklist in `SPLIT_DEPLOY.md`.

