#!/usr/bin/env python3
"""Pull this container's configuration from the Vercel control plane.

Run at container start (see deploy/paas/entrypoint.sh) instead of expecting 20-100
environment variables to be pasted into SnapDeploy/Deplexo/VPS. The only values a
container needs are its own identity:

    COMPONENT_ID=acc1
    COMPONENT_TOKEN=<shown once by the settings page>

    python3 deploy/paas/config_pull.py            # write config.env
    python3 deploy/paas/config_pull.py --print    # dump the key/value pairs
    python3 deploy/paas/config_pull.py --check    # exit 0 if reachable, 1 if not

Stdlib only, so it adds nothing to the image. It writes config.env atomically and
never logs a value. Failure policy is deliberate:

    fetch ok                  -> config.env replaced
    fetch failed, cache exists -> warning, keep the previous file, exit 0
    fetch failed, no cache     -> error, exit 1 (never boot half-configured)
"""

import argparse
import json
import os
import sys
import tempfile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

DEFAULT_ORIGIN = 'https://poppyleechop.vercel.app'
TIMEOUT = int(os.environ.get('CONFIG_PULL_TIMEOUT', '15'))
KEYS_FILE = os.environ.get('CONFIG_KEYS_FILE', 'deploy/paas/config.keys')
OUTPUT = os.environ.get('CONFIG_OUTPUT', 'config.env')


def fetch(origin, component, token):
    """GET /api/resolve -> {'values': {...}, 'config_version': N}"""
    url = f"{origin.rstrip('/')}/api/resolve?component={component}"
    request = Request(url, headers={
        'X-Component-Token': token,
        'Accept': 'application/json',
        'User-Agent': 'wzmlx-config-pull/1.0',
    })
    with urlopen(request, timeout=TIMEOUT) as response:  # noqa: S310 (fixed https origin)
        payload = json.loads(response.read().decode('utf-8'))
    if not payload.get('ok'):
        raise RuntimeError(payload.get('error') or 'control plane returned ok=false')
    return payload


def allowed_keys():
    """The allowlist, so an unexpected key from the control plane is never written."""
    keys = set()
    if os.path.isfile(KEYS_FILE):
        with open(KEYS_FILE, encoding='utf-8') as handle:
            for line in handle:
                key = line.strip()
                if key and not key.startswith('#'):
                    keys.add(key)
    return keys


def write_env(values, path=OUTPUT):
    """Atomic replace: the bot must never read a half-written config.env."""
    directory = os.path.dirname(os.path.abspath(path)) or '.'
    os.makedirs(directory, exist_ok=True)
    handle = tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=directory,
                                         prefix='.config.env.', delete=False)
    try:
        with handle:
            for key in sorted(values):
                value = str(values[key]).replace('\\', '\\\\').replace('"', '\\"')
                handle.write(f'{key} = "{value}"\n')
        os.chmod(handle.name, 0o600)
        os.replace(handle.name, path)
    except Exception:
        if os.path.exists(handle.name):
            os.unlink(handle.name)
        raise
    return path

OUTPUT = os.environ.get('CONFIG_OUTPUT', 'config.env')


def log(message):
    print(f'[config-pull] {message}', flush=True)


def main():
    parser = argparse.ArgumentParser(description='Fetch this container config from Vercel.')
    parser.add_argument('--print', dest='show', action='store_true',
                        help='print KEY=value pairs instead of writing config.env')
    parser.add_argument('--check', action='store_true',
                        help='only report whether the control plane answers')
    parser.add_argument('--origin', default=os.environ.get('CONFIG_ORIGIN', DEFAULT_ORIGIN))
    args = parser.parse_args()

    component = os.environ.get('COMPONENT_ID', '').strip()
    token = os.environ.get('COMPONENT_TOKEN', '').strip()
    if not component or not token:
        log('COMPONENT_ID and COMPONENT_TOKEN are required '
            '(create the component on the settings page and paste its token)')
        return 2

    payload = None
    try:
        payload = fetch(args.origin, component, token)
    except HTTPError as error:
        detail = ''
        try:
            detail = json.loads(error.read().decode('utf-8')).get('error', '')
        except Exception:
            pass
        log(f'HTTP {error.code} from {args.origin}: {detail or error.reason}')
        if error.code in (401, 403):
            log('the component token was refused - rotate it on the settings page '
                'and update this container')
    except (URLError, TimeoutError, OSError, ValueError) as error:
        log(f'control plane unreachable at {args.origin}: {error}')

    if args.check:
        return 0 if payload else 1

    if payload is None:
        if os.path.exists(OUTPUT):
            log(f'keeping the existing {OUTPUT} - starting with the last known config')
            return 0
        log(f'no cached {OUTPUT} and no control plane, refusing to start half-configured')
        return 1

    values = payload.get('values') or {}
    allowed = allowed_keys()
    if allowed:
        unexpected = sorted(set(values) - allowed)
        values = {k: v for k, v in values.items() if k in allowed}
        if unexpected:
            log(f'note: {len(unexpected)} key(s) ignored as absent from {KEYS_FILE}')

    if not values:
        log('control plane returned no values for this component - check its role')
        return 1

    if args.show:
        for key in sorted(values):
            print(f'{key}={values[key]}')
        return 0

    path = write_env(values)
    version = payload.get('config_version')
    log(f'wrote {len(values)} key(s) from {args.origin} '
        f'(config v{version}, role {payload.get("role")}) to {path}')
    if version:
        marker = os.path.join(os.path.dirname(os.path.abspath(path)) or '.', '.config_version')
        with open(marker, 'w', encoding='utf-8') as handle:
            handle.write(str(version))
    return 0


if __name__ == '__main__':
    sys.exit(main())

