# Deploy this package: WZML-X control-plane gateway (Deplexo / SnapDeploy acc2)

A tiny stateless Flask app (~60 MB RSS, no disk use) that gives the dashboard **one stable
API** in front of every runtime container, across as many accounts as you have.

```
dashboard (Vercel) -> gateway (this app) -> runtime acc1 (SnapDeploy acc1)
                                        -> runtime acc2 (SnapDeploy acc2)
                                        -> runtime accN (Deplexo / VPS / your PC)
```

It fits a Deplexo **Free** container (128 MB / 250 MB) or a SnapDeploy Free one, and it is
the only place that knows the runtimes' API tokens - the browser never sees them.

## Steps

1. Push this folder to its own GitHub repository.
2. Deplexo: New app -> GitHub -> the included `deplexo.yaml` selects the Dockerfile build.
   SnapDeploy: New app -> Docker -> it picks up the `Dockerfile` automatically.
3. Set `GATEWAY_TOKEN`, `RUNTIMES`, `UPSTREAM_TIMEOUT`, and `PORT` (= the platform's routed
   port: 8080 for SnapDeploy/container default, whatever Deplexo shows if you override it).
4. Open `https://<app>/healthz` -> `ok`.
5. Add the gateway URL + token to the Vercel dashboard project as `GATEWAY_URL` /
   `GATEWAY_TOKEN`.

## `RUNTIMES` format

```
RUNTIMES=acc1=https://app-1.snapdeploy.app|TOKEN1,acc2=https://app-2.snapdeploy.app|TOKEN2
```

`name=url|token` entries, comma separated. `|token` is that runtime's `API_TOKEN`. Entries
without a token are allowed (that runtime's protected routes will then return 401).

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/healthz` | plain `ok`, for platform health checks and uptime robots |
| GET | `/` | JSON index: configured runtimes + endpoint list |
| GET | `/api/v1/runtimes` | runtime names, urls, whether a token is stored |
| GET | `/api/v1/status` | fans out to every runtime in parallel, returns totals |
| GET | `/api/v1/<runtime>/health\|stats\|torrents` | proxied to that runtime |
| POST | `/api/v1/<runtime>/torrents/clear` | drop finished entries (never active ones) |
| POST | `/api/v1/<runtime>/torrents/<id>/pause\|resume\|cancel` | act on one task |

All routes except `/healthz` need the `X-API-Token: <GATEWAY_TOKEN>` header. Only
whitelisted upstream paths are forwarded, and task ids must be 16-40 hex characters.
