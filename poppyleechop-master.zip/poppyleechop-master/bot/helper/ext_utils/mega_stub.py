#!/usr/bin/env python3
"""
Placeholder for the Mega SDK python bindings (mega.py).

The official bindings are only shipped inside the Docker image, they cannot be
built on Windows. These stubs keep every module importable so the bot can run
without Mega support, Mega links report a clear error instead.
"""

MEGA_AVAILABLE = False

_MEGA_MISSING = 'Mega SDK python bindings are not installed on this platform'


class MegaError:
    def __init__(self, *args, **kwargs):
        self.__value = args[0] if args else ''

    def getErrorCode(self):
        return 0

    def toString(self):
        return _MEGA_MISSING

    def copy(self):
        return self

    def __str__(self):
        return self.toString()


class MegaRequest:
    TYPE_LOGIN = 1
    TYPE_FETCH_NODES = 2
    TYPE_GET_PUBLIC_NODE = 3


class MegaTransfer:
    def isFinished(self):
        return False

    def isFolderTransfer(self):
        return False

    def getFileName(self):
        return ''

    def getSpeed(self):
        return 0

    def getTransferredBytes(self):
        return 0


class MegaListener:
    def __init__(self, *args, **kwargs):
        pass


class MegaApi:
    def __init__(self, *args, **kwargs):
        raise RuntimeError(_MEGA_MISSING)
