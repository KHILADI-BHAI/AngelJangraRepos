"""Two-way sync between this bot's /settings menu and the Vercel control plane.

The dashboard is where you configure the deployment; Telegram /settings is where you
tune the bot while it runs. This module makes a value changed in either place show up
in the other, and it is careful about the one case that would otherwise destroy data:

    DbManger.db_load() runs on EVERY boot and writes the bot's entire in-memory config
    to Mongo. If that were synced upwards, each container restart would push the bot's
    stale view back over whatever you had just saved on the dashboard. So db_load() is
    explicitly NOT synced - only an explicit edit is (update_config / update_deploy_config).

Everything here is best-effort and synchronous-free on purpose: a Vercel outage must
never block or fail a Telegram settings edit. The local Mongo write always happens
first and stays authoritative until a push succeeds.
"""

from json import dumps
from logging import getLogger
from os import environ
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

LOGGER = getLogger(__name__)

DEFAULT_ORIGIN = 'https://poppyleechop.vercel.app'
TIMEOUT = float(environ.get('CONFIG_PUSH_TIMEOUT', '10'))


def enabled():
    """Two-way sync is opt-in: it only runs when this container has a component identity."""
    return bool(environ.get('COMPONENT_ID', '').strip() and environ.get('COMPONENT_TOKEN', '').strip())


def push(values, source='telegram'):
    """Send a small {key: value} patch to the control plane. Never raises."""
    if not values:
        return False
    if not enabled():
        LOGGER.debug('config sync off (no COMPONENT_ID/COMPONENT_TOKEN), skipping push')
        return False
    origin = environ.get('CONFIG_ORIGIN', DEFAULT_ORIGIN).rstrip('/')
    component = environ['COMPONENT_ID'].strip()
    body = dumps({'component': component, 'values': values}).encode('utf-8')
    request = Request(
        f'{origin}/api/push',
        data=body,
        headers={
            'X-Component-Token': environ['COMPONENT_TOKEN'].strip(),
            'Content-Type': 'application/json',
            'User-Agent': 'wzmlx-config-sync/1.0',
        },
        method='POST',
    )
    try:
        with urlopen(request, timeout=TIMEOUT) as response:  # noqa: S310 (fixed https origin)
            status = response.status
        if status < 300:
            LOGGER.info(f'synced {len(values)} key(s) to the control plane ({source})')
            return True
        LOGGER.warning(f'control plane rejected the sync: HTTP {status}')
    except HTTPError as error:
        # 401/403 means the component token no longer matches - worth shouting about.
        LOGGER.warning(f'control plane refused the sync: HTTP {error.code} {error.reason}')
    except (URLError, TimeoutError, OSError, ValueError) as error:
        LOGGER.warning(f'control plane unreachable, the local change is still saved: {error}')
    return False
