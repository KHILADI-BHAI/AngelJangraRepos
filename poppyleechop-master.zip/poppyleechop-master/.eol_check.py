﻿import pathlib
for p in ["deploy/paas/README-daemons.md", "deploy/paas/README-runtime.md", "DEPLOY_MULTI_ACCOUNT.md", "deploy/paas/README-gateway.md"]:
    b = pathlib.Path(p).read_bytes()
    print(p, "|", len(b), "bytes |", "CRLF" if b.count(b"\r\n") else "LF-only", "| trailing-newline:", b.endswith(b"\n"))
