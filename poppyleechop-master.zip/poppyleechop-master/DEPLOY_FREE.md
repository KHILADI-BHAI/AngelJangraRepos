# Deploy WZML-X on Free Hosting (No Credit Card)

## ⚠️ Why NOT Vercel?
- Vercel is **serverless only** — no long-running processes
- Cannot run system daemons (aria2c, qbittorrent-nox)
- Cannot use custom Docker base images
- Telegram bot polling needs 24/7 persistent connectivity
- **Vercel will NOT work for this bot**

## ✅ Best Free Platforms (No CC Required)

### 1. SnapDeploy (Recommended)
- **Sign up**: https://snapdeploy.dev (no CC)
- 512MB RAM, Docker support, 10 deploys/day free
- **Auto-sleeps** after 15 min idle → bot reconnects on wake
- **Sprint Pack**: $1/24h (one-time, no subscription) for 24/7 uptime
- Deploy Guide: https://snapdeploy.dev/docs/deployment-guide

### 2. Deplexo (Alternative)
- **Sign up**: https://deplexo.com (no CC)
- "Free forever for hobby projects", Docker via GitHub
- Claims "always-on no cold starts"
- Specs not clearly documented — try and report back

### 3. JustRunMy.App (Fallback)
- **Sign up**: https://justrunmyapp.com (no CC)
- 256MB RAM, 300MB disk, Docker support
- "Small always-on baseline"
- Resources likely insufficient for torrent downloading

---

## 📋 Deployment Steps (SnapDeploy)

### Step 1: Push to GitHub (without config.env)
```bash
git init
git remote add origin https://github.com/YOURUSER/YOUR-REPO.git
git add -A
git commit -m "Deploy"
git push origin main
```
> config.env is in .gitignore — your credentials won't be pushed.

### Step 2: Create MongoDB Atlas Free Account
1. Go to https://mongodb.com/atlas
2. Sign up (try Google SSO — may skip CC requirement)
3. Create a **Free** (M0) Shared Cluster
4. Database Access → Add username/password
5. Network Access → Add IP Address "0.0.0.0/0" (Allow Anywhere)
6. Connect → Copy the connection string (replace `<password>`)

### Step 3: Get Telegram Credentials
1. **Bot Token**: Message `@BotFather` → `/newbot`
2. **API ID & Hash**: Go to https://my.telegram.org → API Development Tools

### Step 4: Deploy on SnapDeploy
1. Go to https://snapdeploy.dev → Sign up (no CC)
2. Connect your GitHub
3. New → Deploy from GitHub → Select your repo
4. Choose "Docker" buildpack
5. In **Environment Variables**, add:
   ```
   BOT_TOKEN=839293861:AAHT-...     (from @BotFather)
   OWNER_ID=123456789                (your Telegram user ID)
   TELEGRAM_API=123456               (from my.telegram.org)
   TELEGRAM_HASH=abcdef1234567890    (from my.telegram.org)
   DATABASE_URL=mongodb+srv://...     (from MongoDB Atlas)
   DOWNLOAD_DIR=/usr/src/app/downloads/
   GDRIVE_ID=1T8zJQfRZev_...          (your Google Drive folder ID)
   ```
6. Click "Deploy"

### Step 5: Verify
- Check container logs for "WZML-X Bot Started!"
- Send `/start` to your bot on Telegram
- Send `/ping` to verify it responds

---

## 🔐 Environment Variables (Required)
Set these on your hosting platform (do NOT put in GitHub):

| Variable | Source |
|----------|--------|
| BOT_TOKEN | @BotFather |
| OWNER_ID | Your Telegram numeric user ID |
| TELEGRAM_API | my.telegram.org |
| TELEGRAM_HASH | my.telegram.org |
| DATABASE_URL | MongoDB Atlas connection string |

Optional but recommended:
| Variable | Source |
|----------|--------|
| GDRIVE_ID | Your Google Drive folder/team drive ID |
| INDEX_URL | Index link for Drive browsing |
| USE_SERVICE_ACCOUNTS | "True" for SA-based uploads |
| RCLONE_PATH | RClone remote path |
| BASE_URL | Enable web UI for torrent file selection |

---

## 🧪 Deplexo free plan — verdict after running the bot locally (24 Sep 2026)

Deplexo's pricing page lists the free tier as:

| Free ("For one tiny project") | Limit |
| --- | --- |
| Apps | 1 |
| CPU | 0.25 |
| RAM | **128 MB** |
| Disk | **250 MB** |
| Bandwidth | 10 Mbit/s |
| Transfer | 100 GB/mo |
| Persistent volumes | **not offered on any plan** ("coming soon" on Business) |

Measured footprint of the very same stack, idle (no download running):

| Process | RAM |
| --- | --- |
| Bot (`python -m bot`) | **148 MB** |
| qBittorrent | 65 MB |
| aria2c | 13 MB |
| **Total idle** | **~226 MB** |

| Files | Size |
| --- | --- |
| Python dependencies only (`.venv`) | **315 MB** |
| Extracted tools (7-Zip + qBittorrent) | 270 MB |

### Result: ❌ not viable — neither Free nor Starter

1. **RAM**: Free gives 128 MB, Starter 512 MB. The bot alone uses ~148 MB before a single download; add aria2c and the BitTorrent engine (40-65 MB). 226 MB idle already breaks Free and leaves Starter almost no headroom once ffmpeg splitting/uploading starts.
2. **Disk**: Free gives 250 MB, Starter 2 GB. Installing just the Python dependencies already needs ~315 MB, and the published image (`mysterysd/wzmlx`) plus the bot's files is multi-GB. Mirrored files need GBs more.
3. **No persistent storage**: there are no persistent volumes on Free/Starter/Pro (only "coming soon" on Business), so every redeploy wipes downloads, thumbnails and saved tokens.
4. **Bandwidth**: 10 Mbit/s free (≈1.2 MB/s) makes multi-GB mirrors painfully slow.
5. **Process model**: the bot needs four long-running processes (bot, aria2c, qBittorrent, optional gunicorn) plus a Telegram long-polling connection — a poor fit for hobby platforms with idle-sleep or serverless limits.

### What to use instead

- **Cheapest reliable**: a small KVM VPS ($3-5/mo, 1-2 GB RAM, 20 GB disk) with real Docker and a persistent disk. The repo's `docker-compose.yml` + `start.sh` work unchanged because the base image already ships `qbittorrent-nox`, `aria2c`, the Mega SDK bindings and ffmpeg.
- **Free tiers that can actually run it**: Oracle Cloud "Always Free" (ARM 4 vCPU / 24 GB RAM / 200 GB disk — card needed for verification only), Google Cloud e2-micro free tier, or GitHub Codespaces for short test sessions (4 GB RAM, Docker available, but sessions are not 24/7).
- **Avoid** any plan that is serverless, sleeps when idle, or offers <512 MB RAM / <2 GB disk / no persistent volume.

