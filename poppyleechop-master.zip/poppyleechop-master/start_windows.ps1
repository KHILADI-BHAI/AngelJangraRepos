# start_windows.ps1 - Run WZML-X locally on Windows
#
# Windows has no qbittorrent-nox and no aria.sh, so this script starts the two
# daemons the bot expects and then launches the bot itself:
#   * aria2c with RPC enabled on port 6800
#   * qBittorrent with its WebUI on port 8090 (GUI build, keeps its window open)
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\start_windows.ps1
#   powershell -ExecutionPolicy Bypass -File .\start_windows.ps1 -DaemonsOnly   # this PC is the "download box"
#
# Split deployment (see SPLIT_DEPLOY.md): when this PC is only the download box, run
# -DaemonsOnly here, and on the bot box set EXTERNAL_DAEMONS=true plus ARIA2_HOST /
# QBIT_HOST pointing at this PC. With EXTERNAL_DAEMONS=true the script skips the
# local daemons, because they then live somewhere else.

param(
    [switch]$DaemonsOnly
)

$ErrorActionPreference = 'Stop'
$BotDir = $PSScriptRoot
Set-Location $BotDir

$externalDaemons = $env:EXTERNAL_DAEMONS -match '^(1|true|yes)$'
if ($externalDaemons) { Write-Host '[*] EXTERNAL_DAEMONS is set: the daemons are expected on another host' }

$aria2c = (Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Recurse -Filter 'aria2c.exe' -ErrorAction SilentlyContinue | Select-Object -First 1).FullName
if (-not $aria2c) { throw 'aria2c.exe not found. Install it with: winget install aria2.aria2' }

$qbit = Join-Path $BotDir '.tools\qbit\qbittorrent.exe'
if (-not (Test-Path $qbit)) { throw "$qbit not found. Extract qbittorrent_*_x64_setup.exe into .tools\qbit with 7-Zip" }

$python = Join-Path $BotDir '.venv\Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Virtual env missing. Run: python -m venv .venv ; .\.venv\Scripts\python.exe -m pip install -r requirements_local.txt' }

if ($externalDaemons) {
    Write-Host '[*] starting the bot only, Ctrl+C stops it'
    & $python -m bot
    exit
}

# ---------------- aria2c (RPC 6800), flags from aria.sh without --daemon ----
$aria2Args = @(
    '--allow-overwrite=true', '--auto-file-renaming=true', '--bt-enable-lpd=true',
    '--bt-detach-seed-only=true', '--bt-remove-unselected-file=true', '--bt-max-peers=0',
    '--enable-rpc=true', '--rpc-max-request-size=1024M', '--max-connection-per-server=10',
    '--max-concurrent-downloads=10', '--split=10', '--seed-ratio=0', '--check-integrity=true',
    '--continue=true', '--disk-cache=40M', '--force-save=true', '--min-split-size=10M',
    '--follow-torrent=mem', '--check-certificate=false', '--optimize-concurrent-downloads=true',
    '--http-accept-gzip=true', '--max-file-not-found=0', '--max-tries=20', '--reuse-uri=true',
    '--content-disposition-default-utf8=true', '--user-agent=Wget/1.12', '--summary-interval=0',
    '--max-upload-limit=1K', '--log=.tools/aria2.log', '--log-level=notice')

if ($DaemonsOnly -or $env:ARIA2_LISTEN_ALL) {
    # this PC serves other machines: expose the RPC (always use a secret + Tailscale/firewall!)
    $aria2Args += '--rpc-listen-all=true'
    $rpcPort = if ($env:ARIA2_RPC_PORT) { $env:ARIA2_RPC_PORT } else { '6800' }
    $aria2Args += "--rpc-listen-port=$rpcPort"
    if ($env:ARIA2_SECRET) { $aria2Args += "--rpc-secret=$($env:ARIA2_SECRET)" }
    else { Write-Warning 'ARIA2_SECRET is not set: the exposed RPC will have no authentication at all' }
}

if (Get-Process aria2c -ErrorAction SilentlyContinue) {
    Write-Host '[=] aria2c already running'
} else {
    Start-Process -FilePath $aria2c -WindowStyle Hidden -ArgumentList $aria2Args
    Write-Host '[+] aria2c started (RPC port 6800)'
}

for ($i = 0; $i -lt 20; $i++) {
    try {
        $null = Invoke-RestMethod -Uri 'http://localhost:6800/jsonrpc' -Method Post -ContentType 'application/json' -Body '{"jsonrpc":"2.0","id":"1","method":"aria2.getVersion"}' -TimeoutSec 3
        Write-Host '[+] aria2c RPC is answering'
        break
    } catch { Start-Sleep -Seconds 1 }
}

# ---------------- qBittorrent WebUI (8090) ---------------------------------
try {
    $null = Invoke-RestMethod 'http://localhost:8090/api/v2/app/version' -TimeoutSec 3
    Write-Host '[=] qBittorrent WebUI already running'
} catch {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $qbit
    # the profile path contains spaces, so the value has to be quoted
    $psi.Arguments = '--profile="' + $BotDir + '" --confirm-legal-notice --no-splash'
    $psi.WorkingDirectory = $BotDir
    $psi.UseShellExecute = $false
    [void][System.Diagnostics.Process]::Start($psi)
    Write-Host '[+] qBittorrent started, WebUI http://localhost:8090 (admin / adminadmin)'
    Start-Sleep -Seconds 12
}

try {
    $null = Invoke-RestMethod 'http://localhost:8090/api/v2/app/version' -TimeoutSec 5
    Write-Host '[+] qBittorrent WebUI is answering'
} catch {
    Write-Warning 'qBittorrent WebUI is not answering, torrent tasks will fail. Run .tools\fix_qbittorrent_ini.py and restart qBittorrent.'
}

# ---------------- the bot ---------------------------------------------------
if ($DaemonsOnly) {
    Write-Host '[+] daemons are up, this PC can act as the "download box"'
    Write-Host "    aria2 RPC  : http://<this-pc-ip>:6800   (secret: $($env:ARIA2_SECRET))"
    Write-Host '    qBittorrent: http://<this-pc-ip>:8090   (admin / adminadmin)'
    if (-not $env:ARIA2_SECRET) { Write-Warning 'Set $env:ARIA2_SECRET before exposing the RPC to another machine' }
    Write-Host '[*] remote WebUI access needs WebUI\Address=* in qBittorrent.ini:'
    Write-Host '    .\.venv\Scripts\python.exe .tools\fix_qbittorrent_ini.py --address "*"   (then restart qBittorrent)'
    Write-Host '[*] press Enter to stop both daemons, or close this window to leave them running'
    [void](Read-Host)
    Get-Process aria2c, qbittorrent -ErrorAction SilentlyContinue | Stop-Process
    exit
}

Write-Host '[*] starting the bot, Ctrl+C stops it (close the qBittorrent window to stop torrents)'
& $python -m bot
