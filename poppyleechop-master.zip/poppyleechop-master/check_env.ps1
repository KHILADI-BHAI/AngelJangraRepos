Write-Host "=== Environment Check ==="

$pythonVer = & python --version 2>&1
Write-Host "Python: $pythonVer"

$pipVer = & pip --version 2>&1
Write-Host "pip: $pipVer"

Write-Host "`n=== System Dependencies ==="
foreach ($cmd in @("aria2c", "qbittorrent-nox", "openssl")) {
    Write-Host "  $cmd"
    $found = Get-Command $cmd -ErrorAction SilentlyContinue
    if ($found) {
        Write-Host "    FOUND at $($found.Source)"
    } else {
        Write-Host "    NOT FOUND"
    }
}

Write-Host "`n=== Docker ==="
$docker = Get-Command docker -ErrorAction SilentlyContinue
if ($docker) {
    Write-Host "  Docker: FOUND"
} else {
    Write-Host "  Docker: NOT FOUND"
}

Write-Host "`n=== Git ==="
$git = Get-Command git -ErrorAction SilentlyContinue
if ($git) {
    Write-Host "  Git: FOUND"
} else {
    Write-Host "  Git: NOT FOUND"
}