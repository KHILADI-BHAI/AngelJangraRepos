# Ready to deploy

Six zips, one guide. Configuration is entered **once** on Vercel; every other container
pulls its own values from there.

```
01-snapdeploy-acc1-runtime.zip     the bot + aria2 + qBittorrent   (deploy this first)
02-snapdeploy-acc2-runtime.zip     a second bot (own Telegram token)
03-deplexo-acc1-gateway.zip        the API router between Vercel and your bots
04-deplexo-acc2-web-selector.zip   optional standalone file selector
05-vercel-dashboard.zip            the dashboard + admin settings page
06-daemons-vps.zip                 optional download box for a machine with a real disk
env/                               your real values - never share this folder
```

**Do this order: 05 → 01 → 03.** The dashboard must exist before a bot can ask it for
its configuration.

---

## Step 1 - Vercel (the dashboard + config)

1. Unzip `05-vercel-dashboard.zip`.
2. Vercel → **Add New** → **Project** → import that folder.
3. Deploy. It builds as a static + serverless project; no build command needed.
4. Open **Settings → Environment Variables** and add everything from `env/vercel.env`:

   | Name | Value |
   | --- | --- |
   | `ADMIN_TOKEN` | the long value in `env/vercel.env` |
   | `CONFIG_MASTER_KEY` | the long value in `env/vercel.env` |
   | `DATABASE_URL` | your Mongo URI |
   | `BOT_ID` | the digits before `:` in your bot token |
   | `GATEWAY_TOKEN` | value from `env/vercel.env` |
   | `DASHBOARD_TOKEN` | value from `env/vercel.env` |
   | `CRON_SECRET` | value from `env/vercel.env` |
   | `MONGO_DB` | `wzmlx` |
   | `RUNTIME_NAME` | `acc1` |

5. Redeploy (Settings → Deployments → ⋯ → Redeploy) so the new variables take effect.
6. Your URL should be `poppyleechop.vercel.app`. If it is not, carry on - you can tell
   the containers the right address in step 6.

> **Keep `CONFIG_MASTER_KEY` safe.** It encrypts every stored value. Lose it and the saved
> settings cannot be decrypted - you would have to enter them all again.

---

## Step 2 - Fill in your settings

1. Open **`https://poppyleechop.vercel.app/settings`**.
2. Paste your `ADMIN_TOKEN` into the box, click **Connect**.
3. On the **Values** tab fill in at least:

   `BOT_TOKEN` · `OWNER_ID` · `TELEGRAM_API` · `TELEGRAM_HASH` · `DATABASE_URL` ·
   `GDRIVE_ID` · `DEFAULT_UPLOAD` · `API_TOKEN` · `RESTART_API` = `true`

   `BASE_URL` needs your SnapDeploy app URL, which you only get in step 4 - add it then.
   *Every other setting already has a sensible default; add them later if you want.*
4. Click **Save changes**.

---

## Step 3 - Register the containers

Stay on **`/settings` → Components & credentials**:

1. **Create**: name `acc1`, role `runtime`. Leave the URL blank until step 4.
2. **Copy the token** the moment it appears - it is shown once and never again.
3. Repeat for `acc2` (role `runtime`) if you want a second bot.
4. Create `gw`, role `gateway`, for the Deplexo gateway. Copy its token.
5. Create `box`, role `daemons`, only if you use `06-daemons-vps.zip`. Copy its token.

---

## Step 4 - SnapDeploy (the bot)

1. Unzip `01-snapdeploy-acc1-runtime.zip`.
2. SnapDeploy → create a project from that folder (or connect the Git repo).
3. In the app's **Environment** settings add exactly two lines:

   ```
   COMPONENT_ID=acc1
   COMPONENT_TOKEN=paste-the-token-you-copied
   ```

4. Deploy. The first build takes 3-5 minutes.
5. When it is live, open the logs. You want to see:

   ```
   [entrypoint] app dir: /usr/src/app
   [config-pull] wrote 113 key(s) ... (config v1, role runtime)
   [entrypoint] CONFIG_SOURCE=vercel COMPONENT_ID=acc1 COMPONENT_TOKEN=set
   Connected Chat ID ...
   WZML-X Bot [@yourbot] Started!
   ```

6. Copy the app's public URL. Go back to `/settings` → Components → **Set URL** on `acc1`
   and paste it there; the dashboard needs it to reach your bot. Now set **`BASE_URL`** on
   the **Values** tab to the same URL.

**If the logs say `COMPONENT_ID and COMPONENT_TOKEN are required`**, those two environment
variables were not saved on the platform. That is the only thing this container needs.

---

## Step 5 - Deplexo (the gateway)

1. Unzip `03-deplexo-acc1-gateway.zip`.
2. Create a Deplexo app from that folder.
3. Add two environment variables:

   ```
   COMPONENT_ID=gw
   COMPONENT_TOKEN=paste-the-gw-token
   ```

4. Deploy, then copy its public URL.
5. On Vercel add that URL as **`GATEWAY_URL`** (`https://xyz.deplexo.com`), then redeploy
   Vercel.
6. Back on `/settings` → **Values**, set **`RUNTIMES`** to one line per bot:

   ```
   acc1=https://your-acc1-app.snapdeploy.app|paste-acc1-API_TOKEN
   ```

   Each `API_TOKEN` is the one you set on the **Values** tab in step 2.
   Add a second entry for `acc2` if you deployed it.

---

## Step 6 - Check it works

1. `/settings` → **Components & credentials**. Every row should be green and read
   `config v1 of v1`. Anything else tells you exactly what is wrong.
2. `https://poppyleechop.vercel.app/` → the main dashboard: your runtime, its speeds and
   free disk.
3. In Telegram, message your bot `/start`.

---

## Changing settings later

Everything is edited on `/settings` → **Values**.

- Ordinary values (limits, theme, captions): save, then press **Restart** on the
  Components tab. The bot reads its configuration at startup, so a restart is required.
- Telegram `/settings` still works, and changes made there appear on the page too.

---

## Problems

| What you see | What it means | Fix |
| --- | --- | --- |
| `no COMPONENT_ID/COMPONENT_TOKEN set` | env not saved on the platform | add both, redeploy |
| `HTTP 401 ... bad token` | token does not match the component | **Rotate token** on the page, paste the new one, redeploy |
| `refusing to start half-configured` | Vercel unreachable *and* no cached file | check the three Vercel env vars, redeploy Vercel |
| `config v1 of v3` (stale) | the container has not restarted | **Restart** it from the page |
| `No live bot found in MongoDB` | `BOT_ID` not set on Vercel | set `BOT_ID`, redeploy Vercel |
| Bot sleeps after ~15 min | SnapDeploy Free auto-sleep | point a free 5-minute monitor (UptimeRobot, cron-job.org) at `/api/ping` |
| Both bots answer, then one goes quiet | same Telegram token twice | `/clone` in Telegram, then update `BOT_TOKEN` for acc2 |

---

## Before you share this folder

`env/` contains your real Mongo URI, bot token and generated secrets, and
`deploy/dist/env/` is the same thing. **Never upload or commit either.** The zips
themselves contain no real credentials - that is re-checked on every build.
