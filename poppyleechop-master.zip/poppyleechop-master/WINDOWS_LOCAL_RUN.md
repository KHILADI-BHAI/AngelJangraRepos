# Running WZML-X locally on Windows

The bot is written for Linux (uvloop, `aria.sh`, `qbittorrent-nox`, `chmod`, `pkill`).
With a few source guards and two manually started daemons it runs fine on Windows.
Verified on Windows 11 + Python 3.13 (Microsoft Store build), 24 Sep 2026.

## 1. What has to be installed

| Component | How it was installed | Why |
| --- | --- | --- |
| Python deps | `python -m venv .venv` + `.\.venv\Scripts\python.exe -m pip install -r requirements_local.txt` | `uvloop`, `xattr`, `asyncio`, `tgcrypto` are skipped, `python-magic-bin` replaces `python-magic` |
| `pytz` | `pip install pytz` | imported by the bot but missing from `requirements.txt` |
| aria2c 1.37.0 | `winget install aria2.aria2` (user scope, no admin) | the bot talks to it over RPC on port 6800 |
| qBittorrent 5.2.3 | extract `qbittorrent_5.2.3_x64_setup.exe` into `.tools\qbit` with 7-Zip | Windows has **no** `qbittorrent-nox`, the GUI build serves the WebUI API the bot needs |
| 7-Zip 26.03 | `msiexec /a 7-Zip_26.03_Machine_X64_wix_en-US.msi TARGETDIR=.tools\7zip` | for the bot's `7z` calls (no admin needed) |
| ffmpeg | already present on this machine | needed for splitting/screenshots |

## 2. Start / stop

```powershell
# start aria2c + qBittorrent + the bot (Ctrl+C stops the bot)
powershell -ExecutionPolicy Bypass -File .\start_windows.ps1

# this PC is only the "download box" of a split deployment (see SPLIT_DEPLOY.md):
# its aria2 RPC is exposed, its qBittorrent WebUI can be reached from the bot box
$env:ARIA2_SECRET = '<long random string>'
powershell -ExecutionPolicy Bypass -File .\start_windows.ps1 -DaemonsOnly

# the daemons live on another machine: start the bot only and point it there
$env:EXTERNAL_DAEMONS = 'true'; $env:ARIA2_HOST = '100.64.0.7'; $env:ARIA2_SECRET = '<same>'
$env:QBIT_HOST = '100.64.0.7'; $env:QBIT_USERNAME = 'admin'; $env:QBIT_PASSWORD = '<pw>'
powershell -ExecutionPolicy Bypass -File .\start_windows.ps1

# stop the daemons too
Get-Process qbittorrent, aria2c | Stop-Process
```

The bot writes its log to `log.txt`, the daemons log to `.tools\aria2.log` and
`qBittorrent\data\logs\qbittorrent.log`.

## 3. Source changes made for Windows

1. `bot/__init__.py`
   - `uvloop` import guarded (Unix-only), the default asyncio loop is used.
   - startup block: `qbittorrent-nox`, `aria.sh`, `chmod`, `cp .netrc` and gunicorn are skipped on Windows (`IS_WINDOWS`).
   - the qBittorrent preference sync is wrapped in `try/except` so a missing WebUI cannot abort the startup.
2. `bot/helper/ext_utils/bot_utils.py`
   - `mega` import guarded; `pkg_resources` falls back to `importlib.metadata` (removed in setuptools 81+).
3. `bot/helper/mirror_utils/download_utils/mega_download.py` + new `bot/helper/ext_utils/mega_stub.py`
   - Mega links report a clear error instead of crashing the import.
4. `bot/helper/mirror_utils/download_utils/direct_link_generator.py`
   - `lk21` import guarded (incompatible with Python 3.13).
5. `bot/helper/ext_utils/fs_utils.py`
   - the `pkill` in the Ctrl+C shutdown handler tolerates Windows.
6. `bot/__main__.py`
   - `/restart` skips `pkill`/`update.py` on Windows and simply re-executes `python -m bot`.

## 4. Extra files added

| File | Purpose |
| --- | --- |
| `requirements_local.txt` | Windows dependency list (no uvloop/tgcrypto/xattr/asyncio) |
| `start_windows.ps1` | starts aria2c, qBittorrent and the bot (`-DaemonsOnly` = daemons only) |
| `docker-compose.split.yml` + `.env.split.example` | run bot / aria2 / qBittorrent / mongodb as separate parts, on one host or on several |
| `deploy/aria.remote.sh` | aria2 for a remote "download box" (RPC exposed, foreground, secret) |
| `deploy/set_qbittorrent_auth.py` | WebUI username/hash for a remote qBittorrent (Linux `.conf`) |
| `SPLIT_DEPLOY.md` | guide for splitting the stack across machines, incl. sizing + security |
| `.tools/fix_qbittorrent_ini.py` | writes the WebUI settings into `qBittorrent.ini` (`--address` for remote access) |
| `.tools/missing_imports.py` | static scan for imports that are missing in the venv |
| `.tools/patch_lk21_exrex.py` | patches lk21's vendored exrex for Python 3.13 |
| `.tools/qbit`, `.tools/7zip`, `.tools/dl` | portable qBittorrent / 7-Zip (git-ignored) |

## 5. qBittorrent gotchas (these cost the most time)

- qBittorrent **5.x on Windows stores its settings in `qBittorrent\config\qBittorrent.ini`** and
  completely ignores the `qBittorrent.conf` that the Linux/Docker deployments use.
- The WebUI refuses to start without credentials, the log only says
  `WebUI: Credentials are not set`. A username + `Password_PBKDF2` hash must exist.
- Keys appended at the end of the `.ini` land in the wrong section (`[Meta]`) and are ignored —
  they must be inside `[Preferences]`. That is what `.tools/fix_qbittorrent_ini.py` does
  (`WebUI\Enabled`, `Port=8090`, `LocalHostAuth=false`, `Username`, `Password_PBKDF2`).
- The WebUI listens on `127.0.0.1:8090` and `LocalHostAuth=false` is what lets
  `get_client()` in `bot/__init__.py` work without credentials.
- The `--profile` path contains spaces, so it has to be passed quoted
  (`--profile="<repo dir>"`), see `start_windows.ps1`.

## 6. Known limitations on Windows

- No `qbittorrent-nox`: the qBittorrent **GUI window must stay open**, closing it kills the torrent engine.
- Mega links need the Mega SDK python bindings, which only exist in the Docker image.
- lk21 hosters (hxfile, fembed, sbembed, antfiles) fail on Python 3.13 — use Python 3.12 or Docker for those.
- `/restart` re-executes the bot but does not update from git (`update.py` is Linux/`pkill` based).
- `SyntaxWarning: invalid escape sequence` messages from the repo are pre-existing and harmless.
