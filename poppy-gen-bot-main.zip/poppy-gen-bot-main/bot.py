#!/usr/bin/env python3
"""POPPY Guest Account Manager - Telegram Bot with per-user isolation + proxy rotation."""
import os, sys, json, subprocess, threading, re, time, random
from concurrent.futures import ThreadPoolExecutor, as_completed
import telebot
from telebot import types
from datetime import datetime

# ========== WEB SERVER (Render health check) ==========
try:
    from flask import Flask, request
    WEB_AVAILABLE = True
except Exception:
    WEB_AVAILABLE = False

WEB_APP = Flask(__name__) if WEB_AVAILABLE else None

@WEB_APP.route("/") if WEB_AVAILABLE else lambda: None
def web_home():
    return "OK", 200

@WEB_APP.route("/health") if WEB_AVAILABLE else lambda: None
def web_health():
    return "OK", 200

BOT_TOKEN = "8840094400:AAFH7flKA21AZFAcKHgEQtUqLaq-8ewz5jM"
ADMIN_IDS = [8180833778]
ACCOUNTS_PER_PROXY = 50  # Rotate proxy after 50 accounts
PROXY_CHUNK = 50  # Process proxies in this batch size, then free memory before next chunk
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GEN_SCRIPT = os.path.join(BASE_DIR, "gen.py")
ACTIVATOR_SCRIPT = os.path.join(BASE_DIR, "guestactivator.py")
PROXIES_FILE = os.path.join(BASE_DIR, "user_proxies.json")
GOOD_PROXIES_FILE = os.path.join(BASE_DIR, "good_proxies.txt")
WORKER = "proxy_worker.py"

bot = telebot.TeleBot(BOT_TOKEN)
bot_status = {"generating": False, "activating": False, "verifying": False,
              "last_run": None, "total_generated": 0, "total_activated": 0, "total_verified": 0}

# ========== STOP-SYSTEM (halt all running processes mid-run) ==========
STOP_EVENT = threading.Event()
PROC_LOCK = threading.Lock()
ACTIVE_PROCS = []  # list of subprocess.Popen objects currently running


def register_proc(p):
    """Track a running subprocess so stop_all() can kill it."""
    with PROC_LOCK:
        if p is not None:
            ACTIVE_PROCS.append(p)


def unregister_proc(p):
    """Remove a subprocess from the tracked list when it finishes."""
    with PROC_LOCK:
        if p in ACTIVE_PROCS:
            try:
                ACTIVE_PROCS.remove(p)
            except Exception:
                pass


def stop_all(reason="User requested"):
    """Signal all running pipelines to halt and kill their subprocesses.

    Returns True if something was actually running and got stopped.
    """
    was_running = (bot_status["generating"] or bot_status["activating"]
                   or bot_status["verifying"])
    STOP_EVENT.set()
    with PROC_LOCK:
        for p in list(ACTIVE_PROCS):
            if p is not None and p.poll() is None:
                try:
                    p.kill()
                except Exception:
                    pass
        ACTIVE_PROCS.clear()
    bot_status["generating"] = False
    bot_status["activating"] = False
    bot_status["verifying"] = False
    return was_running


def reset_stop_event():
    """Clear the stop flag so a new pipeline can start fresh."""
    STOP_EVENT.clear()


def make_stop_markup():
    """Inline button to stop the running process."""
    mk = types.InlineKeyboardMarkup()
    mk.add(types.InlineKeyboardButton("🛑 STOP", callback_data="stop_now"))
    return mk

# ========== USER-ISOLATION HELPERS ==========
def get_user_folder(chat_id):
    """Per-user folder: POPPY_USERS/chat_id (only that user's accounts live here)."""
    folder = os.path.join(BASE_DIR, "POPPY_USERS", str(chat_id))
    os.makedirs(os.path.join(folder, "ACCOUNTS"), exist_ok=True)
    os.makedirs(os.path.join(folder, "TOKENS-JWT"), exist_ok=True)
    return folder

def user_accounts_file(chat_id):
    folder = get_user_folder(chat_id)
    # gen.py saves as accounts-{region}.json; we glob for any in ACCOUNTS
    return os.path.join(folder, "ACCOUNTS")

def user_tokens_file(chat_id):
    return os.path.join(get_user_folder(chat_id), "TOKENS-JWT")

def read_user_accounts(chat_id):
    accs = []
    folder = user_accounts_file(chat_id)
    if os.path.exists(folder):
        for fn in os.listdir(folder):
            if fn.endswith(".json"):
                try:
                    with open(os.path.join(folder, fn), encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, list):
                            accs.extend(data)
                except:
                    pass
    return accs

def read_user_tokens(chat_id):
    toks = []
    folder = user_tokens_file(chat_id)
    if os.path.exists(folder):
        for fn in os.listdir(folder):
            if fn.endswith(".json"):
                try:
                    with open(os.path.join(folder, fn), encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, list):
                            toks.extend(data)
                except:
                    pass
    return toks

def prepare_gen_input(count=3):
    with open(os.path.join(BASE_DIR, "gen_input.txt"), "w", encoding="utf-8") as f:
        f.write("1\n2\n%d\nPOPPY\nPOPPY\n8\n5\n\n0\n" % count)

def prepare_activator_input(chat_id):
    accs = read_user_accounts(chat_id)
    if not accs: return False
    simple = [{"uid": a["uid"], "password": a["password"]} for a in accs]
    with open(os.path.join(BASE_DIR, "accounts.json"), "w", encoding="utf-8") as f:
        json.dump(simple, f, indent=2, ensure_ascii=False)
    return True

# ========== PROXY MANAGEMENT ==========
def load_user_proxies(chat_id):
    """Load proxies stored for this user."""
    data = {}
    if os.path.exists(PROXIES_FILE):
        try:
            with open(PROXIES_FILE, encoding="utf-8") as f:
                data = json.load(f)
        except:
            data = {}
    return data.get(str(chat_id), [])

def save_user_proxies(chat_id, proxies):
    data = {}
    if os.path.exists(PROXIES_FILE):
        try:
            with open(PROXIES_FILE, encoding="utf-8") as f:
                data = json.load(f)
        except:
            data = {}
    data[str(chat_id)] = proxies
    with open(PROXIES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def format_proxy(p):
    """Format a proxy string to 'http://user:pass@host:port' form. Handles bare ip:port, ip:port, and authenticated forms."""
    p = p.strip()
    if not p: return None
    # If it already has a scheme (http://, https://, socks5://) keep protocol part only
    if "://" in p:
        scheme, rest = p.split("://", 1)
        scheme = scheme.lower()
        # Keep http/https — convert socks to http for gen.py compatibility
        if scheme.startswith("socks"):
            scheme = "http"
        p = rest
    else:
        scheme = "http"
    # Handle authenticated proxy: "user:pass@host:port" or "user-country-US:pass@host:port"
    if "@" in p:
        auth_part, host_part = p.rsplit("@", 1)
        # Validate host part looks like host:port
        if ":" in host_part:
            return f"{scheme}://{auth_part}@{host_part}"
        else:
            # No port — invalid
            return None
    else:
        if ":" in p:
            return f"{scheme}://{p}"
        else:
            return None

def check_proxy_2step(proxy):
    """Two-step proxy check: 1) responsiveness 2) Garena block status. FAST with reduced timeouts."""
    import requests, urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    proxy = format_proxy(proxy)
    if not proxy: return "BAD", "Empty"
    proxies = {"http": proxy, "https": proxy}
    # STEP 1: responsiveness (tight timeout so only proxies fast enough for gen.py's
    # 1.6s generation requests are accepted - anything slower stalls generation).
    try:
        r = requests.get("https://www.google.com/generate_204", proxies=proxies, timeout=(1.0, 1.5), verify=False)
        if r.status_code >= 500: return "UNRESPONSIVE", "Step1: no response"
    except Exception:
        return "UNRESPONSIVE", "Step1: unreachable"
    # STEP 2: Garena block check (tight timeout to match gen.py's 1.6s generation budget)
    try:
        payload = {"app_id": 100067, "client_type": 2, "password": "PP_TestProxy_4242", "source": 2}
        headers = {"User-Agent": "GarenaMSDK/4.0.39(SM-A325M;Android 13;en;HK;)", "Accept": "application/json", "Content-Type": "application/json; charset=utf-8"}
        r = requests.post("https://100067.connect.garena.com/api/v2/oauth/guest:register",
                          proxies=proxies, headers=headers, json=payload, timeout=(1.0, 1.5), verify=False)
        text = r.text
        if r.status_code == 200 and '"data"' in text:
            return "GOOD", "Ready for generation"
        if any(b in text.lower() for b in ["block", "forbidden", "captcha"]):
            return "BLOCKED", "Step2: blocked by Garena"
        return "GOOD", "Reaches Garena (not blocked)"
    except Exception:
        return "BLOCKED", "Step2: cannot reach Garena"

def check_proxies_parallel(proxy_list, batch_size=8, on_progress=None):
    """Check proxies in parallel batches for speed. Calls on_progress(done, status, msg, good, blocked, dead) after each proxy completes. Returns list of (proxy, status, msg).

    Processes proxies in CHUNKS (PROXY_CHUNK at a time) and forces GC after every chunk so
    memory is freed between chunks instead of holding all results/threads at once.
    """
    import gc
    results = {}
    done = 0
    good = blocked = dead = 0
    chunk = PROXY_CHUNK
    # Outer loop: process one chunk at a time, then free memory before next chunk
    for cstart in range(0, len(proxy_list), chunk):
        cur = proxy_list[cstart:cstart + chunk]
        # Inner loop: parallel batch within this chunk
        for start in range(0, len(cur), batch_size):
            batch = cur[start:start + batch_size]
            with ThreadPoolExecutor(max_workers=batch_size, thread_name_prefix="proxycheck") as ex:
                futures = {ex.submit(check_proxy_2step, p): p for p in batch}
                for future in as_completed(futures):
                    p = futures[future]
                    fut_start = time.time()
                    try:
                        status, msg = future.result(timeout=12)
                    except Exception as e:
                        status, msg = "BAD", str(e)
                    elapsed = time.time() - fut_start
                    # gen.py uses a 1.6s timeout on every Garena request, so a proxy that
                    # takes longer than ~1.5s to respond will make generation stall/fail.
                    # Knock off such proxies so only fast (actually-workable) ones are kept.
                    if status == "GOOD" and elapsed > 1.5:
                        status = "SLOW"
                        msg = "Too slow for generation (" + f"{elapsed:.1f}s)"
                    results[p] = (status, msg)
                    done += 1
                    if status == "GOOD": good += 1
                    elif status == "SLOW": good += 1  # count slow separately but not as dead
                    elif status == "BLOCKED": blocked += 1
                    else: dead += 1
                    if on_progress:
                        on_progress(done, p, status, msg, good, blocked, dead)
        # Free memory after each chunk before loading the next one
        gc.collect()
    # Build ordered results matching input order
    ordered = []
    for p in proxy_list:
        r = results.get(p, ("BAD", "Unknown"))
        ordered.append((p, r[0], r[1]))
    return ordered

def get_next_proxy(chat_id, used_count):
    """Rotate proxy: every ACCOUNTS_PER_PROXY accounts, use next proxy."""
    proxies = load_user_proxies(chat_id)
    good = [p for p in proxies if p.get("status") == "GOOD"]
    if not good:
        return None
    idx = (used_count // ACCOUNTS_PER_PROXY) % len(good)
    return good[idx]["proxy"]

# ========== UI HELPERS ==========
def box(title, lines, emoji="✨"):
    t = f"<b>{'='*35}</b>\n<b>{emoji} {title} {emoji}</b>\n<b>{'='*35}</b>\n\n"
    for l in lines: t += f"• {l}\n"
    return t

def progress_bar(current, total, width=15):
    if total <= 0: total = 1
    filled = min(int((current / total) * width), width)
    return "█" * filled + "░" * (width - filled)

def chunk_message(text, max_len=4096):
    """Split a long HTML message into chunks at newline boundaries to avoid breaking tags."""
    if len(text) <= max_len:
        return [text]
    chunks = []
    current = ""
    for line in text.split('\n'):
        if len(current) + len(line) + 1 > max_len and current:
            chunks.append(current)
            current = line
        else:
            current = (current + '\n' + line) if current else line
    if current:
        chunks.append(current)
    return chunks if chunks else [""]

def parse_gen_count(line):
    # gen.py output: "ACCOUNT GENERATED {count}/{total}" e.g. "ACCOUNT GENERATED 1/30"
    m = re.search(r"ACCOUNT GENERATED\s*(\d+)", line)
    if m:
        return int(m.group(1))
    # fallback: "Gen: N"
    m = re.search(r"Gen:\s*(\d+)", line)
    return int(m.group(1)) if m else None

def parse_online_count(line):
    return "online" in line

def is_admin(uid):
    return True if not ADMIN_IDS else uid in ADMIN_IDS

# ========== COMMANDS ==========
@bot.message_handler(commands=['start', 'menu', 'help'])
def cmd_start(m):
    if not is_admin(m.from_user.id): return bot.reply_to(m, "⛔ Access Denied.")
    txt = box("POPPY GUEST MANAGER", ["🔥 Per-user account isolation", "🛡️ Proxy rotation system", "⚡ Auto Gen + Activate + Verify"], "🚀")
    txt += "\n<b>📋 COMMANDS:</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
    txt += "🛠 /gen [count] - Generate\n⚡ /activate - Activate YOUR accounts\n✅ /verify - Verify YOUR accounts\n"
    txt += "🚀 /full [count] - Full pipeline (Gen+Act+Ver)\n\n"
    txt += "<b>🌐 PROXY TOOLS:</b>\n"
    txt += "➕ /addproxies p1 p2... - Add+check (2-step parallel)\n🌐 /freeproxies - Fetch from 3 sources (roundproxies + proxyscrape + geonode)\n🔑 /addoxylabs &lt;curl&gt; - Add paid Oxylabs authenticated proxy\n📱 Upload .txt/.json - Import proxy files\n📡 /proxies - Show my proxies\n🔁 /checkproxies - Re-check saved proxies\n"
    txt += "📊 /status - Bot status\n👥 /accounts - MY credentials only\n🛑 /stop - STOP all running processes\n🗑 /clear - Clear MY data\n📋 /allaccounts - ADMIN: see all users' accounts\n"
    txt += "━━━━━━━━━━━━━━━━━━━━━━\n\n⏰ Last run: " + str(bot_status['last_run'] or 'Never')
    bot.send_message(m.chat.id, txt, parse_mode="HTML")

@bot.message_handler(commands=['addproxies'])
def cmd_addproxies(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    args = m.text.split()[1:]
    if not args:
        bot.reply_to(m, "➕ <b>Add proxies (one per line, optional http:// prefix):</b>\n\nSend /addproxies with your proxies separated by spaces.\nExample:\n<code>/addproxies 192.168.1.1:8080 user:pass@10.0.0.1:3128</code>\n\nOr send a .txt / .json file with your proxies.", parse_mode="HTML")
        return
    # Cap the list: Windows command-line has a length limit (~32k chars), and a
    # huge argv would make Popen fail silently => the command would look "stuck".
    if len(args) > 500:
        bot.reply_to(m, f"⚠️ <b>{len(args)} proxies is a lot for one command.</b>\nChecking the first 500 — split the rest or use /freeproxies.", parse_mode="HTML")
        args = args[:500]
    total = len(args)
    sm = bot.send_message(m.chat.id, f"🔍 <b>Checking {total} proxies (2-step)...</b>\n\n<code>[{progress_bar(0, total)}]</code> 0/{total}", parse_mode="HTML")

    def run():
        existing = load_user_proxies(uid)
        last_edit = [0.0]
        out_file = os.path.join(BASE_DIR, "worker_results.json")

        def on_progress(done, good, blocked, dead):
            now = time.time()
            if now - last_edit[0] >= 1.5:
                last_edit[0] = now
                try:
                    bot.edit_message_text(
                        f"🔍 <b>Checking {total} proxies (2-step)...</b>\n\n"
                        f"<code>[{progress_bar(done, total)}]</code> {done}/{total} checked\n"
                        f"✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass

        # All network checks run in a SEPARATE PROCESS; the bot never blocks.
        results = run_proxy_worker(["check", out_file] + list(args), timeout=180, on_progress=on_progress)
        # Merge GOOD/SLOW results into the user's saved proxies
        added = 0
        for r in results:
            if r.get("status") == "GOOD":
                existing.append({"proxy": r["proxy"], "status": "GOOD", "msg": r.get("msg", "")})
                added += 1
        if added:
            save_user_proxies(uid, list(existing))
        good_count = sum(1 for p in existing if p.get("status") == "GOOD")
        lines = []
        for r in results[-10:]:
            st = r.get("status", "BAD")
            emoji = "✅" if st == "GOOD" else ("🚫" if st == "BLOCKED" else "❌")
            lines.append(f"{emoji} <code>{r.get('proxy','')}</code> → {st}: {r.get('msg','')}")
        r = f"✅ <b>Proxy check complete!</b>\n\n<code>[{progress_bar(total, total)}]</code> {total}/{total}\n\n" + "\n".join(lines)
        r += f"\n\n<b>Total good: {good_count}/{total}</b> (saved to your proxy list)"
        try:
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception:
            pass
        backup_now()

    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(content_types=['document'])
def handle_proxy_file(m):
    """Accept proxy files (.txt or .json) from users. Download runs in a background
    thread with a hard timeout so the bot never hangs on a slow/large file."""
    uid = m.from_user.id
    if not is_admin(uid):
        return bot.reply_to(m, "⚠️ Access Denied.")
    doc = m.document
    if not doc:
        return
    fname = doc.file_name or ""
    if not (fname.endswith(".txt") or fname.endswith(".json")):
        bot.reply_to(m, "❌ Please send a <b>.txt</b> or <b>.json</b> file with proxies.", parse_mode="HTML")
        return
# Reject very large files immediately (a proxy list never needs to be huge;
# 1000 proxies is only ~50KB, so 2MB is already very generous).
    try:
        if getattr(doc, "file_size", 0) > 2 * 1024 * 1024:  # > 2 MB
            bot.reply_to(m, "❌ <b>File too large.</b> Please send a proxy file under 2 MB.", parse_mode="HTML")
            return
    except Exception:
        pass
    sm = bot.send_message(m.chat.id, f"📥 <b>Downloading {fname}...</b>\n\n🔍 DEBUG MODE: All errors will be shown", parse_mode="HTML")

    # Hard 180s (3 min) wall-clock budget for the WHOLE download. Files are
    # pre-capped at 2 MB, so even a slow host (Render free tier, ~20-50 KB/s
    # egress) gets enough time while the bot CANNOT hang forever. The file
    # download is STREAMED in 64 KB chunks so memory stays flat and a stalled
    # connection is detected mid-download (not after a blocking resp.read()).
    dl_budget = 180
    # Shared mutable holder so _process() can report the exact download error
    # to the user (it's visible in both _do_download and _process since they
    # are nested in handle_proxy_file).
    _dl_error = [None]

    def _do_download(read_timeout=90):
        """Download file from Telegram with extensive error logging."""
        print(f"[DL] ========== STARTING DOWNLOAD ==========", file=sys.stderr)
        print(f"[DL] File: {fname}", file=sys.stderr)
        print(f"[DL] File ID: {doc.file_id}", file=sys.stderr)
        print(f"[DL] Read timeout: {read_timeout}s", file=sys.stderr)
        
        # Download the file using requests with streaming. This is simpler and
        # more reliable than urllib for handling timeouts:
        #   - requests respects HTTP_PROXY/HTTPS_PROXY env vars by default, BUT
        #     we explicitly pass proxies={} and trust_env=False to force DIRECT.
        #   - stream=True + iter_content() gives us non-blocking chunk reads.
        #   - requests' timeout applies to BOTH connect and read, so stalled
        #     connections raise ReadTimeout instead of hanging forever.
        try:
            import requests as _rq
            from urllib.parse import quote as _quote
            import urllib3 as _ul
            print(f"[DL] ✓ Imports successful", file=sys.stderr)
            _ul.disable_warnings(_ul.exceptions.InsecureRequestWarning)
            api = "https://api.telegram.org/bot" + BOT_TOKEN
            print(f"[DL] API URL: {api[:50]}...", file=sys.stderr)
            
            # Force DIRECT connection: empty proxies dict + trust_env=False.
            sess = _rq.Session()
            sess.trust_env = False
            sess.proxies = {}
            headers = {"User-Agent": "Mozilla/5.0"}
            print(f"[DL] ✓ Session created (trust_env=False, proxies={{}})", file=sys.stderr)
            
            # Step 1: resolve the file path (small JSON response)
            print(f"[DL] Step 1: Getting file path from Telegram...", file=sys.stderr)
            try:
                url = api + "/getFile?file_id=" + _quote(doc.file_id)
                print(f"[DL] GET {url[:80]}...", file=sys.stderr)
                r = sess.get(url, headers=headers, timeout=(10, 30), verify=False)
                print(f"[DL] getFile response: HTTP {r.status_code}", file=sys.stderr)
                if r.status_code != 200:
                    _dl_error[0] = f"getFile HTTP {r.status_code}: {r.text[:200]}"
                    print(f"[DL] ✗ getFile failed: {_dl_error[0]}", file=sys.stderr)
                    return None
                res = r.json()
                print(f"[DL] getFile JSON: {res}", file=sys.stderr)
                if not res.get("ok"):
                    _dl_error[0] = f"getFile returned ok=false: {res.get('description', 'unknown')}"
                    print(f"[DL] ✗ getFile not ok: {_dl_error[0]}", file=sys.stderr)
                    return None
                if not res.get("result", {}).get("file_path"):
                    _dl_error[0] = "no file_path in getFile response"
                    print(f"[DL] ✗ No file_path in response", file=sys.stderr)
                    return None
                file_path = res["result"]["file_path"]
                print(f"[DL] ✓ File path: {file_path}", file=sys.stderr)
            except Exception as e:
                _dl_error[0] = f"getFile: {type(e).__name__}: {e}"
                print(f"[DL] ✗ getFile EXCEPTION: {e}", file=sys.stderr)
                import traceback
                traceback.print_exc(file=sys.stderr)
                return None
            
            # Step 2: STREAM the file body in 64 KB chunks with a hard deadline.
            deadline = time.time() + read_timeout
            chunks = []
            total = 0
            print(f"[DL] Step 2: Downloading file content (deadline: {read_timeout}s)...", file=sys.stderr)
            try:
                # CRITICAL: Telegram API file download URL format is:
                # https://api.telegram.org/file/bot<token>/<file_path>
                # NOT https://api.telegram.org/bot<token>/file/<file_path>
                file_url = "https://api.telegram.org/file/bot" + BOT_TOKEN + "/" + file_path
                print(f"[DL] GET {file_url[:80]}...", file=sys.stderr)
                with sess.get(file_url, headers=headers, timeout=(10, read_timeout), verify=False, stream=True) as r:
                    print(f"[DL] File download response: HTTP {r.status_code}", file=sys.stderr)
                    if r.status_code != 200:
                        _dl_error[0] = f"file download HTTP {r.status_code}: {r.text[:200]}"
                        print(f"[DL] ✗ File download failed: {_dl_error[0]}", file=sys.stderr)
                        return None
                    print(f"[DL] ✓ Streaming started...", file=sys.stderr)
                    chunk_count = 0
                    for chunk in r.iter_content(chunk_size=65536):
                        chunk_count += 1
                        # Enforce deadline on EVERY chunk - stall detection
                        if time.time() > deadline:
                            _dl_error[0] = f"download exceeded {read_timeout}s budget (got {total} bytes in {chunk_count} chunks)"
                            print(f"[DL] ✗ Deadline exceeded: {_dl_error[0]}", file=sys.stderr)
                            return None
                        if not chunk:
                            print(f"[DL] Empty chunk received, stopping", file=sys.stderr)
                            break
                        total += len(chunk)
                        print(f"[DL] Chunk {chunk_count}: {len(chunk)} bytes (total: {total})", file=sys.stderr)
                        if total > 3 * 1024 * 1024:
                            _dl_error[0] = f"file exceeded 3 MB cap ({total} bytes)"
                            print(f"[DL] ✗ Size limit exceeded: {_dl_error[0]}", file=sys.stderr)
                            return None
                        chunks.append(chunk)
                    print(f"[DL] ✓ Download complete: {chunk_count} chunks, {total} bytes total", file=sys.stderr)
                content = b"".join(chunks).decode("utf-8", errors="replace")
                print(f"[DL] ✓ Decoded to text: {len(content)} chars", file=sys.stderr)
                return content
            except Exception as e:
                _dl_error[0] = f"download: {type(e).__name__}: {e}"
                print(f"[DL] ✗ download EXCEPTION: {e}", file=sys.stderr)
                import traceback
                traceback.print_exc(file=sys.stderr)
                return None
        except Exception as e:
            _dl_error[0] = f"FATAL: {type(e).__name__}: {e}"
            print(f"[DL] ✗ FATAL ERROR: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc(file=sys.stderr)
            return None

    def _process():
        # Cap on the WHOLE download (getFile + file bytes), scaled to file size.
        # Even if the network stalls forever, we show a clear message and the bot
        # keeps running.
        ok, content = _run_with_timeout(_do_download, dl_budget, dl_budget)
        if not ok:
            try:
                bot.edit_message_text(
                    f"❌ <b>Download of {fname} timed out.</b>\n\n"
                    f"Could not download the file within {dl_budget}s on this host.\n"
                    f"On a slow host (Render free tier) large files can fail.\n\n"
                    f"👉 Split the file into smaller chunks (< 500 KB each), or add proxies via\n"
                    f"<code>/addproxies</code> or <code>/freeproxies</code> instead.",
                    m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass
            return
        if content is None:
            detail = _dl_error[0] if _dl_error[0] else "unknown error"
            try:
                bot.edit_message_text(
                    f"❌ <b>Download of {fname} failed.</b>\n\n"
                    f"Reason: <code>{detail}</code>\n\n"
                    f"The file may be too large (over 3 MB), Telegram is slow, or the host "
                    f"is blocking direct downloads. Try a smaller file (< 2 MB).",
                    m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass
            return
        # content is ready - parse it
        proxies = []
        if fname.endswith(".json"):
            try:
                data = json.loads(content)
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, str):
                            proxies.append(item)
                        elif isinstance(item, dict):
                            if "proxy" in item:
                                proxies.append(str(item["proxy"]))
                            elif "ip" in item and "port" in item:
                                proxies.append(f"{item['ip']}:{item['port']}")
                            elif "host" in item and "port" in item:
                                proxies.append(f"{item['host']}:{item['port']}")
                elif isinstance(data, dict):
                    for key in ["proxies", "proxy_list", "list", "data"]:
                        if key in data and isinstance(data[key], list):
                            for item in data[key]:
                                if isinstance(item, str):
                                    proxies.append(item)
                                elif isinstance(item, dict):
                                    if "proxy" in item:
                                        proxies.append(str(item["proxy"]))
                                    elif "ip" in item and "port" in item:
                                        proxies.append(f"{item['ip']}:{item['port']}")
                                    elif "host" in item and "port" in item:
                                        proxies.append(f"{item['host']}:{item['port']}")
            except Exception as e:
                try:
                    bot.edit_message_text(f"❌ Invalid JSON: {e}", m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass
                return
        else:  # .txt - one proxy per line
            proxies = [l.strip() for l in content.splitlines() if l.strip() and not l.startswith("#")]
        if not proxies:
            try:
                bot.edit_message_text("❌ No proxies found in file.", m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass
            return
        total = len(proxies)
        try:
            bot.edit_message_text(
                f"🔍 <b>Checking {total} proxies from {fname} (2-step)...</b>\n\n<code>[{progress_bar(0, total)}]</code> 0/{total}",
                m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception:
            pass
        save_lock = threading.Lock()
        existing = load_user_proxies(uid)
        out_file = os.path.join(BASE_DIR, "worker_results.json")

        def run_proxy_check():
            last_edit = [0.0]

            def on_progress(done, good, blocked, dead):
                # Throttle edits to 1 per 1.5s to avoid Telegram 429 rate-limit storms
                now = time.time()
                if now - last_edit[0] >= 1.5:
                    last_edit[0] = now
                    try:
                        bot.edit_message_text(
                            f"🔍 <b>Checking {total} proxies from {fname} (2-step)...</b>\n\n"
                            f"<code>[{progress_bar(done, total)}]</code> {done}/{total} checked\n"
                            f"✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}",
                            m.chat.id, sm.message_id, parse_mode="HTML")
                    except Exception:
                        pass

            # All network checks run in a SEPARATE SUBPROCESS with a hard timeout,
            # so the bot can never freeze at "Downloading..." / "Checking...".
            # Scale timeout to proxy count: each proxy takes ~1.5s with 2-step check.
            # For 1000 proxies, that's ~25 minutes - give enough time or the worker
            # will be killed and return partial results.
            check_timeout = min(300 + total * 2, 1800)  # 5 min base + 2s per proxy, max 30 min
            results = run_proxy_worker(["check", out_file] + list(proxies), timeout=check_timeout, on_progress=on_progress)
            added = 0
            for r in results:
                if r.get("status") == "GOOD":
                    with save_lock:
                        existing.append({"proxy": r["proxy"], "status": "GOOD", "msg": r.get("msg", "")})
                        added += 1
            if added:
                save_user_proxies(uid, list(existing))
            lines = []
            for r in results[-10:]:
                st = r.get("status", "BAD")
                emoji = "✅" if st == "GOOD" else ("🚫" if st == "BLOCKED" else "❌")
                lines.append(f"{emoji} <code>{r.get('proxy','')}</code> → {st}: {r.get('msg','')}")
            good_count = sum(1 for p in existing if p.get("status") == "GOOD")
            r = (f"✅ <b>Proxy check complete! ({fname})</b> (saved)\n\n"
                 f"<code>[{progress_bar(total, total)}]</code> {total}/{total}\n\n"
                 + "\n".join(lines if lines else ["— no results returned —"]))
            r += f"\n\n<b>Total good: {good_count}/{total}</b>"
            try:
                bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass
            backup_now()

        threading.Thread(target=run_proxy_check, daemon=True).start()

    # Run the whole download+parse+check pipeline in a background thread so the
    # bot's polling thread is never blocked and the bot never appears stuck.
    threading.Thread(target=_process, daemon=True).start()


def parse_oxylabs_curl(text):
    """Parse Oxylabs curl command line and return formatted proxy string.

    Handles formats like:
      curl -x dc.oxylabs.io:8000 -U "user-12345_K242M-country-US:123_abc_ABC_" https://ip.oxylabs.io/location
      curl -x "user-12345_K242M-country-US:123_abc_ABC_@dc.oxylabs.io:8000" https://ip.oxylabs.io/location
    """
    import re as _re
    # Strip optional scheme
    text = text.strip()
    # Pattern: -x host:port  and -U "user:pass"  (two-argument style)
    m_proxy = _re.search(r'-x\s+(\S+)', text)
    m_user = _re.search(r'-U\s+"?([^"\s]+)"?', text)
    if m_proxy and m_user:
        host_port = m_proxy.group(1)
        auth = m_user.group(1)
        if "://" in host_port:
            host_port = host_port.split("://", 1)[1]
        return format_proxy(f"{auth}@{host_port}")
    # Pattern: -x "user:pass@host:port"  (single-argument style with auth embedded)
    m_combined = _re.search(r'-x\s+"?([^"\s]+)"?', text)
    if m_combined:
        raw = m_combined.group(1)
        if "://" in raw:
            raw = raw.split("://", 1)[1]
        return format_proxy(raw)
    return None

@bot.message_handler(commands=['addoxylabs'])
def cmd_addoxylabs(m):
    """Parse an Oxylabs curl command and add the proxy to the user's list."""
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    # Get everything after the command
    rest = m.text.split(None, 1)
    rest = rest[1] if len(rest) > 1 else ""
    if not rest:
        bot.reply_to(m, "🔑 <b>Add Oxylabs proxy from curl command:</b>\n\nExample:\n"
            "<code>/addoxylabs curl -x dc.oxylabs.io:8000 -U \"user-12345_K242M-country-US:123_abc_ABC_\" https://ip.oxylabs.io/location</code>\n\n"
            "Or paste just the proxy part:\n"
            "<code>/addoxylabs user-12345_K242M-country-US:123_abc_ABC_@dc.oxylabs.io:8000</code>", parse_mode="HTML")
        return
    formatted = parse_oxylabs_curl(rest)
    if not formatted:
        # Try treating it as a raw proxy string
        formatted = format_proxy(rest)
    if not formatted:
        bot.reply_to(m, "❌ Could not parse the Oxylabs proxy. Please provide the full curl command or a `user:pass@host:port` string.", parse_mode="HTML")
        return
    # Now 2-step check it
    sm = bot.send_message(m.chat.id, f"🔍 <b>Checking Oxylabs proxy...</b>\n<code>{formatted[:80]}</code>\n\n<code>[{progress_bar(0, 1)}]</code> 0/1", parse_mode="HTML")
    existing = load_user_proxies(uid)

    def run():
        status, msg = check_proxy_2step(formatted)
        if status == "GOOD":
            with threading.Lock():
                existing.append({"proxy": formatted, "status": "GOOD", "msg": msg, "source": "oxylabs"})
                save_user_proxies(uid, list(existing))
            r = f"✅ <b>Oxylabs proxy added & verified!</b>\n<code>{formatted[:100]}</code>\n\n{msg}"
        else:
            r = f"❌ <b>Proxy check failed:</b>\n{status}: {msg}\n\nRaw: <code>{formatted[:100]}</code>"
        bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        backup_now()
    threading.Thread(target=run, daemon=True).start()

def fetch_freeproxies_all():
    """Fetch proxies from 3 sources: roundproxies.com (JSON), ProxyScrape (plain text), GeoNode (JSON). Returns set of ip:port strings."""
    import requests, urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    proxies_raw = set()
    # Source 1: roundproxies.com API (JSON with ip, port, protocols)
    try:
        r = requests.get("https://roundproxies.com/api/get-free-proxies/", timeout=10, verify=False)
        if r.status_code == 200:
            data = r.json()
            raw_list = data.get("data", []) if isinstance(data, dict) else data
            for item in raw_list:
                ip, port = item.get("ip"), item.get("port")
                protos = item.get("protocols", [])
                if ip and port and ("http" in protos or "https" in protos):
                    proxies_raw.add(f"{ip}:{port}")
    except Exception as e:
        print(f"[roundproxies] Error: {e}")
    # Source 2: ProxyScrape v2 API (plain text, one per line)
    for proto in ["http", "https"]:
        try:
            r = requests.get(f"https://api.proxyscrape.com/v2/?request=getproxies&protocol={proto}&timeout=5&country=all&ssl=all&anonymous=all", timeout=10, verify=False)
            if r.status_code == 200 and r.text.strip():
                for line in r.text.strip().splitlines():
                    line = line.strip()
                    if line and ":" in line:
                        proxies_raw.add(line)
        except Exception as e:
            print(f"[proxyscrape {proto}] Error: {e}")
    # Source 3: GeoNode API (JSON with ip, port, protocols)
    try:
        r = requests.get("https://proxylist.geonode.com/api/proxy-list?limit=500&sort_by=speed&sort_type=asc", timeout=10, verify=False)
        if r.status_code == 200:
            data = r.json()
            raw_list = data.get("data", [])
            for item in raw_list:
                ip, port = item.get("ip"), item.get("port")
                protos = item.get("protocols", [])
                if ip and port and ("http" in protos or "https" in protos):
                    proxies_raw.add(f"{ip}:{port}")
    except Exception as e:
        print(f"[geonode] Error: {e}")
    return proxies_raw

@bot.message_handler(commands=['freeproxies'])
def cmd_freeproxies(m):
    """Fetch free proxies from 3 sources in a BACKGROUND thread so the bot never
    blocks (DNS/HTTP hangs cannot freeze the bot), cap the count, and check them
    with throttled progress edits."""
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    sm = bot.send_message(m.chat.id, "🌐 <b>Fetching free proxies (3 sources)...</b>\n• roundproxies.com\n• ProxyScrape\n• GeoNode", parse_mode="HTML")

    def run():
        last_edit = [0.0]
        out_file = os.path.join(BASE_DIR, "worker_results.json")

        def on_progress(done, good, blocked, dead):
            now = time.time()
            if now - last_edit[0] >= 1.5:
                last_edit[0] = now
                try:
                    bot.edit_message_text(
                        f"🔍 Checking {done} proxies (2-step parallel)\n✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}\n<code>[{progress_bar(done, done or 1)}]</code>",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass

        # The ENTIRE fetch + check runs in a SEPARATE SUBPROCESS with a hard 360s cap.
        # Even if every proxy source hangs on DNS, the worker is killed and the bot
        # keeps responding — it can never get stuck at "Fetching free proxies...".
        results = run_proxy_worker(["freeproxies", out_file], timeout=360, on_progress=on_progress)
        existing = load_user_proxies(uid)
        added = 0
        for r in results:
            if r.get("status") == "GOOD":
                existing.append({"proxy": r["proxy"], "status": "GOOD", "msg": r.get("msg", "")})
                added += 1
        if added:
            save_user_proxies(uid, list(existing))
        total = len(results)
        good_count = sum(1 for r in results if r.get("status") == "GOOD")
        blocked_count = sum(1 for r in results if r.get("status") == "BLOCKED")
        dead_count = total - good_count - blocked_count
        r = f"✅ <b>Free proxy import complete!</b>\n\n"
        r += f"Fetched {total} proxies (roundproxies + proxyscrape + geonode)\n"
        r += f"\n✅ Good: {good_count}\n🚫 Blocked: {blocked_count}\n❌ Dead/Slow: {dead_count}\n"
        r += f"\nGood proxies saved to your list."
        try:
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception:
            pass
        backup_now()

    threading.Thread(target=run, daemon=True).start()

# Delay between chunked messages (seconds) to avoid Telegram 429 rate-limit / timeouts
CHUNK_SEND_DELAY = 2.5

def send_html_chunks(chat_id, text, max_len=4096, delay=CHUNK_SEND_DELAY):
    """
    Send HTML text split into chunks (at newline boundaries to avoid breaking tags).
    Adds a delay between every message and retries with backoff on Telegram 429 (rate limit)
    so the bot doesn't time out when sending many messages back-to-back.
    """
    chunks = chunk_message(text, max_len)
    for idx, chunk in enumerate(chunks):
        if idx > 0:
            time.sleep(delay)  # space out messages to avoid Telegram 429 / timeout
        # Retry loop for rate-limit (429) and network errors
        for attempt in range(6):
            try:
                bot.send_message(chat_id, chunk, parse_mode="HTML")
                break
            except Exception as e:
                # Telegram 429 = too many requests -> wait longer and retry
                err_code = getattr(getattr(e, "result", None), "error_code", None)
                if err_code == 429:
                    retry_after = getattr(getattr(e, "result", None), "retry_after", None) or (delay * (attempt + 1))
                    time.sleep(max(retry_after, delay))
                    continue
                # Unrecoverable error (e.g. non-HTML-safe) -> send without parse mode
                try:
                    bot.send_message(chat_id, chunk)
                except Exception:
                    pass
                break

def _run_with_timeout(func, timeout, *args, **kwargs):
    """Run func(*args, **kwargs) in a background thread and wait up to `timeout` seconds.
    Returns (True, result) on success, (False, None) on timeout/error."""
    import queue as _q
    out = _q.Queue()
    def _target():
        try:
            out.put((True, func(*args, **kwargs)))
        except Exception as e:
            out.put((False, e))
    t = threading.Thread(target=_target, daemon=True)
    t.start()
    try:
        return out.get(timeout=timeout)
    except _q.Empty:
        return (False, TimeoutError("operation timed out"))


def run_proxy_worker(args, timeout, on_progress=None):
    """Launch proxy_worker.py as a SEPARATE PROCESS so the bot can never hang on
    network work. Reads its stdout lines; calls on_progress(done,good,blocked,dead)
    for each 'PROGRESS n g b d' line. Kills the process after `timeout` seconds.
    Returns the final results list (JSON) written by the worker, or [] on timeout."""
    import queue as _q
    worker = os.path.join(BASE_DIR, WORKER)
    cmd = [sys.executable, "-u", worker] + args
    results = []
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding="utf-8", errors="replace",
                             bufsize=1, cwd=BASE_DIR)
        register_proc(p)
        q = _q.Queue()

        def _reader():
            try:
                for line in p.stdout:
                    q.put(line)
            except Exception:
                pass
            finally:
                q.put(None)

        threading.Thread(target=_reader, daemon=True).start()
        start = time.time()
        while True:
            remaining = timeout - (time.time() - start)
            if remaining <= 0:
                break
            try:
                line = q.get(timeout=remaining)
            except _q.Empty:
                break  # wall-clock timeout reached
            if line is None:
                break  # worker exited
            line = line.strip()
            if line.startswith("PROGRESS "):
                parts = line.split()
                if len(parts) == 5:
                    try:
                        done, good, blocked, dead = (int(parts[1]), int(parts[2]),
                                                     int(parts[3]), int(parts[4]))
                        if on_progress:
                            on_progress(done, good, blocked, dead)
                    except Exception:
                        pass
        if p and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass
        unregister_proc(p)
    except Exception:
        pass
    # Load whatever results the worker wrote incrementally.
    out_arg = args[1] if len(args) >= 2 else ""
    if out_arg:
        try:
            with open(os.path.join(BASE_DIR, out_arg), encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    results = data
        except Exception:
            results = []
    return results


@bot.message_handler(commands=['proxies'])
def cmd_proxies(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    proxies = load_user_proxies(uid)
    if not proxies:
        bot.reply_to(m, "📡 <b>No proxies added.</b>\nUse /addproxies to add some.", parse_mode="HTML")
        return
    # PRUNE: automatically remove blocked/dead proxies so only GOOD ones remain.
    # This keeps the list clean and generation only uses working proxies.
    removed = 0
    kept = []
    for p in proxies:
        st = p.get("status")
        if st == "GOOD":
            kept.append(p)
        else:
            removed += 1
    if removed:
        save_user_proxies(uid, kept)
        proxies = kept
    good = [p for p in proxies if p.get("status") == "GOOD"]
    t = f"📡 <b>MY PROXIES: {len(proxies)}</b>\n"
    t += f"✅ Good: {len(good)} | 🚫 Blocked: {sum(1 for p in proxies if p.get('status')=='BLOCKED')} | ❌ Dead: {sum(1 for p in proxies if p.get('status')=='UNRESPONSIVE')}\n"
    if removed:
        t += f"🗑 <b>{removed}</b> blocked/dead proxy(ies) removed automatically.\n"
    t += "\n"
    for i, p in enumerate(proxies, 1):
        emoji = "✅" if p.get("status") == "GOOD" else (("🚫" if p.get("status") == "BLOCKED" else "❌"))
        t += f"{i}. {emoji} <code>{p.get('proxy')}</code> ({p.get('status')})\n"
# Chunk message to respect Telegram 4096-char limit, with delayed + rate-limit-safe sending
    send_html_chunks(m.chat.id, t)

@bot.message_handler(commands=['checkproxies'])
def cmd_checkproxies(m):
    """Re-check all saved proxies for this user and update their status in place.
    Drops dead/blocked ones so generation only uses currently-working proxies."""
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    proxies = load_user_proxies(uid)
    if not proxies:
        bot.reply_to(m, "📡 <b>No saved proxies to check.</b>\nUse /addproxies to add some.", parse_mode="HTML")
        return
    total = len(proxies)
    sm = bot.send_message(m.chat.id, f"🔍 <b>Re-checking {total} saved proxies...</b>\n\n<code>[{progress_bar(0, total)}]</code> 0/{total}", parse_mode="HTML")
    save_lock = threading.Lock()

    def run():
        # Build list of raw proxy strings to re-check
        raw_list = [p.get("proxy") for p in proxies if p.get("proxy")]
        last_edit = [0.0]  # throttle edits to avoid Telegram 429 rate-limit
        out_file = os.path.join(BASE_DIR, "worker_results.json")
        def on_progress(done, good, blocked, dead):
            # Throttle: update the progress bar at most every 1.0s to avoid 429 rate limits
            now = time.time()
            if now - last_edit[0] < 1.0:
                return
            last_edit[0] = now
            try:
                bot.edit_message_text(
                    f"🔍 <b>Re-checking {total} saved proxies...</b>\n\n"
                    f"<code>[{progress_bar(done, total)}]</code> {done}/{total} checked\n"
                    f"✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}",
                    m.chat.id, sm.message_id, parse_mode="HTML")
            except: pass
        # The whole re-check runs in a SEPARATE PROCESS with a hard 300s timeout.
        # The bot can never freeze even if a proxy stalls DNS or HTTP.
        results = run_proxy_worker(["check", out_file] + list(raw_list), timeout=300, on_progress=on_progress)
        res_map = {r.get("proxy"): r for r in results if r.get("proxy")}
        # Update each saved proxy's status/msg, then DELETE blocked/dead ones immediately
        with save_lock:
            kept = []
            for p in proxies:
                raw = p.get("proxy")
                if raw in res_map:
                    p["status"] = res_map[raw].get("status", "BAD")
                    p["msg"] = res_map[raw].get("msg", "")
                if p.get("status") == "GOOD":
                    kept.append(p)
                # SLOW proxies are dropped too (they stall generation).
            save_user_proxies(uid, kept)
        good_count = len(kept)
        blocked_count = 0
        dead_count = 0
        r = f"✅ <b>Proxy re-check complete!</b>\n\n<code>[{progress_bar(total, total)}]</code> {total}/{total} checked\n"
        r += f"✅ Good: {good_count} | 🚫 Blocked: {blocked_count} | ❌ Dead: {dead_count} (removed)\n\n"
        r += "📋 <b>First 10 results:</b>\n"
        shown = 0
        for p in kept:
            if shown >= 10: break
            st = p.get("status")
            emoji = "✅" if st == "GOOD" else ("🚫" if st == "BLOCKED" else "❌")
            r += f"{emoji} <code>{p.get('proxy')}</code> ({st})\n"
            shown += 1
        if total > 10:
            r += f"... and {total - 10} more (use /proxies to see all).\n"
        r += f"\n\n🗑 Blocked/dead/slow proxies were <b>deleted</b> from your list.\nOnly <b>{good_count} GOOD</b> proxies remain for generation."
        try: bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except: pass
        backup_now()
    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(commands=['gen'])
def cmd_gen(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    args = m.text.split()
    count = int(args[1]) if len(args) > 1 and args[1].isdigit() else 3
    if bot_status["generating"]: return bot.reply_to(m, "⏳ Already generating.")
    folder = get_user_folder(uid)
    proxy = get_next_proxy(uid, len(read_user_accounts(uid)))
    if not proxy:
        bot.reply_to(m, "🚫 <b>No GOOD proxy available.</b>\n\nWithout a proxy, Garena blocks the server IP after ~1 account, so generation will stall.\n\n👉 Add working proxies first:\n<code>/addproxies ip:port</code> or <code>/checkproxies</code>\n\nOr add a paid proxy with <code>/addoxylabs</code>.", parse_mode="HTML")
        return
    bot_status["generating"] = True
    reset_stop_event()
    prepare_gen_input(count)
    sm = bot.send_message(m.chat.id, f"⏳ <b>Generating {count} accounts...</b>\n📁 Your folder\n📡 Proxy: {'✅ ' + proxy[:50] if proxy else '❌ None (direct)'}\n\n{progress_bar(0, count)} 0/{count}", parse_mode="HTML", reply_markup=make_stop_markup())

    def run():
        start_t = time.time()
        max_time = max(60, count * 25)  # total wall-clock budget for ALL proxies
        stall_threshold = 90  # per-proxy: if no account in 90s, try next proxy
        got_first = False
        forced = False
        stopped = False
        p = None
        total_done = 0
        proxy_idx = 0
        proxy_stalled = False
        # Collect ALL good proxies so we can fall back when one is slow/blocked.
        all_proxies = [px.get("proxy") for px in load_user_proxies(uid)
                       if px.get("status") == "GOOD" and px.get("proxy")]
        if not all_proxies and proxy:
            all_proxies = [proxy]
        proxy_count = len(all_proxies) if all_proxies else 1
        #
        # ---- Outer loop: retry gen.py with the next proxy if the current one stalls ----
        while True:
            proxy_stalled = False
            proxy_start = time.time()
            cur_proxy = (all_proxies[proxy_idx % len(all_proxies)]
                         if all_proxies else proxy)
            remaining = count - total_done
            if remaining <= 0:
                break
            prepare_gen_input(remaining)
            # Inform the user which proxy we are using for this attempt.
            if proxy_count > 1:
                try:
                    bot.edit_message_text(
                        f"⏳ <b>Generating {count} accounts...</b>\n"
                        f"📡 Proxy {proxy_idx + 1}/{proxy_count}: {cur_proxy[:50] if cur_proxy else '❌ direct'}\n\n"
                        f"<code>[{progress_bar(total_done, count)}]</code> {total_done}/{count} generated",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass
            try:
                env = {**os.environ, "PYTHONIOENCODING": "utf-8",
                       "POPPY_BASE_FOLDER": folder}
                if cur_proxy:
                    env["POPPY_PROXY"] = cur_proxy
                p = subprocess.Popen([sys.executable, "-u", GEN_SCRIPT],
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, cwd=BASE_DIR, encoding="utf-8", errors="replace",
                    bufsize=1, env=env)
                register_proc(p)
                with open(os.path.join(BASE_DIR, "gen_input.txt"), "r", encoding="utf-8") as gf:
                    p.stdin.write(gf.read())
                p.stdin.flush(); p.stdin.close()
                last = total_done
                import queue as _q
                q = _q.Queue()

                def _reader():
                    try:
                        for line in p.stdout:
                            q.put(line)
                    except Exception:
                        pass
                    finally:
                        q.put(None)

                threading.Thread(target=_reader, daemon=True).start()
                while True:
                    if STOP_EVENT.is_set():
                        stopped = True
                        break
                    try:
                        line = q.get(timeout=5)
                    except _q.Empty:
                        if STOP_EVENT.is_set():
                            stopped = True
                            break
                        # No output for 5s. Check if gen.py actually produced accounts.
                        cur_accs = read_user_accounts(uid)
                        cur = len(cur_accs)
                        if cur > total_done:
                            got_first = True
                            total_done = cur
                        if cur >= count:
                            last = cur
                            try:
                                bot.edit_message_text(
                                    f"⏳ <b>Generating {count} accounts...</b>\n"
                                    f"📡 Proxy: {'✅ ' + cur_proxy[:50] if cur_proxy else '❌ None (direct)'}\n\n"
                                    f"<code>[{progress_bar(cur, count)}]</code> {cur}/{count} generated",
                                    m.chat.id, sm.message_id, parse_mode="HTML")
                            except Exception:
                                pass
                            break
                        if time.time() - start_t > max_time:
                            forced = True
                            break
                        # Per-proxy stall: if this proxy hasn't produced a first
                        # account within stall_threshold, try the next proxy.
                        if not got_first and (time.time() - proxy_start) > stall_threshold:
                            proxy_stalled = True
                            break
                        continue
                    if line is None:
                        break  # gen.py exited
                    g = parse_gen_count(line)
                    if g is not None:
                        cur = len(read_user_accounts(uid))
                        if cur > total_done:
                            got_first = True
                            total_done = cur
                        last = max(last, total_done)
                        try:
                            bot.edit_message_text(
                                f"⏳ <b>Generating {count} accounts...</b>\n"
                                f"📡 Proxy: {'✅ ' + cur_proxy[:50] if cur_proxy else '❌ None (direct)'}\n\n"
                                f"<code>[{progress_bar(total_done, count)}]</code> {total_done}/{count} generated",
                                m.chat.id, sm.message_id, parse_mode="HTML")
                        except Exception:
                            pass
                    if total_done >= count:
                        break
                    # Per-proxy stall check after parsing a line
                    if not got_first and (time.time() - proxy_start) > stall_threshold:
                        proxy_stalled = True
                        break
                    # Overall max time
                    if time.time() - start_t > max_time:
                        forced = True
                        break
            except Exception as e:
                try:
                    bot.edit_message_text(f"❌ <b>Error</b>: {e}", m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass
            # ---- Cleanup this gen.py process ----
            if p and p.poll() is None:
                try:
                    p.kill()
                except Exception:
                    pass
            unregister_proc(p)
            # Re-read actual on-disk count (source of truth)
            total_done = len(read_user_accounts(uid))
            if STOP_EVENT.is_set():
                stopped = True
                break
            if total_done >= count:
                break
            if forced:
                break
            if time.time() - start_t > max_time:
                forced = True
                break
            # If this proxy stalled with zero progress, try the next one.
            if proxy_stalled and not got_first:
                proxy_idx += 1
                if proxy_idx < len(all_proxies):
                    # Retry with the next proxy
                    continue
                else:
                    # Exhausted all proxies — set forced so the final report
                    # shows the helpful "No account could be generated" message.
                    forced = True
                    break
            # gen.py exited normally but didn't finish — if we have time and
            # proxies left, retry; otherwise report.
            if proxy_stalled and got_first:
                # proxy was producing accounts but then stalled (rate-limited).
                # Try the next proxy for the remaining accounts.
                proxy_idx += 1
                if proxy_idx < len(all_proxies) and remaining > 0:
                    continue
            # No more progress possible
            break
        #
        # ---- Final report ----
        bot_status["generating"] = False
        reset_stop_event()
        bot_status["last_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        accs = read_user_accounts(uid)
        bot_status["total_generated"] = len(accs)
        head = "✅ <b>Generation Complete!</b>"
        if stopped:
            head = "🛑 <b>Generation stopped by user.</b>"
        elif forced:
            if not got_first:
                head = ("🚫 <b>No account could be generated</b> — all proxies were "
                        "slow/blocked for Garena. Try /checkproxies or a paid proxy.")
            else:
                head = "⚠️ <b>Generation stopped</b> (proxy rate-limited/blocked after some accounts)."
        r = f"{head}\n\n<code>[{progress_bar(len(accs), count)}]</code> {len(accs)}/{count}\n"
        for i, a in enumerate(accs[-3:], 1):
            r += f"{i}. <code>{a['uid']}</code> | {a['password']}\n"
        bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        backup_now()
    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(commands=['activate'])
def cmd_activate(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    if bot_status["generating"] or bot_status["activating"]: return bot.reply_to(m, "⏳ Busy.")
    accs = read_user_accounts(uid)
    if not accs: return bot.reply_to(m, "❌ No accounts. Use /gen first.")
    bot_status["activating"] = True
    reset_stop_event()
    prepare_activator_input(uid)
    total = len(accs)
    sm = bot.send_message(m.chat.id, f"⚡ <b>Activating YOUR {total} accounts...</b>\n\n<code>[{progress_bar(0, total)}]</code> 0/{total} online", parse_mode="HTML", reply_markup=make_stop_markup())

    def run():
        import queue as _q
        online = 0
        start_t = time.time()
        # The activator runs forever (keeps accounts online). We don't wait for it to exit;
        # we run it for a bounded window, collect "online" progress, then report back.
        # 60s is enough to see how many accounts came online; more can be added by re-running.
        max_time = max(60, total * 5)  # e.g. 13 accounts -> 65s
        p = None
        stopped = False
        try:
            p = subprocess.Popen([sys.executable, "-u", ACTIVATOR_SCRIPT], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=BASE_DIR,
                encoding="utf-8", errors="replace", bufsize=1,
                env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            register_proc(p)
            q = _q.Queue()
            def _reader():
                try:
                    for line in p.stdout:
                        q.put(line)
                except Exception:
                    pass
                finally:
                    q.put(None)
            threading.Thread(target=_reader, daemon=True).start()
            while True:
                if STOP_EVENT.is_set():
                    stopped = True
                    break
                if time.time() - start_t > max_time:
                    break  # bounded window reached
                try:
                    line = q.get(timeout=5)
                except _q.Empty:
                    # No output momentarily; keep waiting until the window ends.
                    continue
                if line is None:
                    # Activator exited on its own (crash/error). Report what we saw.
                    break
                if parse_online_count(line):
                    online += 1
                    try:
                        bot.edit_message_text(
                            f"⚡ <b>Activating YOUR {total} accounts...</b>\n\n<code>[{progress_bar(online, total)}]</code> {online}/{total} online",
                            m.chat.id, sm.message_id, parse_mode="HTML")
                    except: pass
            # Cleanup: stop the activator (it's meant to keep running; we end the session).
            if p and p.poll() is None:
                try: p.kill()
                except: pass
            unregister_proc(p)
            bot_status["activating"] = False
            reset_stop_event()
            bot_status["last_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            bot_status["total_activated"] = online
            if stopped:
                bot.edit_message_text(f"🛑 <b>Activation stopped by user.</b>\n\n<code>[{progress_bar(online, total)}]</code> {online}/{total} online", m.chat.id, sm.message_id, parse_mode="HTML")
            else:
                note = "" if online > 0 else "\n\n⚠️ No accounts came online. The activator may have failed to connect (check that accounts.json has valid uids/passwords)."
                bot.edit_message_text(f"✅ <b>Activation Complete!</b>\n\n<code>[{progress_bar(online, total)}]</code> {online}/{total} online{note}", m.chat.id, sm.message_id, parse_mode="HTML")
            backup_now()
        except Exception as e:
            bot_status["activating"] = False
            reset_stop_event()
            if p and p.poll() is None:
                try: p.kill()
                except: pass
            unregister_proc(p)
            try: bot.edit_message_text(f"❌ Error: {e}", m.chat.id, sm.message_id)
            except: pass
    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(commands=['verify'])
def cmd_verify(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    if bot_status["verifying"]: return bot.reply_to(m, "⏳ Already verifying.")
    accs, toks = read_user_accounts(uid), read_user_tokens(uid)
    if not accs: return bot.reply_to(m, "❌ No accounts. Use /gen first.")
    bot_status["verifying"] = True
    reset_stop_event()
    total = len(accs)
    sm = bot.send_message(m.chat.id, f"🔍 <b>Verifying YOUR {total} accounts...</b>\n\n<code>[{progress_bar(0, total)}]</code> 0/{total}", parse_mode="HTML", reply_markup=make_stop_markup())

    def run():
        STOP_WAS_SET = False
        try:
            import requests, urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            jm = {str(t["uid"]): t["jwt_token"] for t in toks}
            vu = [0]
            vj = [0]
            done = [0]
            lock = threading.Lock()

            def check_one(a):
                if STOP_EVENT.is_set():
                    STOP_WAS_SET = True
                    return
                aid, jwt = a.get("account_id",""), jm.get(str(a["uid"]), "")
                ok1 = ok2 = False
                try:
                    r1 = requests.get("http://187.127.175.208:5000/Bmw", params={"uid": aid}, timeout=15, verify=False)
                    ok1 = r1.status_code == 200
                except: pass
                try:
                    r2 = requests.get(f"https://drogon-login-info.vercel.app/login?loginhistory&jwt_token={jwt}", timeout=15, verify=False)
                    ok2 = r2.status_code == 200
                except: pass
                with lock:
                    if ok1: vu[0] += 1
                    if ok2: vj[0] += 1
                    done[0] += 1
                    cur = done[0]
                try:
                    bot.edit_message_text(
                        f"🔍 <b>Verifying YOUR {total} accounts...</b>\n\n<code>[{progress_bar(cur, total)}]</code> {cur}/{total}\n• AccID: {vu[0]} ✅ • JWT: {vj[0]} ✅",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except: pass

            # Verify all accounts in parallel (thread pool sized to account count, capped at 20)
            with ThreadPoolExecutor(max_workers=min(len(accs), 20)) as ex:
                list(ex.map(check_one, accs))

            bot_status["verifying"] = False
            reset_stop_event()
            bot_status["last_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            bot_status["total_verified"] = vj[0]
            if STOP_WAS_SET:
                r = f"🛑 <b>Verification stopped by user.</b>\n\n<code>[{progress_bar(total, total)}]</code> {total}/{total}\n• AccID: {vu[0]}/{total}\n• JWT: {vj[0]}/{total}"
            else:
                r = f"✅ <b>Verification Complete!</b>\n\n<code>[{progress_bar(total, total)}]</code> {total}/{total}\n• AccID: {vu[0]}/{total}\n• JWT: {vj[0]}/{total}\nStatus: {'✅ ALL VALID' if vu[0] == total and vj[0] == total else '⚠️ PARTIAL'}"
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception as e:
            bot_status["verifying"] = False
            reset_stop_event()
            try: bot.edit_message_text(f"❌ Error: {e}", m.chat.id, sm.message_id)
            except: pass
    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(commands=['full'])
def cmd_full(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    args = m.text.split()
    count = int(args[1]) if len(args) > 1 and args[1].isdigit() else 3
    if bot_status["generating"] or bot_status["activating"] or bot_status["verifying"]:
        return bot.reply_to(m, "⏳ Busy.")
    folder = get_user_folder(uid)
    proxy = get_next_proxy(uid, len(read_user_accounts(uid)))
    reset_stop_event()
    sm = bot.send_message(m.chat.id, f"🚀 <b>FULL PIPELINE (YOUR ACCOUNTS)</b>\n• Target: {count}\n📡 Proxy: {'✅ ' + proxy[:50] if proxy else '❌ None (direct)'}\n\n"
        f"<b>Gen:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}\n<b>Act:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}\n<b>Ver:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}", parse_mode="HTML", reply_markup=make_stop_markup())

    def run():
        try:
            env = {**os.environ, "PYTHONIOENCODING": "utf-8", "POPPY_BASE_FOLDER": folder}
            if proxy: env["POPPY_PROXY"] = proxy
            # STEP 1: GEN
            prepare_gen_input(count)
            p1 = subprocess.Popen([sys.executable, "-u", GEN_SCRIPT], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=BASE_DIR,
                encoding="utf-8", errors="replace", bufsize=1, env=env)
            register_proc(p1)
            p1.stdin.write(open(os.path.join(BASE_DIR, "gen_input.txt"), "r", encoding="utf-8").read())
            p1.stdin.flush(); p1.stdin.close()
            gen_count = 0
            stopped = False
            for line in p1.stdout:
                if STOP_EVENT.is_set():
                    stopped = True
                    break
                g = parse_gen_count(line)
                if g is not None and g > gen_count:
                    gen_count = g
                    try:
                        bot.edit_message_text(
                            f"🚀 <b>FULL PIPELINE</b>\n• Target: {count}\n\n<b>Gen:</b> <code>[{progress_bar(gen_count, count)}]</code> {gen_count}/{count}\n<b>Act:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}\n<b>Ver:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}",
                            m.chat.id, sm.message_id, parse_mode="HTML")
                    except: pass
            p1.wait()
            unregister_proc(p1)
            if stopped:
                accs = read_user_accounts(uid)
                bot_status.update(last_run=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), total_generated=len(accs))
                bot.edit_message_text(f"🛑 <b>Full pipeline stopped by user.</b>\n\nGenerated so far: {len(accs)} accounts (saved).", m.chat.id, sm.message_id, parse_mode="HTML")
                return
            accs = read_user_accounts(uid)
            if not accs: return bot.edit_message_text("❌ Generation failed.", m.chat.id, sm.message_id)
            gen_count = len(accs)

            # STEP 2: ACTIVATE
            prepare_activator_input(uid)
            p2 = subprocess.Popen([sys.executable, "-u", ACTIVATOR_SCRIPT], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=BASE_DIR,
                encoding="utf-8", errors="replace", bufsize=1,
                env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            register_proc(p2)
            online = 0
            for line in p2.stdout:
                if STOP_EVENT.is_set():
                    stopped = True
                    break
                if parse_online_count(line):
                    online += 1
                    try:
                        bot.edit_message_text(
                            f"🚀 <b>FULL PIPELINE</b>\n• Target: {count}\n\n<b>Gen:</b> <code>[{progress_bar(gen_count, count)}]</code> {gen_count}/{count} ✅\n<b>Act:</b> <code>[{progress_bar(online, count)}]</code> {online}/{count}\n<b>Ver:</b> <code>[{progress_bar(0, count)}]</code> 0/{count}",
                            m.chat.id, sm.message_id, parse_mode="HTML")
                    except: pass
            p2.wait()
            unregister_proc(p2)
            if stopped:
                bot.edit_message_text(f"🛑 <b>Full pipeline stopped by user.</b>\n\nGenerated: {gen_count} accounts (saved).", m.chat.id, sm.message_id, parse_mode="HTML")
                backup_now()
                return

            # STEP 3: VERIFY (in parallel for speed)
            import requests, urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            toks = read_user_tokens(uid)
            jm = {str(t["uid"]): t["jwt_token"] for t in toks}
            vu = [0]
            vj = [0]
            done = [0]
            vlock = threading.Lock()

            def fv_one(a):
                if STOP_EVENT.is_set():
                    return
                ok1 = ok2 = False
                try:
                    r1 = requests.get("http://187.127.175.208:5000/Bmw", params={"uid": a.get("account_id","")}, timeout=15, verify=False)
                    ok1 = r1.status_code == 200
                except: pass
                try:
                    r2 = requests.get(f"https://drogon-login-info.vercel.app/login?loginhistory&jwt_token={jm.get(str(a['uid']),'')}", timeout=15, verify=False)
                    ok2 = r2.status_code == 200
                except: pass
                with vlock:
                    if ok1: vu[0] += 1
                    if ok2: vj[0] += 1
                    done[0] += 1
                    cur = done[0]
                try:
                    bot.edit_message_text(
                        f"🚀 <b>FULL PIPELINE</b>\n• Target: {count}\n\n<b>Gen:</b> <code>[{progress_bar(gen_count, count)}]</code> {gen_count}/{count} ✅\n<b>Act:</b> <code>[{progress_bar(online, count)}]</code> {online}/{count} ✅\n<b>Ver:</b> <code>[{progress_bar(cur, count)}]</code> {cur}/{count}",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except: pass

            with ThreadPoolExecutor(max_workers=min(len(accs), 20)) as ex:
                list(ex.map(fv_one, accs))

            bot_status.update(last_run=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                total_generated=len(accs), total_activated=online, total_verified=vj[0])
            reset_stop_event()
            r = f"🎉 <b>FULL PIPELINE COMPLETE! (YOUR ACCOUNTS)</b>\n\n"
            r += f"<b>Gen:</b> <code>[{progress_bar(len(accs), count)}]</code> {len(accs)}/{count} ✅\n"
            r += f"<b>Act:</b> <code>[{progress_bar(online, count)}]</code> {online}/{count} ✅\n"
            r += f"<b>Ver:</b> <code>[{progress_bar(vj[0], count)}]</code> {vj[0]}/{count} ✅\n"
            r += f"Status: {'✅ ALL VALID' if vj[0] == count else '⚠️ PARTIAL'}\n\n<b>🔑 YOUR CREDENTIALS:</b>\n"
            for i, a in enumerate(accs, 1):
                r += f"{i}. UID: <code>{a['uid']}</code>\n   PWD: <code>{a['password']}</code>\n   AccID: <code>{a.get('account_id','')}</code>\n   Name: {a['name']}\n\n"
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception as e:
            reset_stop_event()
            try: bot.edit_message_text(f"❌ Pipeline error: {e}", m.chat.id, sm.message_id)
            except: pass
    threading.Thread(target=run, daemon=True).start()

@bot.message_handler(commands=['accounts'])
def cmd_accounts(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    accs = read_user_accounts(uid)
    if not accs: return bot.reply_to(m, "❌ No accounts. Use /gen.")
    t = f"📋 <b>YOUR ACCOUNTS: {len(accs)}</b>\n━━━━━━━━━━━━━━━━━━━━━━\n\n"
    for i, a in enumerate(accs, 1):
        t += f"<b>#{i}</b>\n• UID: <code>{a['uid']}</code>\n• PWD: <code>{a['password']}</code>\n• AccID: <code>{a.get('account_id','')}</code>\n• Name: {a['name']}\n• Region: {a.get('region','N/A')}\n\n"
    if len(t) > 4000:
        for part in [t[i:i+4000] for i in range(0, len(t), 4000)]:
            bot.send_message(m.chat.id, part, parse_mode="HTML")
    else:
        bot.send_message(m.chat.id, t, parse_mode="HTML")

@bot.message_handler(commands=['allaccounts'])
def cmd_allaccounts(m):
    """Admin command: list ALL accounts from ALL user folders."""
    if not is_admin(m.from_user.id): return bot.reply_to(m, "⛔ Access Denied.")
    users_dir = os.path.join(BASE_DIR, "POPPY_USERS")
    if not os.path.exists(users_dir):
        return bot.reply_to(m, "📋 <b>No users have generated accounts yet.</b>", parse_mode="HTML")
    all_accounts = []
    for chat_id in os.listdir(users_dir):
        user_folder = os.path.join(users_dir, chat_id)
        if not os.path.isdir(user_folder): continue
        accs = read_user_accounts(int(chat_id))
        for a in accs:
            all_accounts.append((chat_id, a))
    if not all_accounts:
        return bot.reply_to(m, "📋 <b>No accounts found in any user folder.</b>", parse_mode="HTML")
    # Send in chunks of 4000 chars
    header = f"📋 <b>ALL ACCOUNTS ({len(all_accounts)} total from {sum(1 for _ in os.listdir(users_dir) if os.path.isdir(os.path.join(users_dir, _)))} users)</b>\n\n"
    chunk = ""
    parts = []
    for i, (uid, a) in enumerate(all_accounts, 1):
        line = f"<b>#{i}</b> 👤{uid}\n• UID: <code>{a['uid']}</code>\n• PWD: <code>{a['password']}</code>\n• AccID: <code>{a.get('account_id','')}</code>\n• Name: {a.get('name','N/A')}\n• Region: {a.get('region','N/A')}\n\n"
        if len(chunk + line) > 3800:
            parts.append(chunk)
            chunk = ""
        chunk += line
    if chunk:
        parts.append(chunk)
    for i, part in enumerate(parts):
        msg = (header + part) if i == 0 else part
        if len(msg) > 4096:
            msg = msg[:4090] + "..."
        try: bot.send_message(m.chat.id, msg, parse_mode="HTML")
        except: pass

@bot.message_handler(commands=['status'])
def cmd_status(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    accs, toks = read_user_accounts(uid), read_user_tokens(uid)
    proxies = load_user_proxies(uid)
    good = [p for p in proxies if p.get("status") == "GOOD"]
    t = "📊 <b>BOT STATUS</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
    t += f"🔄 Generating: {'⏳' if bot_status['generating'] else '✅'}\n⚡ Activating: {'⏳' if bot_status['activating'] else '✅'}\n"
    t += f"🔍 Verifying: {'⏳' if bot_status['verifying'] else '✅'}\n⏰ Last run: {bot_status['last_run'] or 'Never'}\n\n"
    t += f"📈 Generated: {bot_status['total_generated']}\n📈 Activated: {bot_status['total_activated']}\n📈 Verified: {bot_status['total_verified']}\n\n"
    t += f"👤 <b>YOUR STATS:</b>\n• Accounts: {len(accs)}\n• Tokens: {len(toks)}\n• Proxies: {len(good)} good / {len(proxies)} total\n• Proxy rotation: every {ACCOUNTS_PER_PROXY} accounts"
    bot.send_message(m.chat.id, t, parse_mode="HTML")

@bot.message_handler(commands=['clear'])
def cmd_clear(m):
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    mk = types.InlineKeyboardMarkup()
    mk.add(types.InlineKeyboardButton("✅ YES", callback_data="clear_yes"),
           types.InlineKeyboardButton("❌ Cancel", callback_data="clear_no"))
    bot.send_message(m.chat.id, "⚠️ <b>Clear YOUR account data?</b>\n(Only your folder will be deleted, not others.)", reply_markup=mk, parse_mode="HTML")

@bot.callback_query_handler(func=lambda c: c.data.startswith("clear_"))
def cb_clear(c):
    uid = c.from_user.id
    if c.data == "clear_yes":
        folder = get_user_folder(uid)
        import shutil
        if os.path.exists(folder):
            shutil.rmtree(folder, ignore_errors=True)
            # Clear accounts.json used by activator
            if os.path.exists(os.path.join(BASE_DIR, "accounts.json")):
                os.remove(os.path.join(BASE_DIR, "accounts.json"))
            bot.edit_message_text("🗑 <b>Your account data cleared.</b>", c.message.chat.id, c.message.message_id, parse_mode="HTML")
        else:
            bot.edit_message_text("❌ Nothing to clear.", c.message.chat.id, c.message.message_id, parse_mode="HTML")
    else:
        bot.edit_message_text("❌ <b>Cancelled.</b>", c.message.chat.id, c.message.message_id, parse_mode="HTML")

@bot.message_handler(func=lambda m: True)
def echo(m):
    if not is_admin(m.from_user.id): return bot.reply_to(m, "⛔ Access Denied.")
    bot.reply_to(m, "❓ Unknown command. Use /help.", parse_mode="HTML")

# ========== STOP COMMAND & CALLBACK (halt all running processes) ==========
@bot.message_handler(commands=['stop'])
def cmd_stop(m):
    """Stop any running generation / activation / verification immediately."""
    if not is_admin(m.from_user.id): return bot.reply_to(m, "⛔ Access Denied.")
    was = stop_all(reason="command")
    if was:
        bot.reply_to(m, "🛑 <b>All processes stopped.</b>\n\nAny accounts already saved are kept.", parse_mode="HTML")
    else:
        bot.reply_to(m, "✅ <b>Nothing is currently running.</b>", parse_mode="HTML")


@bot.callback_query_handler(func=lambda c: c.data == "stop_now")
def cb_stop_now(c):
    """Inline 🛑 STOP button callback."""
    if not is_admin(c.from_user.id):
        try: bot.answer_callback_query(c.id, "⛔ Access Denied.")
        except: pass
        return
    was = stop_all(reason="button")
    try:
        bot.answer_callback_query(c.id, "🛑 Stopping processes..." if was else "Nothing running.")
    except: pass
    try:
        bot.edit_message_text(
            "🛑 <b>Process stopped.</b>\n\nAny accounts already saved are kept.",
            c.message.chat.id, c.message.message_id, parse_mode="HTML")
    except: pass


# ========== PERSISTENCE (survive Render redeploys) ==========
import persist as _persist


def backup_now():
    """Snapshot user data (proxies + accounts) to the DB if persistence is enabled."""
    try:
        if _persist.enabled():
            _persist.backup_all(BASE_DIR)
    except Exception:
        pass


# ========== GLOBAL 429-SAFE EXCEPTION HANDLER ==========
import telebot as _tb
from telebot import apihelper

_ORIG_MAKE_REQUEST = apihelper._make_request


def _make_request_429_safe(*args, **kwargs):
    """
    NON-BLOCKING rate-limit safety wrapper.

    IMPORTANT: this wrapper NEVER sleeps. Sleeping inside apihelper._make_request
    blocks the polling/getUpdates loop (and any handler that calls send/edit), which
    made the bot appear completely hung (30s+ freeze on every 429/409).

    Instead:
      - getUpdates on 429/409 -> return [] immediately so the poll loop keeps running.
      - every other method     -> re-raise; callers already guard with try/except
                                  (progress edits use `except: pass`, send_html_chunks
                                  has its own 429 retry/backoff loop).
    """
    try:
        return _ORIG_MAKE_REQUEST(*args, **kwargs)
    except Exception as e:
        err_code = getattr(getattr(e, "result", None), "error_code", None)
        err_str = str(e)
        is_429 = (err_code == 429) or ("429" in err_str)
        is_409 = (err_code == 409) or ("409" in err_str) or ("Conflict" in err_str)
        if not (is_429 or is_409):
            raise
        joined = " ".join(str(a) for a in args) + " " + " ".join(str(v) for v in kwargs.values())
        # get_updates must return an iterable or telebot crashes.
        if "getUpdates" in joined or "/getUpdates" in joined:
            return []
        # Non-polling calls: let the caller's own try/except handle it (no sleep).
        raise


# Patch the Telegram API request function globally.
try:
    apihelper._make_request = _make_request_429_safe
except Exception:
    pass


# ========== KEEP-ALIVE (prevent Render free-instance auto-sleep) ==========
def keep_alive_loop():
    """
    Periodically ping the app's public URL (RENDER_URL) so Render's free tier
    does NOT spin the instance down after ~15 min of inactivity.

    Telegram long-polling is outbound traffic and does NOT count as inbound
    requests, so without this the instance would sleep and the bot would take
    50+ seconds to respond after a period of no activity.

    Set RENDER_URL env var to your Render public URL, e.g.
        https://poppy-gen-bot.onrender.com
    The loop also pings the local /health endpoint as a fallback.
    """
    import requests as _rq
    import urllib3 as _ul
    _ul.disable_warnings(_ul.exceptions.InsecureRequestWarning)
    public_url = os.environ.get("RENDER_URL", "").strip().rstrip("/")
    local_url = "http://127.0.0.1:" + os.environ.get("PORT", "8000") + "/health"
    while True:
        try:
            time.sleep(240)  # ping every 4 minutes (< 15 min threshold)
            # 1) Local health endpoint (keeps Flask served / process active)
            try:
                _rq.get(local_url, timeout=5, verify=False)
            except Exception:
                pass
            # 2) Public Render URL via external request path (if set)
            if public_url:
                try:
                    _rq.get(public_url + "/health", timeout=10, verify=False)
                except Exception:
                    pass
        except Exception:
            pass


if __name__ == "__main__":
    import sys as _sys
    if hasattr(_sys.stdout, "reconfigure"):
        _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("=" * 60)
    print("[ROCKET] POPPY GUEST MANAGER BOT v3")
    print("   Per-user isolation + Proxy rotation")
    print("=" * 60)
    print(f"[OK] Gen: {os.path.basename(GEN_SCRIPT)}")
    print(f"[OK] Activator: {os.path.basename(ACTIVATOR_SCRIPT)}")
    print(f"[OK] Proxy rotation: every {ACCOUNTS_PER_PROXY} accounts")
    print("=" * 60)
    # Start the Flask web server in a background thread so Render's health check passes
    if WEB_AVAILABLE and WEB_APP is not None:
        port = int(os.environ.get("PORT", 8000))
        print(f"[WEB] Starting health-check server on port {port}...")
        threading.Thread(target=WEB_APP.run,
                         kwargs={"host": "0.0.0.0", "port": port, "use_reloader": False, "threaded": True},
                         daemon=True).start()
    else:
        print("[WEB] Flask not available — skipping web server (polling only).")
    # Restore persisted user data (proxies + accounts) so redeploys don't lose them.
    try:
        if _persist.enabled():
            got = _persist.restore_all(BASE_DIR)
            print(f"[DB] Persistence enabled. Restored user data: {got}")
        else:
            print("[DB] SUPABASE_URL/KEY not set - persistence disabled. Set them to survive redeploys.")
    except Exception as e:
        print(f"[DB] Restore error: {e}")
    # Backup periodically in the background so data is safe even without a redeploy.
    def _bg_backup():
        import time as _t
        while True:
            _t.sleep(600)  # every 10 minutes
            backup_now()
    try:
        threading.Thread(target=_bg_backup, daemon=True).start()
    except Exception:
        pass
    # Keep-alive: prevent Render free-instance auto-sleep (pings every 4 min)
    try:
        threading.Thread(target=keep_alive_loop, daemon=True).start()
        print("[KEEP] Keep-alive heartbeat started (every 240s). Set RENDER_URL to your public Render URL for best effect.")
    except Exception as e:
        print(f"[KEEP] Could not start keep-alive: {e}")
    print("[BOT] Starting bot polling...")
    while True:
        try:
            bot.infinity_polling()
            break
        except KeyboardInterrupt:
            print("\n👋 Bot stopped")
            break
        except Exception as e:
            err = str(e)
            # 409 Conflict = another instance polling same token. Wait, don't spin CPU.
            if "409" in err or "Conflict" in err:
                print("[BOT] 409 Conflict (another instance polling). Waiting 30s...")
                time.sleep(30)
            else:
                print(f"[BOT] Polling retry after error: {err}")
                time.sleep(5)