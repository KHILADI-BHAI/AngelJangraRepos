with open('bot.py', 'r', encoding='utf-8') as f:
    c = f.read()

changes = []
WORKER = "proxy_worker.py"

# ============================================================
# 1) Add a helper to run the worker subprocess with a hard timeout.
#    Insert it right after the `_run_with_timeout` definition.
# ============================================================
anchor = '''def _run_with_timeout(func, timeout, *args, **kwargs):
    """Run func(*args, **kwargs) in a background thread and wait up to `timeout` seconds.
    Returns (True, result) on success, (False, None) on timeout/error."""
    import queue as _q
    out = _q.Queue()
    def _target():
        try:
            out.put((True, func(*args, **kwargs)))
        except Exception as e:
            out.put((False, e))
    t = threading.Thread(target=_target, daemon=True)
    t.start()
    try:
        return out.get(timeout=timeout)
    except _q.Empty:
        return (False, TimeoutError("operation timed out"))'''

anchor_new = anchor + '''


def run_proxy_worker(args, timeout, on_progress=None):
    """Launch proxy_worker.py as a SEPARATE PROCESS so the bot can never hang on
    network work. Reads its stdout lines; calls on_progress(done,good,blocked,dead)
    for each 'PROGRESS n g b d' line. Kills the process after `timeout` seconds.
    Returns the final results list (JSON) written by the worker, or [] on timeout."""
    import queue as _q
    worker = os.path.join(BASE_DIR, WORKER)
    cmd = [sys.executable, "-u", worker] + args
    results = []
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, encoding="utf-8", errors="replace",
                             bufsize=1, cwd=BASE_DIR)
        register_proc(p)
        q = _q.Queue()

        def _reader():
            try:
                for line in p.stdout:
                    q.put(line)
            except Exception:
                pass
            finally:
                q.put(None)

        threading.Thread(target=_reader, daemon=True).start()
        start = time.time()
        while True:
            remaining = timeout - (time.time() - start)
            if remaining <= 0:
                break
            try:
                line = q.get(timeout=remaining)
            except _q.Empty:
                break  # wall-clock timeout reached
            if line is None:
                break  # worker exited
            line = line.strip()
            if line.startswith("PROGRESS "):
                parts = line.split()
                if len(parts) == 5:
                    try:
                        done, good, blocked, dead = (int(parts[1]), int(parts[2]),
                                                     int(parts[3]), int(parts[4]))
                        if on_progress:
                            on_progress(done, good, blocked, dead)
                    except Exception:
                        pass
        if p and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass
        unregister_proc(p)
    except Exception:
        pass
    # Load whatever results the worker wrote incrementally.
    out_arg = args[1] if len(args) >= 2 else ""
    if out_arg:
        try:
            with open(os.path.join(BASE_DIR, out_arg), encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    results = data
        except Exception:
            results = []
    return results'''

if anchor in c:
    c = c.replace(anchor, anchor_new, 1)
    changes.append('added run_proxy_worker helper')
else:
    changes.append('run_proxy_worker helper: ANCHOR NOT FOUND')

# ============================================================
# 2) Rewrite cmd_addproxies to delegate to the worker process.
# ============================================================
old_add = '''    total = len(args)
    sm = bot.send_message(m.chat.id, f"🔍 <b>Checking {total} proxies (2-step)...</b>\\n\\n<code>[{progress_bar(0, total)}]</code> 0/{total}", parse_mode="HTML")
    save_lock = threading.Lock()
    existing = load_user_proxies(uid)

    def run():
        # Map raw proxy -> check result, populated by on_progress
        check_results = {}
        last_edit = [0.0]
        def on_progress(done, p, status, msg, good, blocked, dead):
            check_results[p] = (status, msg)
            # Throttle edits to 1 per 1.5s to avoid Telegram 429 rate-limit storms
            now = time.time()
            if now - last_edit[0] >= 1.5:
                last_edit[0] = now
                try:
                    bot.edit_message_text(
                        f"🔍 <b>Checking {total} proxies (2-step)...</b>\\n\\n"
                        f"<code>[{progress_bar(done, total)}]</code> {done}/{total} checked\\n"
                        f"✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except: pass
            # INCREMENTAL SAVE: immediately persist GOOD proxies so crash won't lose them
            if status == "GOOD":
                with save_lock:
                    existing.append({"proxy": format_proxy(p), "status": status, "msg": msg})
                    save_user_proxies(uid, list(existing))
        check_proxies_parallel(args, batch_size=10, on_progress=on_progress)
        results = []
        for raw in args:
            status, msg = check_results.get(raw, ("BAD", "Unknown"))
            emoji = "✅" if status == "GOOD" else ("🚫" if status == "BLOCKED" else "❌")
            results.append(f"{emoji} <code>{raw}</code> → {status}: {msg}")
        good_count = sum(1 for p in existing if p.get("status") == "GOOD")
        r = f"✅ <b>Proxy check complete! (saved incrementally)</b>\\n\\n<code>[{progress_bar(total, total)}]</code> {total}/{total}\\n\\n" + "\\n".join(results[-10:] if len(results) > 10 else results)
        r += f"\\n\\n<b>Total good: {good_count}/{total}</b> (saved to your proxy list)"
        try: bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except: pass
        backup_now()
    threading.Thread(target=run, daemon=True).start()'''

new_add = '''    total = len(args)
    sm = bot.send_message(m.chat.id, f"🔍 <b>Checking {total} proxies (2-step)...</b>\\n\\n<code>[{progress_bar(0, total)}]</code> 0/{total}", parse_mode="HTML")

    def run():
        existing = load_user_proxies(uid)
        last_edit = [0.0]
        out_file = os.path.join(BASE_DIR, "worker_results.json")

        def on_progress(done, good, blocked, dead):
            now = time.time()
            if now - last_edit[0] >= 1.5:
                last_edit[0] = now
                try:
                    bot.edit_message_text(
                        f"🔍 <b>Checking {total} proxies (2-step)...</b>\\n\\n"
                        f"<code>[{progress_bar(done, total)}]</code> {done}/{total} checked\\n"
                        f"✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass

        # All network checks run in a SEPARATE PROCESS; the bot never blocks.
        results = run_proxy_worker(["check", out_file] + list(args), timeout=180, on_progress=on_progress)
        # Merge GOOD/SLOW results into the user's saved proxies
        added = 0
        for r in results:
            if r.get("status") == "GOOD":
                existing.append({"proxy": r["proxy"], "status": "GOOD", "msg": r.get("msg", "")})
                added += 1
        if added:
            save_user_proxies(uid, list(existing))
        good_count = sum(1 for p in existing if p.get("status") == "GOOD")
        lines = []
        for r in results[-10:]:
            st = r.get("status", "BAD")
            emoji = "✅" if st == "GOOD" else ("🚫" if st == "BLOCKED" else "❌")
            lines.append(f"{emoji} <code>{r.get('proxy','')}</code> → {st}: {r.get('msg','')}")
        r = f"✅ <b>Proxy check complete!</b>\\n\\n<code>[{progress_bar(total, total)}]</code> {total}/{total}\\n\\n" + "\\n".join(lines)
        r += f"\\n\\n<b>Total good: {good_count}/{total}</b> (saved to your proxy list)"
        try:
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception:
            pass
        backup_now()

    threading.Thread(target=run, daemon=True).start()'''

if old_add in c:
    c = c.replace(old_add, new_add, 1)
    changes.append('cmd_addproxies -> worker process')
else:
    changes.append('cmd_addproxies: PATTERN_NOT_FOUND')

with open('bot.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\n'.join(changes))
