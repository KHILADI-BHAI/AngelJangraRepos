# persist.py - Persistent storage so user data (proxies + accounts) survives Render redeploys.
#
# Render's free tier uses an EPHEMERAL filesystem that is wiped on every redeploy/restart.
# This module stores the bot's user data (user_proxies.json + POPPY_USERS folders) as a single
# JSON document in a Supabase Postgres table, and restores it on startup.
#
# Supabase IS Postgres, so you have TWO ways to enable persistence (no SQL editor needed):
#
#   OPTION A (recommended - fully automatic, NO SQL editor):
#     Set DATABASE_URL to Supabase's Postgres connection string:
#       postgresql://postgres.[ref]:[password]@aws-0-[region].pooler.supabase.com:5432/postgres
#       (or the direct string: postgresql://postgres:[password]@db.[ref].supabase.co:5432/postgres)
#     With this, the code AUTO-CREATES the table on first run using CREATE TABLE IF NOT EXISTS.
#
#   OPTION B (Supabase REST client):
#     Set SUPABASE_URL and SUPABASE_KEY.
#     This uses the REST API (port 443, always open). It ALSO auto-creates the table by
#     running SQL through the connection string if DATABASE_URL is also set; otherwise it
#     makes a best-effort and prints a clear one-time setup hint.
#
# If none of these are set, this module is a no-op (bot uses local files as before).

import os
import json


def _db_url():
    return os.environ.get("DATABASE_URL", "").strip()


def _supabase_url():
    return os.environ.get("SUPABASE_URL", "").strip()


def _supabase_key():
    return os.environ.get("SUPABASE_KEY", "").strip()


def enabled():
    """True if any Supabase/Postgres persistence is configured."""
    return bool(_db_url()) or (bool(_supabase_url()) and bool(_supabase_key()))


def _connect_pg():
    """Open a direct Postgres connection to Supabase using pg8000 (pure Python).

    pg8000 >= 1.31 does NOT have Connection.from_url, so we parse the URL manually.
    Supabase strings look like:
      postgresql://postgres:PASSWORD@db.REF.supabase.co:5432/postgres
    The password may contain special chars (@, :, etc.), and if it contains an '@'
    it's often NOT percent-encoded. So instead of urlsplit (which would break on the
    '@' in the password), we find the LAST '@' before the host and split around it.
    """
    import pg8000.native
    url = _db_url().strip()
    # Strip scheme
    if "://" in url:
        scheme, rest = url.split("://", 1)
        if scheme not in ("postgres", "postgresql"):
            raise ValueError(f"Unsupported DATABASE_URL scheme: {scheme}")
    else:
        rest = url
    # Split host/db from userinfo at the LAST '@' (the password may contain '@').
    # Format: user:pass@host:port/db   -> the last '@' is the real separator.
    userinfo, _, hostpart = rest.rpartition("@")
    # userinfo = "user:pass", hostpart = "host:port/db"
    if ":" in userinfo:
        user, _, password = userinfo.partition(":")
    else:
        user, password = userinfo, ""
    # hostpart = "host:port/db"  -> split db
    if "/" in hostpart:
        host_n_port, _, database = hostpart.partition("/")
    else:
        host_n_port, database = hostpart, "postgres"
    # host_n_port = "host:port"
    if ":" in host_n_port:
        host, _, port_s = host_n_port.rpartition(":")
        try:
            port = int(port_s)
        except ValueError:
            port = 5432
    else:
        host, port = host_n_port, 5432
    if not host:
        raise ValueError("Could not parse host from DATABASE_URL")
    return pg8000.native.Connection(
        user=user, password=password, host=host, port=port, database=database or "postgres"
    )


def _init_pg():
    """Auto-create the snapshot table via direct SQL - NO SQL editor needed."""
    con = _connect_pg()
    try:
        con.run(
            "CREATE TABLE IF NOT EXISTS poppy_snapshots ("
            "  k text PRIMARY KEY,"
            "  data text"
            ")"
        )
    finally:
        con.close()


def _set_pg(key, data):
    _init_pg()
    con = _connect_pg()
    try:
        con.run(
            "INSERT INTO poppy_snapshots (k, data) VALUES (:k, :d) "
            "ON CONFLICT (k) DO UPDATE SET data = EXCLUDED.data",
            k=key, d=data,
        )
    finally:
        con.close()


def _get_pg(key):
    _init_pg()
    con = _connect_pg()
    try:
        rows = con.run("SELECT data FROM poppy_snapshots WHERE k = :k", k=key)
        return rows[0][0] if rows else None
    finally:
        con.close()


# ---------------- Supabase REST client fallback ----------------
def _client():
    from supabase import create_client
    return create_client(_supabase_url().rstrip("/"), _supabase_key())


def _init_rest():
    """Best-effort REST init. If DATABASE_URL is available, create the table via SQL.
    Otherwise, if the table is missing, print a clear one-time setup hint."""
    # If we have the connection string, just create the table directly.
    if _db_url():
        try:
            _init_pg()
            return
        except Exception:
            pass
    # Otherwise try REST - if the table is missing, give a clear hint.
    client = _client()
    try:
        client.table("poppy_snapshots").select("k").limit(1).execute()
    except Exception:
        print(
            "[DB] Supabase table 'poppy_snapshots' not found via REST. "
            "Either set DATABASE_URL (auto-creates the table, recommended) or run this "
            "once in the Supabase SQL editor:\n"
            "  create table if not exists poppy_snapshots (k text primary key, data text);"
        )
        raise


def _set_rest(key, data):
    client = _client()
    client.table("poppy_snapshots").upsert(
        {"k": key, "data": data}, on_conflict="k"
    ).execute()


def _get_rest(key):
    client = _client()
    res = client.table("poppy_snapshots").select("data").eq("k", key).execute()
    rows = res.data
    if rows and len(rows) > 0:
        return rows[0].get("data")
    return None


def _set(key, data):
    if _db_url():
        _set_pg(key, data)
    else:
        _init_rest()
        _set_rest(key, data)


def _get(key):
    if _db_url():
        return _get_pg(key)
    return _get_rest(key)


SNAPSHOT_KEY = "poppy_user_data_v1"


def backup_all(base_dir):
    """Serialize all user data (proxies + POPPY_USERS folders) and store in Supabase."""
    if not enabled():
        return False
    data = {"proxies": None, "users": {}}

    # user_proxies.json
    pf = os.path.join(base_dir, "user_proxies.json")
    if os.path.exists(pf):
        try:
            with open(pf, encoding="utf-8") as f:
                data["proxies"] = json.load(f)
        except Exception:
            data["proxies"] = None

    # POPPY_USERS/<chat_id>/ACCOUNTS + TOKENS-JWT
    users_dir = os.path.join(base_dir, "POPPY_USERS")
    if os.path.isdir(users_dir):
        for chat in os.listdir(users_dir):
            folder = os.path.join(users_dir, chat)
            if not os.path.isdir(folder):
                continue
            u = {"accounts": {}, "tokens": {}}
            # accounts
            acc_dir = os.path.join(folder, "ACCOUNTS")
            if os.path.isdir(acc_dir):
                for fn in os.listdir(acc_dir):
                    if fn.endswith(".json"):
                        try:
                            with open(os.path.join(acc_dir, fn), encoding="utf-8") as f:
                                u["accounts"][fn] = json.load(f)
                        except Exception:
                            pass
            # tokens
            tok_dir = os.path.join(folder, "TOKENS-JWT")
            if os.path.isdir(tok_dir):
                for fn in os.listdir(tok_dir):
                    if fn.endswith(".json"):
                        try:
                            with open(os.path.join(tok_dir, fn), encoding="utf-8") as f:
                                u["tokens"][fn] = json.load(f)
                        except Exception:
                            pass
            data["users"][chat] = u

    try:
        _set(SNAPSHOT_KEY, json.dumps(data))
        return True
    except Exception as e:
        print(f"[DB] backup_all error: {type(e).__name__}: {e}")
        return False


def restore_all(base_dir):
    """Restore user data from Supabase back to local files (called at startup)."""
    if not enabled():
        return False
    try:
        raw = _get(SNAPSHOT_KEY)
    except Exception as e:
        print(f"[DB] restore_all _get error: {type(e).__name__}: {e}")
        return False
    if not raw:
        print("[DB] restore_all: no snapshot data found in DB (first run?)")
        return False
    try:
        data = json.loads(raw)
    except Exception:
        print("[DB] restore_all: snapshot data is not valid JSON")
        return False

    # proxies
    if data.get("proxies") is not None:
        try:
            pf = os.path.join(base_dir, "user_proxies.json")
            with open(pf, "w", encoding="utf-8") as f:
                json.dump(data["proxies"], f, indent=2)
        except Exception:
            pass

    # user folders
    for chat, u in (data.get("users") or {}).items():
        base_user = os.path.join(base_dir, "POPPY_USERS", chat)
        acc_dir = os.path.join(base_user, "ACCOUNTS")
        tok_dir = os.path.join(base_user, "TOKENS-JWT")
        os.makedirs(acc_dir, exist_ok=True)
        os.makedirs(tok_dir, exist_ok=True)
        for fn, lst in (u.get("accounts") or {}).items():
            try:
                with open(os.path.join(acc_dir, fn), "w", encoding="utf-8") as f:
                    json.dump(lst, f, indent=2, ensure_ascii=False)
            except Exception:
                pass
        for fn, lst in (u.get("tokens") or {}).items():
            try:
                with open(os.path.join(tok_dir, fn), "w", encoding="utf-8") as f:
                    json.dump(lst, f, indent=2, ensure_ascii=False)
            except Exception:
                pass
    return True
