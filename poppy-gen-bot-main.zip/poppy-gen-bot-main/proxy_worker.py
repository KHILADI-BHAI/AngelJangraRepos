#!/usr/bin/env python3
"""
proxy_worker.py - Standalone proxy checker that runs in its OWN PROCESS.

The Telegram bot launches this script as a subprocess for ALL network-heavy
proxy work (freeproxies fetch, addproxies, proxy-file import, checkproxies).
This guarantees the bot process itself never blocks on a slow network call:
if the worker hangs, the bot simply kills it after a hard timeout.

KEY FIX: Unlike the old version (which had NO total wall-clock cap), this worker
now enforces its own OVERALL deadline. Even if every proxy source hangs on DNS,
or 1000 proxies each take 1.5s+, the worker stops, writes the partial results it
has, and exits. The bot then shows "N checked" instead of appearing stuck.

Usage:
  python proxy_worker.py check <out_file> <proxy1> <proxy2> ...
  python proxy_worker.py freeproxies <out_file>

Progress is printed to stdout as:
  FETCHED <n>                              (freeproxies only)
  PROGRESS <done> <good> <blocked> <dead>
  DONE

Results are written INCREMENTALLY to <out_file> as a JSON list:
  [{"proxy": "...", "status": "GOOD|BLOCKED|UNRESPONSIVE|SLOW|BAD", "msg": "..."}]
so the bot can recover whatever was checked even if the worker is killed.
"""
import sys
import os
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

CHUNK = 50          # process this many proxies before the next chunk
BATCH = 10          # parallel threads per batch
MAX_FREE = 300      # cap on how many free proxies we check

# HARD TOTAL BUDGETS (seconds). The worker self-terminates after
# timeout_budget regardless of how many proxies remain, then writes
# whatever it checked so far — so it can never hang for hours.
FETCH_TIMEOUT = 30          # total time for fetching from 3 sources
CHECK_TIMEOUT = 240         # total time for the whole check phase
PER_PROXY_EXTRA = 1.5       # budget added per proxy (up to the hard cap)


def format_proxy(p):
    """Normalize a proxy string to 'http://user:pass@host:port'."""
    p = p.strip()
    if not p:
        return None
    if "://" in p:
        scheme, rest = p.split("://", 1)
        scheme = scheme.lower()
        if scheme.startswith("socks"):
            scheme = "http"
        p = rest
    else:
        scheme = "http"
    if "@" in p:
        auth_part, host_part = p.rsplit("@", 1)
        if ":" in host_part:
            return f"{scheme}://{auth_part}@{host_part}"
        return None
    else:
        if ":" in p:
            return f"{scheme}://{p}"
        return None


def check_proxy_2step(proxy):
    """Two-step check: 1) responsiveness 2) Garena block status."""
    import requests
    proxy = format_proxy(proxy)
    if not proxy:
        return "BAD", "Empty"
    proxies = {"http": proxy, "https": proxy}
    # STEP 1: responsiveness (tight timeout to match gen.py's 1.6s budget)
    try:
        r = requests.get("https://www.google.com/generate_204",
                         proxies=proxies, timeout=(1.0, 1.5), verify=False)
        if r.status_code >= 500:
            return "UNRESPONSIVE", "Step1: no response"
    except Exception:
        return "UNRESPONSIVE", "Step1: unreachable"
    # STEP 2: Garena block check
    try:
        payload = {"app_id": 100067, "client_type": 2,
                   "password": "PP_TestProxy_4242", "source": 2}
        headers = {"User-Agent": "GarenaMSDK/4.0.39(SM-A325M;Android 13;en;HK;)",
                   "Accept": "application/json",
                   "Content-Type": "application/json; charset=utf-8"}
        r = requests.post("https://100067.connect.garena.com/api/v2/oauth/guest:register",
                          proxies=proxies, headers=headers, json=payload,
                          timeout=(1.0, 1.5), verify=False)
        text = r.text
        if r.status_code == 200 and '"data"' in text:
            return "GOOD", "Ready for generation"
        if any(b in text.lower() for b in ["block", "forbidden", "captcha"]):
            return "BLOCKED", "Step2: blocked by Garena"
        return "GOOD", "Reaches Garena (not blocked)"
    except Exception:
        return "BLOCKED", "Step2: cannot reach Garena"


def fetch_freeproxies_all():
    """Fetch proxies from 3 sources: roundproxies, ProxyScrape, GeoNode.
    Each request has a 10s timeout and the whole fetch is bounded by
    `deadline` passed in (checked between sources).

    CRITICAL: these fetches ALWAYS use a DIRECT connection (proxies=None/None).
    `requests` honors HTTP_PROXY/HTTPS_PROXY/ALL_PROXY env vars by default; if
    the host has one set, fetching free proxies would route through it and can
    stall or fail. The proxy list we're fetching is meant to be used LATER for
    Garena generation — the fetch itself must not go through a proxy."""
    import requests
    proxies_raw = set()
    # Direct connection: build a Session with trust_env=False (trust_env is a
    # Session attribute, NOT a requests.get() kwarg — passing it to get() raises
    # an instant TypeError). Empty proxies dict + trust_env=False on the Session
    # forces a direct connection that ignores HTTP_PROXY/HTTPS_PROXY/ALL_PROXY.
    no_proxy = {}
    _sess = requests.Session()
    _sess.trust_env = False
    _sess.proxies = no_proxy
    try:
        r = _sess.get("https://roundproxies.com/api/get-free-proxies/",
                      timeout=10, verify=False)
        if r.status_code == 200:
            data = r.json()
            raw_list = data.get("data", []) if isinstance(data, dict) else data
            for item in raw_list:
                ip, port = item.get("ip"), item.get("port")
                protos = item.get("protocols", [])
                if ip and port and ("http" in protos or "https" in protos):
                    proxies_raw.add(f"{ip}:{port}")
    except Exception as e:
        print(f"[roundproxies] Error: {e}")
    for proto in ["http", "https"]:
        try:
            r = _sess.get(
                f"https://api.proxyscrape.com/v2/?request=getproxies&protocol={proto}"
                f"&timeout=5&country=all&ssl=all&anonymous=all",
                timeout=10, verify=False)
            if r.status_code == 200 and r.text.strip():
                for line in r.text.strip().splitlines():
                    line = line.strip()
                    if line and ":" in line:
                        proxies_raw.add(line)
        except Exception as e:
            print(f"[proxyscrape {proto}] Error: {e}")
    try:
        r = _sess.get(
            "https://proxylist.geonode.com/api/proxy-list?limit=500&sort_by=speed&sort_type=asc",
            timeout=10, verify=False)
        if r.status_code == 200:
            data = r.json()
            raw_list = data.get("data", [])
            for item in raw_list:
                ip, port = item.get("ip"), item.get("port")
                protos = item.get("protocols", [])
                if ip and port and ("http" in protos or "https" in protos):
                    proxies_raw.add(f"{ip}:{port}")
    except Exception as e:
        print(f"[geonode] Error: {e}")
    return proxies_raw


def write_results(out_file, results):
    """Atomically write the results list to out_file. This is called only
    ONCE at the end (plus a final partial-dump on timeout), NOT after every
    single proxy — writing a full JSON list to disk 500 times in a row was a
    major slowdown."""
    tmp = out_file + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        os.replace(tmp, out_file)
    except Exception:
        pass


def main():
    if len(sys.argv) < 3:
        print("Usage: proxy_worker.py <check|freeproxies> <out_file> [proxies...]")
        sys.exit(1)
    cmd = sys.argv[1]
    out_file = sys.argv[2]

    # Whole-process wall-clock start — used for ALL hard budgets.
    proc_start = time.time()

    if cmd == "freeproxies":
        print("FETCHING")
        sys.stdout.flush()
        raw = fetch_freeproxies_all()
        proxies = list(raw)[:MAX_FREE]
        print(f"FETCHED {len(proxies)}")
        sys.stdout.flush()
    elif cmd == "check":
        proxies = sys.argv[3:]
    else:
        print(f"UNKNOWN_CMD {cmd}")
        sys.stdout.flush()
        sys.exit(1)

    if not proxies:
        write_results(out_file, [])
        print("DONE")
        sys.stdout.flush()
        return

    results = []
    done = good = blocked = dead = 0

    # Total budget for the check phase: bounded by both a base timeout and the
    # proxy count, so a huge list (e.g. 1000) cannot run forever. The bot also
    # has its own outer timeout that kills us, but we should never reach it.
    total_budget = CHECK_TIMEOUT + min(len(proxies) * PER_PROXY_EXTRA, 120)
    deadline = proc_start + total_budget

    # Process in chunks so memory stays bounded
    for cstart in range(0, len(proxies), CHUNK):
        if time.time() > deadline:
            # Hard deadline reached: stop, write partial results, exit cleanly.
            break
        chunk = proxies[cstart:cstart + CHUNK]
        with ThreadPoolExecutor(max_workers=BATCH, thread_name_prefix="pw") as ex:
            futures = {ex.submit(check_proxy_2step, p): p for p in chunk}
            for fut in as_completed(futures):
                p = futures[fut]
                st = time.time()
                try:
                    status, msg = fut.result()
                except Exception as e:
                    status, msg = "BAD", str(e)
                elapsed = time.time() - st
                # gen.py uses a 1.6s timeout per Garena request; proxies slower
                # than ~1.5s would stall generation -> mark SLOW (dropped by bot).
                if status == "GOOD" and elapsed > 1.5:
                    status = "SLOW"
                    msg = f"Too slow for generation ({elapsed:.1f}s)"
                results.append({"proxy": format_proxy(p), "status": status, "msg": msg})
                done += 1
                if status == "GOOD":
                    good += 1
                elif status == "BLOCKED":
                    blocked += 1
                else:
                    dead += 1
                print(f"PROGRESS {done} {good} {blocked} {dead}")
                sys.stdout.flush()
                if time.time() > deadline:
                    # Stop submitting new work once the deadline is hit
                    break
            # Cancel any pending futures (deadline reached)
            for fut in futures:
                if not fut.done():
                    fut.cancel()
            if time.time() > deadline:
                break

    # Single atomic write of all results (much faster than rewriting the file
    # after every single proxy, which was the old behavior).
    write_results(out_file, results)
    print("DONE")
    sys.stdout.flush()


if __name__ == "__main__":
    main()