with open('bot.py', 'r', encoding='utf-8') as f:
    c = f.read()

changes = []

# ============================================================
# Rewrite cmd_freeproxies to delegate to the worker process.
# ============================================================
old_fp = '''@bot.message_handler(commands=['freeproxies'])
def cmd_freeproxies(m):
    """Fetch free proxies from 3 sources in a BACKGROUND thread so the bot never
    blocks (DNS/HTTP hangs cannot freeze the bot), cap the count, and check them
    with throttled progress edits."""
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    sm = bot.send_message(m.chat.id, "🌐 <b>Fetching free proxies (3 sources)...</b>\\n• roundproxies.com\\n• ProxyScrape\\n• GeoNode", parse_mode="HTML")

    def run():
        last_edit = [0.0]
        try:
            # Fetch in a thread with a hard 45s cap so a stuck DNS/source never hangs.
            ok, proxies_raw = _run_with_timeout(fetch_freeproxies_all, 45)
            if not ok or not proxies_raw:
                bot.edit_message_text("❌ No http/https proxies fetched from any source (or fetch timed out).", m.chat.id, sm.message_id, parse_mode="HTML")
                return
            proxies_raw = list(proxies_raw)
            if len(proxies_raw) > 300:
                proxies_raw = proxies_raw[:300]
            total = len(proxies_raw)
            bot.edit_message_text(f"✅ Fetched {total} http/https proxies (3 sources). Starting 2-step check (parallel)...\\n\\n<code>[{progress_bar(0, total)}]</code> 0/{total}", m.chat.id, sm.message_id, parse_mode="HTML")
            save_lock = threading.Lock()
            existing = load_user_proxies(uid)
            check_results = {}

            def on_progress(done, p, status, msg, good, blocked, dead):
                check_results[p] = (status, msg)
                now = time.time()
                if now - last_edit[0] >= 1.5:
                    last_edit[0] = now
                    try:
                        bot.edit_message_text(
                            f"🔍 Checking {done}/{total} proxies (2-step parallel)\\n✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}\\n<code>[{progress_bar(done, total)}]</code>",
                            m.chat.id, sm.message_id, parse_mode="HTML")
                    except Exception:
                        pass
                if status == "GOOD":
                    with save_lock:
                        existing.append({"proxy": format_proxy(p), "status": "GOOD", "msg": msg})
                        save_user_proxies(uid, list(existing))

            check_proxies_parallel(proxies_raw, batch_size=10, on_progress=on_progress)
            good_count = sum(1 for p in load_user_proxies(uid) if p.get("status") == "GOOD")
            r = f"✅ <b>Free proxy import complete!</b>\\n\\n"
            r += f"Fetched {total} proxies (roundproxies + proxyscrape + geonode)\\n"
            r += f"\\n✅ Good: {sum(1 for p in existing if p.get('status')=='GOOD')}\\n🚫 Blocked: {sum(1 for p in existing if p.get('status')=='BLOCKED')}\\n❌ Dead: {sum(1 for p in existing if p.get('status')=='UNRESPONSIVE')}\\n"
            r += f"\\nGood proxies saved to your list immediately."
            try:
                bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass
            backup_now()
        except Exception as e:
            try:
                bot.edit_message_text(f"❌ <b>Fetch failed:</b> {e}\\n\\nMake sure you're online.", m.chat.id, sm.message_id, parse_mode="HTML")
            except Exception:
                pass

    threading.Thread(target=run, daemon=True).start()'''

new_fp = '''@bot.message_handler(commands=['freeproxies'])
def cmd_freeproxies(m):
    """Fetch + check free proxies entirely in a SEPARATE PROCESS so the bot can
    never hang. Even if the fetch hangs, the worker is killed after a timeout and
    the bot keeps responding."""
    uid = m.from_user.id
    if not is_admin(uid): return bot.reply_to(m, "⛔ Access Denied.")
    sm = bot.send_message(m.chat.id, "🌐 <b>Fetching free proxies (3 sources)...</b>\\n• roundproxies.com\\n• ProxyScrape\\n• GeoNode", parse_mode="HTML")

    def run():
        last_edit = [0.0]
        out_file = os.path.join(BASE_DIR, "worker_results.json")

        def on_progress(done, good, blocked, dead):
            now = time.time()
            if now - last_edit[0] >= 1.5:
                last_edit[0] = now
                try:
                    bot.edit_message_text(
                        f"🔍 Checking {done} proxies (2-step parallel)\\n✅ Good: {good} | 🚫 Blocked: {blocked} | ❌ Dead: {dead}\\n<code>[{progress_bar(done, done or 1)}]</code>",
                        m.chat.id, sm.message_id, parse_mode="HTML")
                except Exception:
                    pass

        # The whole fetch+check runs in a subprocess with a 6-minute hard cap.
        results = run_proxy_worker(["freeproxies", out_file], timeout=360, on_progress=on_progress)
        existing = load_user_proxies(uid)
        added = 0
        for r in results:
            if r.get("status") == "GOOD":
                existing.append({"proxy": r["proxy"], "status": "GOOD", "msg": r.get("msg", "")})
                added += 1
        if added:
            save_user_proxies(uid, list(existing))
        total = len(results)
        good_count = sum(1 for r in results if r.get("status") == "GOOD")
        blocked_count = sum(1 for r in results if r.get("status") == "BLOCKED")
        dead_count = total - good_count - blocked_count
        r = f"✅ <b>Free proxy import complete!</b>\\n\\n"
        r += f"Fetched {total} proxies (roundproxies + proxyscrape + geonode)\\n"
        r += f"\\n✅ Good: {good_count}\\n🚫 Blocked: {blocked_count}\\n❌ Dead/Slow: {dead_count}\\n"
        r += f"\\nGood proxies saved to your list."
        try:
            bot.edit_message_text(r, m.chat.id, sm.message_id, parse_mode="HTML")
        except Exception:
            pass
        backup_now()

    threading.Thread(target=run, daemon=True).start()'''

if old_fp in c:
    c = c.replace(old_fp, new_fp, 1)
    changes.append('cmd_freeproxies -> worker process')
else:
    changes.append('cmd_freeproxies: PATTERN_NOT_FOUND')

with open('bot.py', 'w', encoding='utf-8') as f:
    f.write(c)

print('\n'.join(changes))
