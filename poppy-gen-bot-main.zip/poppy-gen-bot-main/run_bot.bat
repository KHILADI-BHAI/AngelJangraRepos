@echo off
cd /d "C:\Users\Deep Studio\Downloads\Guest acc gen + activator"
set PYTHONIOENCODING=utf-8
echo ==========================================
echo   POPPY GUEST MANAGER - TELEGRAM BOT
echo ==========================================
echo.
echo  Make sure you set your BOT_TOKEN in bot.py first!
echo.
python -u bot.py
pause