#!/usr/bin/env python3
"""
ProxyChecker - 2-step proxy validation for Free Fire guest generation.
Step 1: Responsiveness check (proxy can reach the internet)
Step 2: Garena block check (proxy can reach Garena guest registration)
"""
import requests
import urllib3
import re
import sys
import os

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Test URLs
RESPONSIVENESS_URL = "https://www.google.com/generate_204"  # Fast, always reachable
GARENA_TEST_URL = "https://100067.connect.garena.com/api/v2/oauth/guest:register"

def format_proxy(p):
    """Normalize proxy string: add http:// if no scheme."""
    p = p.strip()
    if not p:
        return None
    if "://" not in p:
        p = "http://" + p
    return p

def check_responsiveness(proxy, timeout=10):
    """Step 1: Check if proxy is responsive/reachable."""
    proxies = {"http": proxy, "https": proxy}
    try:
        r = requests.get(RESPONSIVENESS_URL, proxies=proxies, timeout=timeout, verify=False)
        return r.status_code < 500  # Any response means proxy is alive
    except Exception:
        return False

def check_garena_block(proxy, timeout=15):
    """
    Step 2: Check if Garena guest generation is BLOCKED on this proxy.
    Try a guest registration request. If we get a 'blocked' or status code indicating
    IP ban, the proxy is unusable. If we get a normal API response (even error),
    the proxy is not blocked.
    """
    proxies = {"http": proxy, "https": proxy}
    payload = {"app_id": 100067, "client_type": 2, "password": "PP_TestProxy_4242", "source": 2}
    headers = {
        "User-Agent": "GarenaMSDK/4.0.39(SM-A325M;Android 13;en;HK;)",
        "Accept": "application/json", "Content-Type": "application/json; charset=utf-8",
        "Accept-Encoding": "gzip", "Connection": "Keep-Alive"
    }
    try:
        r = requests.post(GARENA_TEST_URL, proxies=proxies, headers=headers, json=payload, timeout=timeout, verify=False)
        # Any HTTP response (even 4xx/5xx with JSON) means proxy reaches Garena and is NOT blocked.
        # A blocked proxy usually times out, returns empty, or returns HTML block page.
        text = r.text
        if r.status_code == 200 and "data" in text:
            return True  # Proxy works perfectly, can generate
        if "block" in text.lower() or "forbidden" in text.lower() or "captcha" in text.lower():
            return False  # Blocked page
        # Other status codes (400/4xx/5xx) - proxy reaches Garena but request failed = NOT blocked
        return True
    except requests.exceptions.ConnectTimeout:
        return False
    except requests.exceptions.ProxyError:
        return False
    except requests.exceptions.SSLError:
        return False
    except Exception:
        return False

def check_proxy_2step(proxy, verbose=False):
    """
    Full 2-step validation.
    Returns: (status, message)
    status: "GOOD" | "UNRESPONSIVE" | "BLOCKED"
    """
    proxy = format_proxy(proxy)
    if not proxy:
        return "BAD", "Empty proxy"
    
    if verbose:
        print(f"[1/2] Checking responsiveness: {proxy}")
    
    # Step 1: Responsiveness
    if not check_responsiveness(proxy):
        return "UNRESPONSIVE", "Proxy not reachable (Step 1 failed)"
    
    if verbose:
        print(f"[1/2] ✅ Responsive")
        print(f"[2/2] Checking Garena block status: {proxy}")
    
    # Step 2: Garena block check
    if not check_garena_block(proxy):
        return "BLOCKED", "Proxy blocked by Garena (Step 2 failed)"
    
    if verbose:
        print(f"[2/2] ✅ Not blocked by Garena")
    
    return "GOOD", "Proxy is ready for generation"

def main():
    """CLI entry point for testing proxies from file or command line."""
    verbose = "-v" in sys.argv or "--verbose" in sys.argv
    
    # Parse proxy(s): from file or args
    proxies = []
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        proxies.append(sys.argv[1])
    elif os.path.exists("proxies.txt"):
        with open("proxies.txt", "r", encoding="utf-8") as f:
            proxies = [l.strip() for l in f if l.strip() and not l.startswith("#")]
    
    if not proxies:
        print("Usage: python proxy_checker.py [proxy] [-v]")
        print("  or create proxies.txt with one proxy per line")
        return
    
    results = {"GOOD": [], "UNRESPONSIVE": [], "BLOCKED": []}
    for p in proxies:
        status, msg = check_proxy_2step(p, verbose)
        results[status].append(p)
        print(f"{p}: {status} - {msg}")
    
    print(f"\n=== PROXY CHECK SUMMARY ===")
    print(f"✅ GOOD: {len(results['GOOD'])}")
    print(f"❌ UNRESPONSIVE: {len(results['UNRESPONSIVE'])}")
    print(f"🚫 BLOCKED: {len(results['BLOCKED'])}")
    
    # Write good proxies to file for bot use
    if results["GOOD"]:
        with open("good_proxies.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(results["GOOD"]))
        print(f"\n💾 Good proxies saved to good_proxies.txt")

if __name__ == "__main__":
    main()