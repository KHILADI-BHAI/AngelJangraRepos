# Free Bot Deployment Guide (No Credit Card Required)

## ⚠️ Important: PythonAnywhere Free Tier Limitations

**PythonAnywhere free tier does NOT support Always-On tasks.** The bot will only run while you're actively using the console. For 24/7 bot hosting, use one of these alternatives:

---

## Option 1: Railway.app ⭐ RECOMMENDED
**Best free option - $5/month credits, no CC required**

### Step 1: Create Railway Account
1. Go to https://railway.app
2. Sign up with GitHub (no credit card)
3. You get $5/month free credits

### Step 2: Deploy from GitHub
1. Click "New Project" → "Deploy from GitHub"
2. Select your `poppyelitebot` repository
3. Railway auto-detects the `render.yaml` config
4. Click "Deploy"

### Step 3: Set Environment Variables
In Railway dashboard:
```
BOT_TOKEN=8614986125:AAHas40P5kGGoFruWXGPu7RfEt9W3BNB3Zg
OWNER_ID=8180833778
WEB_ADMIN_PASSWORD=admin
SITE_NAME=Poppy Elite Hosting
PORT=8080
```

### Step 4: Get Your Bot URL
- Railway gives you: `https://poppy-elite-bot-production.up.railway.app`
- Copy this URL

### Step 5: Update Vercel
Add to Vercel environment variables:
- `BOT_SERVICE_URL` = `https://poppy-elite-bot-production.up.railway.app`

---

## Option 2: Replit (Free but Limited)
**Free tier available, but limited resources**

1. Go to https://replit.com
2. Create new repl, import from GitHub
3. Add `BOT_TOKEN` and `OWNER_ID` to Secrets
4. Use "Always On" feature (free tier has limits)

---

## Option 3: Fly.io (Free Tier)
**Free allowance but requires CC for age verification**

1. Go to https://fly.io
2. Sign up (CC required but won't charge)
3. Use CLI: `fly launch`
4. Deploy with Docker

---

## RECOMMENDED: Railway.app Setup (5 Minutes)

### Prerequisites:
- GitHub account (already have)
- Railway account (sign up free)

### Steps:
1. Push your bot code to https://github.com/AngelJangra/poppyelitebot (already done!)
2. Go to https://railway.app/new
3. Select "Deploy from GitHub repo"
4. Choose `poppyelitebot` repository
5. Railway auto-detects Python and requirements.txt
6. Add environment variables in Railway dashboard
7. Deploy! Your bot will be live in ~2 minutes
8. Get your Railway URL and add it to Vercel

### Cost:
- **$5/month free credits** (enough for small bots 24/7)
- **No credit card required**
- **Automatically scales** based on usage

### Monitoring:
- Railway dashboard shows CPU/RAM usage
- View logs in real-time
- Auto-restarts if bot crashes

---

## After Deployment:

1. **Get your Railway URL** (e.g., `https://poppy-elite-bot.up.railway.app`)
2. **Add to Vercel:**
   - Go to Vercel dashboard → Hosting-BOT project
   - Settings → Environment Variables
   - Add: `BOT_SERVICE_URL` = `https://your-railway-url.up.railway.app`
3. **Redeploy Vercel** to apply changes

Your web panel will now connect to your Railway bot via API!

---

## Troubleshooting:

**Bot not responding?**
- Check Railway logs for errors
- Verify BOT_TOKEN is correct
- Make sure PORT is set to 8080

**Vercel can't connect?**
- Verify BOT_SERVICE_URL is correct (include https://)
- Check Railway app is not sleeping (free tier may sleep after inactivity)
- Test Railway URL directly in browser

**Out of credits?**
- Railway gives $5/month free
- Monitor usage in Railway dashboard
- Bot uses ~$1-2/month for small deployments

---

## Summary:
- **Vercel**: Hosts web panel (already deployed)
- **Railway**: Hosts Telegram bot (24/7, free)
- **Total cost**: $0/month
- **No credit card required**